import React from 'react';
import { Users, Award, Globe, Target, CheckCircle, Star, ArrowLeft } from 'lucide-react';

const AboutPage = () => {
  const team = [
    {
      name: 'دکتر امیر محمدی',
      role: 'مدیر عامل و مشاور ارشد',
      education: 'دکترای موسیقی از کنسرواتوار میلان',
      experience: '15 سال تجربه در آموزش و مشاوره',
      image: 'https://images.pexels.com/photos/3779448/pexels-photo-3779448.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      description: 'با بیش از 15 سال تجربه در زمینه آموزش موسیقی و مشاوره تحصیلی، بیش از 500 دانشجو را در مسیر تحصیل در ایتالیا راهنمایی کرده است.'
    },
    {
      name: 'سارا احمدی',
      role: 'مشاور زبان و آمادگی آزمون',
      education: 'فوق‌لیسانس زبان‌شناسی ایتالیایی',
      experience: '10 سال تجربه آموزش زبان ایتالیایی',
      image: 'https://images.pexels.com/photos/3812944/pexels-photo-3812944.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      description: 'متخصص آموزش زبان ایتالیایی و آمادگی آزمون CILS با نرخ موفقیت 95% در قبولی دانشجویان.'
    },
    {
      name: 'علی رضایی',
      role: 'مشاور ویزا و امور اداری',
      education: 'فوق‌لیسانس حقوق بین‌الملل',
      experience: '8 سال تجربه در امور ویزا و مهاجرت',
      image: 'https://images.pexels.com/photos/3779760/pexels-photo-3779760.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      description: 'متخصص امور ویزا و مدارک قانونی با نرخ موفقیت 98% در اخذ ویزای تحصیلی ایتالیا.'
    }
  ];

  const stats = [
    { number: '500+', label: 'دانشجوی موفق', icon: Users },
    { number: '20+', label: 'کنسرواتوار همکار', icon: Award },
    { number: '98%', label: 'نرخ موفقیت ویزا', icon: CheckCircle },
    { number: '15+', label: 'سال تجربه', icon: Globe }
  ];

  const achievements = [
    'اولین مرکز تخصصی مشاوره موسیقی در ایران',
    'همکاری رسمی با بیش از 20 کنسرواتوار معتبر ایتالیا',
    'بالاترین نرخ موفقیت در اخذ ویزای تحصیلی (98%)',
    'بیش از 500 دانشجوی موفق در مقاطع مختلف',
    'تیم متخصص با تحصیل از دانشگاه‌های معتبر ایتالیا',
    'خدمات جامع از مشاوره تا اسکان در ایتالیا'
  ];

  const testimonials = [
    {
      name: 'آرین محمدی',
      course: 'کنسرواتوار میلان - پیانو',
      text: 'بدون راهنمایی تیم تخصصی این مرکز، هرگز نمی‌توانستم به رویای تحصیل در کنسرواتوار میلان برسم. از مشاوره اولیه تا دریافت ویزا، همه مراحل را با دقت و تخصص همراهی کردند.',
      rating: 5,
      image: 'https://images.pexels.com/photos/3779448/pexels-photo-3779448.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      name: 'سارا رحیمی',
      course: 'کنسرواتوار رم - ویولن',
      text: 'کلاس‌های آمادگی CILS و شبیه‌سازی مصاحبه سفارت فوق‌العاده مفید بود. الان دارم در رم تحصیل می‌کنم و از انتخابم راضی هستم.',
      rating: 5,
      image: 'https://images.pexels.com/photos/3812944/pexels-photo-3812944.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    }
  ];

  const values = [
    {
      icon: Target,
      title: 'تعهد به کیفیت',
      description: 'ارائه بهترین خدمات مشاورهای با استانداردهای بین‌المللی'
    },
    {
      icon: Users,
      title: 'محوریت دانشجو',
      description: 'تمرکز بر نیازها و اهداف فردی هر دانشجو'
    },
    {
      icon: CheckCircle,
      title: 'شفافیت کامل',
      description: 'ارائه اطلاعات دقیق و صادقانه در تمام مراحل'
    },
    {
      icon: Globe,
      title: 'تجربه بین‌المللی',
      description: 'بهره‌مندی از تجربه مستقیم زندگی و تحصیل در ایتالیا'
    }
  ];

  return (
    <div dir="rtl" className="pt-20 pb-16 font-lateef">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-emerald-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold mb-6 font-lalezar">
            درباره ما
          </h1>
          <p className="text-2xl lg:text-3xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
            پیشگام مشاوره تخصصی تحصیل موسیقی در ایتالیا 
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 font-lalezar">
                ماموریت ما
              </h2>
              <p className="text-xl text-gray-700 leading-relaxed mb-8">
                ما با هدف کمک به علاقه‌مندان موسیقی برای تحقق رویای تحصیل در معتبرترین کنسرواتوارهای ایتالیا تأسیس شده‌ایم. 
                تیم ما متشکل از متخصصان با تحصیل و تجربه مستقیم در ایتالیا است که آماده‌اند تا شما را در تمام مراحل همراهی کنند.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">راهنمایی تخصصی و فردی‌سازی‌شده</span>
                </div>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">پشتیبانی کامل از ابتدا تا انتهای فرآیند</span>
                </div>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">تضمین کیفیت خدمات و رضایت دانشجو</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://ik.imagekit.io/amirfaramarzpour/Ali%20Mousavi/Hero.jpg?updatedAt=1758303899858"
                alt="Music education in Italy"
                className="rounded-2xl shadow-2xl"
              />

            </div>
          </div>
        </div>
      </section>



      {/* Team Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4 font-lalezar">
              تیم متخصص ما
            </h2>
            <p className="text-2xl text-gray-600 max-w-2xl mx-auto">
              تیمی از متخصصان باتجربه که خودشان در ایتالیا تحصیل کرده‌اند
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 overflow-hidden">
                <div className="p-8 text-center">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-24 h-24 rounded-full mx-auto mb-6 object-cover"
                  />
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 font-lalezar">{member.name}</h3>
                  <p className="text-blue-600 font-medium mb-4 text-lg">{member.role}</p>
                  <div className="space-y-2 mb-6">
                    <p className="text-sm text-gray-600">{member.education}</p>
                    <p className="text-sm text-gray-600">{member.experience}</p>
                  </div>
                  <p className="text-gray-700 text-lg leading-relaxed">{member.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4 font-lalezar">
              ارزش‌های ما
            </h2>
            <p className="text-2xl text-gray-600">
              اصولی که بر اساس آن‌ها خدمات ارائه می‌دهیم
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <div key={index} className="bg-white rounded-xl p-6 text-center shadow-lg">
                  <div className="bg-gradient-to-r from-blue-600 to-emerald-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 font-lalezar">{value.title}</h3>
                  <p className="text-gray-600 text-lg leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>



      {/* Testimonials Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4 font-lalezar">
              نظرات دانشجویان
            </h2>
            <p className="text-2xl text-gray-600">
              تجربه واقعی دانشجویانی که با ما موفق شدند
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="flex items-center mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover ml-4"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 text-lg font-lalezar">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.course}</p>
                    <div className="flex mt-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 leading-relaxed italic text-lg">"{testimonial.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-800 to-emerald-600 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6 font-lalezar">
            آماده همراهی با شما هستیم
          </h2>
          <p className="text-2xl text-blue-100 mb-8">
            با تیم متخصص ما ملاقات کنید و مسیر تحصیل خود را شروع کنید
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white hover:bg-gray-100 text-blue-800 px-8 py-4 rounded-lg font-semibold text-xl transition-all duration-200 inline-flex items-center justify-center space-x-2 space-x-reverse">
              <span>مشاوره رایگان</span>
              <ArrowLeft className="h-5 w-5" />
            </button>
            <button className="border-2 border-white hover:bg-white hover:text-blue-800 text-white px-8 py-4 rounded-lg font-semibold text-xl transition-all duration-200">
              تماس با ما
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;