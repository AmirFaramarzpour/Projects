import React, { useState } from 'react';
import { Search, Calendar, User, ArrowLeft, Eye, Tag, X } from 'lucide-react';
import { Link } from 'react-router-dom';

// Utility function to convert numbers to Farsi digits
const toFarsiNumber = (num: number | string) => {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/[0-9]/g, (d) => farsiDigits[parseInt(d)]);
};

interface Post {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  category: string;
  author: string;
  date: string;
  readTime: string;
  views: number;
  tags: string[];
}

const BlogPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const postsPerPage = 6;

  const categories = [
    { id: 'all', name: 'همه مقالات', count: 24 },
    { id: 'study', name: 'تحصیل', count: 8 },
    { id: 'language', name: 'زبان', count: 6 },
    { id: 'visa', name: 'ویزا', count: 4 },
    { id: 'experience', name: 'تجربه دانشجوها', count: 6 }
  ];

  const blogPosts: Post[] = [
    {
      id: 1,
      title: 'شرایط تحصیل موسیقی در ایتالیا',
      excerpt: 'راهنمای کاملی از شرایط ورود، مدارک مورد نیاز، و فرآیند پذیرش در کنسرواتوارهای معتبر ایتالیا.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/164821/pexels-photo-164821.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'study',
      author: 'دکتر امیر محمدی',
      date: '1403/10/15',
      readTime: '۸ دقیقه',
      views: 1250,
      tags: ['تحصیل', 'کنسرواتوار', 'ایتالیا']
    },
    {
      id: 2,
      title: 'آشنایی با آزمون CILS',
      excerpt: 'همه چیز درباره آزمون CILS: ساختار، نحوه آمادگی، نکات مهم، و راهنمای قدم به قدم برای قبولی.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/301920/pexels-photo-301920.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'language',
      author: 'سارا احمدی',
      date: '1403/10/10',
      readTime: '۱۲ دقیقه',
      views: 980,
      tags: ['CILS', 'آزمون', 'زبان ایتالیایی']
    },
    {
      id: 3,
      title: 'نکات مهم برای موفقیت در مصاحبه سفارت ایتالیا',
      excerpt: 'راهنمای جامع برای آمادگی مصاحبه سفارت، سوالات متداول، و نکات کلیدی برای افزایش شانس پذیرش.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'visa',
      author: 'علی رضایی',
      date: '1403/10/05',
      readTime: '۱۰ دقیقه',
      views: 1580,
      tags: ['ویزا', 'مصاحبه', 'سفارت']
    },
    {
      id: 4,
      title: 'بهترین کنسرواتوارهای موسیقی ایتالیا',
      excerpt: 'معرفی معتبرترین کنسرواتوارهای موسیقی ایتالیا، رشته‌های تحصیلی، و ویژگی‌های هر یک.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/1407322/pexels-photo-1407322.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'study',
      author: 'دکتر مریم حسینی',
      date: '1403/09/28',
      readTime: '۱۵ دقیقه',
      views: 2100,
      tags: ['کنسرواتوار', 'دانشگاه', 'موسیقی']
    },
    {
      id: 5,
      title: 'تجربه من از تحصیل پیانو در کنسرواتوار میلان',
      excerpt: 'داستان واقعی یکی از دانشجویان موفق ما که توانست وارد کنسرواتوار میلان شود و تجربیاتش را با ما در میان گذاشت.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/1246437/pexels-photo-1246437.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'experience',
      author: 'آرین محمدی',
      date: '1403/09/20',
      readTime: '۷ دقیقه',
      views: 1650,
      tags: ['تجربه', 'پیانو', 'میلان']
    },
    {
      id: 6,
      title: 'راهنمای یادگیری زبان ایتالیایی برای مبتدیان',
      excerpt: 'نکات و روش‌های مؤثر برای شروع یادگیری زبان ایتالیایی، منابع مفید، و برنامه‌ریزی مطالعه.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/267507/pexels-photo-267507.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'language',
      author: 'فاطمه کریمی',
      date: '1403/09/15',
      readTime: '۹ دقیقه',
      views: 890,
      tags: ['زبان', 'آموزش', 'مبتدی']
    },
    {
      id: 7,
      title: 'هزینه‌های تحصیل و زندگی در ایتالیا',
      excerpt: 'بررسی کامل هزینه‌های تحصیل، اجاره، غذا، و سایر مخارج زندگی در شهرهای مختلف ایتالیا.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/3483098/pexels-photo-3483098.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'study',
      author: 'حسن علیزاده',
      date: '1403/09/10',
      readTime: '۱۱ دقیقه',
      views: 1420,
      tags: ['هزینه', 'زندگی', 'بودجه']
    },
    {
      id: 8,
      title: 'مدارک مورد نیاز برای اخذ ویزای تحصیلی ایتالیا',
      excerpt: 'لیست کامل مدارک، نحوه تهیه، ترجمه، و تأیید مدارک برای درخواست ویزای تحصیلی ایتالیا.',
      content: 'محتوای کامل مقاله در اینجا قرار می‌گیرد...',
      image: 'https://images.pexels.com/photos/4491881/pexels-photo-4491881.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'visa',
      author: 'نگار صادقی',
      date: '1403/09/05',
      readTime: '۱۳ دقیقه',
      views: 1750,
      tags: ['مدارک', 'ویزا', 'راهنما']
    }
  ];

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = filteredPosts.slice(indexOfFirstPost, indexOfLastPost);
  const totalPages = Math.ceil(filteredPosts.length / postsPerPage);

  const openPostModal = (post: Post) => {
    setSelectedPost(post);
  };

  const closePostModal = () => {
    setSelectedPost(null);
  };

  return (
    <div className="pt-20 pb-16 rtl font-farsi font-lattef-bold" dir="rtl">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-emerald-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6 font-lattef-bold">
              مجله تحصیل در ایتالیا
            </h1>
            <p className="text-base lg:text-2xl text-blue-100 max-w-xl mx-auto leading-relaxed font-farsi-body">
              آخرین مقالات، راهنماها، و تجربیات واقعی برای موفقیت در تحصیل موسیقی
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="جستجو در مقالات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-lg border-0 text-gray-900 text-xl focus:ring-2 focus:ring-yellow-400 font-farsi-body"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* All Posts */}
            <section>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold text-gray-900 font-lattef-bold">
                  {searchTerm || selectedCategory !== 'all' ? 'نتایج جستجو' : 'همه مقالات'}
                </h2>
                <div className="text-base text-gray-600 font-farsi-body">
                  <span className="font-lattef-bold">{toFarsiNumber(filteredPosts.length)}</span> مقاله یافت شد
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {currentPosts.map((post) => (
                  <article key={post.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div className="relative">
                      <img
                        src={post.image}
                        alt={post.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-4 right-4">
                        <span className="bg-blue-600 text-white text-sm px-3 py-1 rounded-full font-farsi-body">
                          {categories.find(cat => cat.id === post.category)?.name}
                        </span>
                      </div>
                      <div className="absolute bottom-4 right-4 bg-black/70 text-white text-sm px-2 py-1 rounded">
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <Eye className="h-3 w-3" />
                          <span className="font-lattef-bold">{toFarsiNumber(post.views)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-2xl font-bold text-gray-900 mb-3 line-clamp-2 hover:text-blue-600 transition-colors duration-200 font-lattef-bold">
                        {post.title}
                      </h3>
                      <p className="text-gray-600 mb-4 line-clamp-3 font-farsi-body text-xl font-lattef-bold">{post.excerpt}</p>
                      
                      <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <User className="h-4 w-4" />
                          <span className="font-farsi-body">{post.author}</span>
                        </div>
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <Calendar className="h-4 w-4" />
                          <span className="font-lattef-bold text-base">{toFarsiNumber(post.date)}</span>
                        </div>
                        <div className="text-blue-600 font-farsi-body text-xl">
                          {post.readTime}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex flex-wrap gap-1">
                          {post.tags.slice(0, 2).map((tag, index) => (
                            <span key={index} className="bg-gray-100 text-gray-600 text-sm px-2 py-1 rounded font-farsi-body">
                              #{tag}
                            </span>
                          ))}
                        </div>
                        <button 
                          onClick={() => openPostModal(post)}
                          className="text-blue-600 hover:text-blue-800 font-medium text-base inline-flex items-center space-x-1 space-x-reverse group font-farsi-body"
                        >
                          <span>مطالعه کامل</span>
                          <ArrowLeft className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
                        </button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center items-center space-x-2 space-x-reverse mt-12">
                  <button
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed font-farsi-body text-base"
                  >
                    قبلی
                  </button>
                  
                  {[...Array(totalPages)].map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentPage(index + 1)}
                      className={`px-4 py-2 rounded-lg font-lattef-bold ${
                        currentPage === index + 1
                          ? 'bg-blue-600 text-white'
                          : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {toFarsiNumber(index + 1)}
                    </button>
                  ))}
                  
                  <button
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed font-farsi-body text-base"
                  >
                    بعدی
                  </button>
                </div>
              )}
            </section>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-8">
              {/* Categories */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-4 font-lattef-bold">دسته‌بندی مقالات</h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full text-right px-4 py-3 rounded-lg transition-colors duration-200 font-farsi-body text-xl ${
                        selectedCategory === category.id
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{category.name}</span>
                        <span className={`text-sm px-2 py-1 rounded font-lattef-bold ${
                          selectedCategory === category.id
                            ? 'bg-white/20'
                            : 'bg-gray-300 text-gray-600'
                        }`}>
                          {toFarsiNumber(category.count)}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Popular Posts */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4 font-lattef-bold">محبوب‌ترین مقالات</h3>
                <div className="space-y-4">
                  {blogPosts.slice().sort((a, b) => b.views - a.views).slice(0, 5).map((post, index) => (
                    <div key={post.id} className="flex items-start space-x-3 space-x-reverse">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-base font-bold font-lattef-bold">
                        {toFarsiNumber(index + 1)}
                      </div>
                      <div className="flex-1">
                        <h4 
                          className="text-base font-medium text-gray-900 line-clamp-2 hover:text-blue-600 cursor-pointer font-lattef-bold"
                          onClick={() => openPostModal(post)}
                        >
                          {post.title}
                        </h4>
                        <div className="flex items-center text-sm text-gray-500 mt-1">
                          <Eye className="h-3 w-3 ml-1" />
                          <span className="font-lattef-bold">{toFarsiNumber(post.views)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Newsletter Signup */}
              <div className="bg-gradient-to-br from-blue-600 to-emerald-500 rounded-xl p-6 text-white">
                <h3 className="text-xl font-bold mb-3 font-lattef-bold">خبرنامه ما</h3>
                <p className="text-blue-100 text-base mb-4 font-farsi-body">
                  آخرین مقالات و اخبار تحصیل در ایتالیا را دریافت کنید
                </p>
                <input
                  type="email"
                  placeholder="آدرس ایمیل"
                  className="w-full px-4 py-2 rounded-lg text-gray-900 text-base focus:outline-none focus:ring-2 focus:ring-white font-farsi-body"
                />
                <button
                  type="submit"
                  className="w-full bg-white text-blue-600 px-4 py-2 rounded-lg font-medium text-base hover:bg-gray-100 transition-colors duration-200 font-farsi-body mt-3"
                >
                  عضویت در خبرنامه
                </button>
              </div>

              {/* Tags */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4 font-lattef-bold">برچسب‌های محبوب</h3>
                <div className="flex flex-wrap gap-2">
                  {['موسیقی', 'ایتالیا', 'کنسرواتوار', 'CILS', 'ویزا', 'تحصیل', 'زبان', 'مصاحبه'].map((tag) => (
                    <span
                      key={tag}
                      className="bg-gray-100 hover:bg-blue-100 text-gray-700 hover:text-blue-700 px-3 py-1 rounded-full text-sm cursor-pointer transition-colors duration-200 font-farsi-body"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Blog Post Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 overflow-y-auto" dir="rtl">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 sm:p-0" dir="rtl">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={closePostModal}></div>

            <div 
              className="inline-block align-bottom bg-white rounded-lg overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full"
              role="dialog"
              aria-labelledby="modal-title"
              dir="rtl"
            >
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" dir="rtl">
                <div className="flex items-center justify-between mb-4">
                  <h3 id="modal-title" className="text-4xl font-bold text-gray-900 font-lattef-bold">{selectedPost.title}</h3>
                  <button
                    onClick={closePostModal}
                    className="text-gray-400 hover:text-gray-600 transition-colors duration-200 ml-4"
                  >
                    <X className="h-6 w-6" />
                  </button>
                </div>

                <div className="mb-6">
                  <img
                    src={selectedPost.image}
                    alt={selectedPost.title}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                </div>

                <div className="flex items-center justify-end mb-6 space-x-4 space-x-reverse">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="flex items-center space-x-1 space-x-reverse">
                      <User className="h-4 w-4 mx-3" />
                      <span className="font-farsi-body">{selectedPost.author}</span>
                    </div>
                    <div className="flex items-center space-x-1 space-x-reverse">
                      <Calendar className="h-4 w-4 mx-3" />
                      <span className="font-lattef-bold">{toFarsiNumber(selectedPost.date)}</span>
                    </div>
                    <div className="flex items-center space-x-1 space-x-reverse">
                      <Eye className="h-4 w-4 mx-3" />
                      <span className="font-lattef-bold">{toFarsiNumber(selectedPost.views)}</span>
                    </div>
                  </div>
                  <span className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full font-farsi-body">
                    {categories.find(cat => cat.id === selectedPost.category)?.name}
                  </span>
                </div>

                <div className="prose prose-lg max-w-none mb-6" dir="rtl">
                  <p className="text-gray-700 leading-relaxed font-farsi-body text-lg mb-4">
                    {selectedPost.excerpt}
                  </p>
                  <div className="text-gray-700 leading-relaxed font-farsi-body text-lg space-y-4">
                    {selectedPost.content}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-6 justify-end">
                  {selectedPost.tags.map((tag: string, index: number) => (
                    <span key={index} className="bg-gray-100 text-gray-600 text-sm px-3 py-1 rounded-full font-farsi-body">
                      #{tag}
                    </span>
                  ))}
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={closePostModal}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 font-farsi-body text-base"
                  >
                    بستن
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BlogPage;