
import React, { useState } from 'react';
import { Phone, Mail, MessageCircle, Send, CheckCircle, Instagram, Youtube, Linkedin, Globe } from 'lucide-react';

// Utility function to convert Latin numbers to Persian numbers
const toPersianNumber = (num: string | number) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(num).replace(/[0-9]/g, (d) => persianDigits[parseInt(d)]);
};

const ContactPage = () => {
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const [consultationForm, setConsultationForm] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    preferredDate: '',
    preferredTime: '',
    message: ''
  });
  const [isBooking, setIsBooking] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const socialMedia = [
    { name: 'LinkedIn', icon: Linkedin, url: '#', color: 'bg-blue-700' },
    { name: 'YouTube', icon: Youtube, url: '#', color: 'bg-red-500' },
    { name: 'Instagram', icon: Instagram, url: '#', color: 'bg-pink-500' },
    { name: 'Telegram', icon: MessageCircle, url: '#', color: 'bg-blue-500' },
    { name: 'WhatsApp', icon: MessageCircle, url: '#', color: 'bg-green-500' },
    { name: 'Email', icon: Mail, url: 'mailto:info@musicstudyitaly.com', color: 'bg-gray-500' },
    { name: 'Website', icon: Globe, url: 'https://musicstudyitaly.com', color: 'bg-purple-500' },
    { name: 'Phone', icon: Phone, url: 'tel:+989123456789', color: 'bg-teal-500' }
  ];

  const services = [
    'مشاوره عمومی تحصیل موسیقی',
    'راهنمایی انتخاب دانشگاه',
    'کمک در تهیه مدارک',
    'آمادگی مصاحبه سفارت',
    'آموزش زبان ایتالیایی',
    'سایر موارد'
  ];

  const timeSlots = [
    '09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00', '18:00'
  ].map(time => toPersianNumber(time));

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      console.log('Contact form submitted:', contactForm);
      setIsSuccess(true);
      setContactForm({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      });
      setTimeout(() => setIsSuccess(false), 3000);
    } catch (error) {
      console.error('Contact form error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConsultationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsBooking(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      console.log('Consultation booking submitted:', consultationForm);
      setBookingSuccess(true);
      setConsultationForm({
        name: '',
        email: '',
        phone: '',
        service: '',
        preferredDate: '',
        preferredTime: '',
        message: ''
      });
      setTimeout(() => setBookingSuccess(false), 3000);
    } catch (error) {
      console.error('Consultation booking error:', error);
    } finally {
      setIsBooking(false);
    }
  };

  const handleContactInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setContactForm({
      ...contactForm,
      [e.target.name]: e.target.value
    });
  };

  const handleConsultationInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setConsultationForm({
      ...consultationForm,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="pt-20 pb-16" dir="rtl">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-emerald-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6">
            تماس با ما
          </h1>
          <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
            آماده پاسخ‌گویی به سوالات شما و راهنمایی در مسیر تحصیل در ایتالیا هستیم
          </p>
        </div>
      </section>

      {/* Contact Forms */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* General Contact Form */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-right">ارسال پیام</h2>
              
              {isSuccess ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">پیام شما ارسال شد!</h3>
                  <p className="text-gray-600">به زودی با شما تماس خواهیم گرفت.</p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                        نام و نام خانوادگی *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={contactForm.name}
                        onChange={handleContactInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                        شماره تماس *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={contactForm.phone}
                        onChange={handleContactInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                        required
                        dir="ltr"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                      آدرس ایمیل *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={contactForm.email}
                      onChange={handleContactInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                      required
                      dir="ltr"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                      موضوع پیام *
                    </label>
                    <select
                      name="subject"
                      value={contactForm.subject}
                      onChange={handleContactInputChange}
                      className="w-full text-xl font-bold px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                      required
                    >
                      <option value="">انتخاب کنید</option>
                      <option value="consultation">مشاوره تحصیل</option>
                      <option value="visa">سوال درباره ویزا</option>
                      <option value="courses">سوال درباره دوره‌ها</option>
                      <option value="general">سوال عمومی</option>
                      <option value="complaint">شکایت یا انتقاد</option>
                      <option value="suggestion">پیشنهاد</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                      متن پیام *
                    </label>
                    <textarea
                      name="message"
                      value={contactForm.message}
                      onChange={handleContactInputChange}
                      rows={6}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right text-base"
                      placeholder="لطفاً پیام خود را به تفصیل بنویسید..."
                      required
                    />
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white text-xl font-bold py-4 px-8 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 space-x-reverse"
                  >
                    <Send className="h-5 w-5 " />
                    <span>{isSubmitting ? 'در حال ارسال...' : 'ارسال پیام'}</span>
                  </button>
                </form>
              )}
            </div>

            {/* Consultation Booking Form */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-right">رزرو مشاوره رایگان</h2>
              
              {bookingSuccess ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">رزرو موفق بود!</h3>
                  <p className="text-gray-600">جلسه مشاوره شما رزرو شد. به زودی تماس خواهیم گرفت.</p>
                </div>
              ) : (
                <form onSubmit={handleConsultationSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                        نام و نام خانوادگی *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={consultationForm.name}
                        onChange={handleConsultationInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                        شماره تماس *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={consultationForm.phone}
                        onChange={handleConsultationInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                        required
                        dir="ltr"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                      آدرس ایمیل *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={consultationForm.email}
                      onChange={handleConsultationInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                      required
                      dir="ltr"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                      نوع مشاوره *
                    </label>
                    <select
                      name="service"
                      value={consultationForm.service}
                      onChange={handleConsultationInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                      required
                    >
                      <option value="">انتخاب کنید</option>
                      {services.map((service) => (
                        <option key={service} value={service}>
                          {service}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                        تاریخ ترجیحی *
                      </label>
                      <input
                        type="date"
                        name="preferredDate"
                        value={consultationForm.preferredDate}
                        onChange={handleConsultationInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                        required
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                        زمان ترجیحی *
                      </label>
                      <select
                        name="preferredTime"
                        value={consultationForm.preferredTime}
                        onChange={handleConsultationInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                        required
                      >
                        <option value="">انتخاب کنید</option>
                        {timeSlots.map((time) => (
                          <option key={time} value={time}>
                            {time}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xl font-bold text-gray-700 mb-2 text-right">
                      پیام یا سوال (اختیاری)
                    </label>
                    <textarea
                      name="message"
                      value={consultationForm.message}
                      onChange={handleConsultationInputChange}
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right text-base"
                      placeholder="سوالات یا توضیحات اضافی..."
                    />
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isBooking}
                    className="w-full bg-gradient-to-r from-emerald-600 to-blue-500 hover:from-emerald-700 hover:to-blue-600 text-white text-xl font-bold py-4 px-8 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 space-x-reverse"
                  >
                    <CheckCircle className="h-5 w-5" />
                    <span>{isBooking ? 'در حال رزرو...' : 'رزرو مشاوره رایگان'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Social Media */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-3xl font-semibold text-gray-900 mb-6">ما را در شبکه‌های اجتماعی دنبال کنید</h3>
            <div className="flex justify-center space-x-4 space-x-reverse">
              {socialMedia.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={index}
                    href={social.url}
                    className={`${social.color} hover:opacity-90 text-white w-12 h-12 rounded-full flex items-center justify-center transition-opacity duration-200`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <IconComponent className="h-6 w-6" />
                  </a>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
