import React, { useState } from 'react';
import { ArrowLeft, Star, Users, Award, Globe, Calendar, Mail, Phone, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const services = [
    {
      icon: Users,
      title: 'مشاوره و کوچینگ',
      description: 'راهنمایی تخصصی برای انتخاب دانشگاه و رشته موسیقی مناسب',
      link: '/services'
    },
    {
      icon: Award,
      title: 'اخذ ویزای تحصیلی',
      description: 'کمک کامل در فرآیند اخذ ویزای تحصیلی ایتالیا',
      link: '/services'
    },
    {
      icon: Globe,
      title: 'آموزش زبان ایتالیایی',
      description: 'کلاس‌های خصوصی و گروهی زبان ایتالیایی از مبتدی تا پیشرفته',
      link: '/services'
    },
    {
      icon: MessageSquare,
      title: 'آمادگی مصاحبه سفارت',
      description: 'تمرین و شبیه‌سازی مصاحبه سفارت برای افزایش شانس پذیرش',
      link: '/services'
    }
  ];

  const testimonials = [
    {
      name: 'آرین محمدی',
      role: 'دانشجوی کنسرواتوار میلان',
      image: 'https://images.pexels.com/photos/3779448/pexels-photo-3779448.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      quote: 'بدون راهنمایی‌های تخصصی این تیم، هرگز نمی‌توانستم وارد کنسرواتوار میلان شوم. از مشاوره تا ویزا همه چیز عالی بود.',
      rating: 5
    },
    {
      name: 'سارا رحیمی',
      role: 'دانشجوی کنسرواتوار رم',
      image: 'https://images.pexels.com/photos/3812944/pexels-photo-3812944.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      quote: 'کلاس‌های زبان ایتالیایی بسیار کاربردی بود و کمک زیادی به قبولی من در آزمون ورودی کرد.',
      rating: 5
    },
    {
      name: 'امیر صادقی',
      role: 'دانشجوی کنسرواتوار فلورانس',
      image: 'https://images.pexels.com/photos/3779760/pexels-photo-3779760.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      quote: 'مشاوره‌های این تیم واقعاً تخصصی و کاربردی است. الان دارم در فلورانس تحصیل می‌کنم.',
      rating: 5
    }
  ];

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      console.log('Contact form submitted:', contactForm);
      setIsSuccess(true);
      setContactForm({ name: '', email: '', phone: '', message: '' });
      setTimeout(() => setIsSuccess(false), 3000);
    } catch (error) {
      console.error('Contact form error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setContactForm({
      ...contactForm,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="pt-16">
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Lalezar&family=Lateef:wght@700&display=swap');
          .font-lalezar { font-family: 'Lalezar', sans-serif; }
          .font-lateef { font-family: 'Lateef', sans-serif; }
          .font-lateef-bold { font-family: 'Lateef', sans-serif; font-weight: 700; }
          .italy-flag-text {
            background: linear-gradient(to left, #009246 0%, #009246 33%, #ffffff 33%, #ffffff 66%, #ce2b37 66%, #ce2b37 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
          }
        `}
      </style>

      {/* Hero Section */}
      <section dir="rtl" className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-emerald-700 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div 
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: 'url("https://ik.imagekit.io/amirfaramarzpour/Ali%20Mousavi/wallpaperflare.com_wallpaper.jpg?updatedAt=1746031964110")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        ></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-right">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight mb-6 font-lalezar">
                تحصیل موسیقی در 
                <span className="italy-flag-text">ایتالیا</span>
                <span className="block text-yellow-400">با راهنمایی تخصصی</span>
              </h1>
              <p className="text-xl lg:text-3xl text-blue-100 mb-8 leading-relaxed font-lateef">
                رویای خود را برای تحصیل در معتبرترین کنسرواتوارهای ایتالیا با کمک ما محقق کنید
              </p>
              <div className="flex flex-col sm:flex-row-reverse gap-4">
                <Link
                  to="/contact"
                  className="bg-[#064232] hover:bg-[#556B2F] text-[#EFF5D2] px-12 py-4 border-2 border-[#EFF5D2] rounded-xl font-lalezar transition-all duration-200 text-center text-xl inline-flex items-center justify-center space-x-reverse space-x-2"
                >
                  <Calendar className="h-5 w-5 mx-3" />
                  <span>ثبت مشاوره رایگان</span>
                </Link>


                {/* 
                <Link
                  to="/courses"
                  className="border-2 border-white hover:bg-white hover:text-blue-900 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 text-xl text-center inline-flex items-center justify-center space-x-reverse space-x-2 font-lateef"
                >
                  <span>شروع مسیر تحصیل</span>
                  <ArrowLeft className="h-5 w-5" />
                </Link> 
                */}

              </div>
            </div>
            
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <img
                  src="https://ik.imagekit.io/amirfaramarzpour/Ali%20Mousavi/Ennio%20Morricone.jpeg?updatedAt=1758329126899"
                  alt="Music student in Italy"
                  className="w-full h-80 object-cover rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section dir="rtl" className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl text-red-700 mb-4 font-lalezar font-bold">
              خدمات تخصصی ما
            </h2>
            <p className="text-2xl text-green-700 max-w-2xl mx-auto font-lateef-bold">
              از مشاوره تا اخذ ویزا، همه مراحل تحصیل در ایتالیا را با شما هستیم
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <div
                  key={index}
                  className="bg-transparent border-2 border-green-500 rounded-xl p-8 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group"
                >
                  <div className="bg-gradient-to-r from-green-600 via-white to-red-600 w-16 h-16 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-200">
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl text-red-800 mb-3 font-lalezar font-bold">
                    {service.title}
                  </h3>
                  <p className="text-green-800 mb-6 leading-relaxed font-lateef-bold text-lg">
                    {service.description}
                  </p>
                  <Link
                    to={service.link}
                    className="text-red-600 hover:text-green-700 font-medium inline-flex items-center space-x-reverse space-x-1 group/link font-lateef-bold"
                  >
                    <span>بیشتر بخوانید</span>
                    <ArrowLeft className="h-4 w-4 group-hover/link:-translate-x-1 transition-transform duration-200" />
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>


      {/* Testimonials Section */}
      <section dir="rtl" className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 font-lalezar">
              نظرات دانشجویان موفق
            </h2>
            <p className="text-xl text-gray-600 font-lateef">
              تجربه‌های دانشجویانی که رویاهایشان را در ایتالیا محقق کردند
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-shadow duration-300">
                <div className="flex items-center mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover ml-4"
                  />
                  <div className="flex-1 text-right">
                    <h4 className="font-semibold text-gray-900 font-lalezar">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600 font-lateef">{testimonial.role}</p>
                    <div className="flex justify-end mt-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 leading-relaxed font-lateef">{testimonial.quote}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section dir="rtl" className="bg-gradient-to-br from-blue-800 to-emerald-600 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white mb-12">
            <h2 className="text-4xl lg:text-5xl font-lateef-bold text-white mb-4">
              آماده شروع هستید؟
            </h2>
            <p className="text-2xl text-blue-100 font-lateef-bold">
              همین حالا با ما تماس بگیرید و اولین قدم را برای تحصیل در ایتالیا بردارید
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-2xl">
            {isSuccess ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-lateef-bold text-gray-900 mb-2">پیام شما ارسال شد!</h3>
                <p className="text-lg text-gray-600 font-lateef-bold">به زودی با شما تماس خواهیم گرفت.</p>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-base font-lateef-bold text-gray-700 mb-2">
                      نام و نام خانوادگی *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={contactForm.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right font-lateef-bold text-lg"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-base font-lateef-bold text-gray-700 mb-2">
                      شماره تماس *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={contactForm.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right font-lateef-bold text-lg"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-base font-lateef-bold text-gray-700 mb-2">
                    آدرس ایمیل *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={contactForm.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right font-lateef-bold text-lg"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-base font-lateef-bold text-gray-700 mb-2">
                    پیام شما *
                  </label>
                  <textarea
                    name="message"
                    value={contactForm.message}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right font-lateef-bold text-lg"
                    placeholder="لطفاً سوال یا درخواست خود را بنویسید..."
                    required
                  />
                </div>
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white font-lateef-bold text-xl py-4 px-8 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? 'در حال ارسال...' : 'ارسال پیام'}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;