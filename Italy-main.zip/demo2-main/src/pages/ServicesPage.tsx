import React, { useState } from 'react';
import { Users, Award, Globe, MessageSquare, FileText, Video, ArrowLeft, CheckCircle } from 'lucide-react';
import BookingModal from '../components/BookingModal';

const ServicesPage = () => {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [expandedService, setExpandedService] = useState<number | null>(null);

  const services = [
    {
      icon: Users,
      title: 'مشاوره و کوچینگ تحصیل موسیقی در ایتالیا',
      subtitle: 'راهنمایی کامل از انتخاب رشته تا پذیرش در دانشگاه',
      description: 'خدمات مشاوره تخصصی ما شامل بررسی پروفایل تحصیلی، انتخاب بهترین کنسرواتوار متناسب با علایق و توانایی‌های شما، راهنمایی برای تهیه مدارک مورد نیاز، و برنامه‌ریزی مرحله به مرحله برای ورود به دانشگاه می‌باشد.',
      features: [
        'بررسی رایگان پروفایل تحصیلی',
        'معرفی بهترین کنسرواتوارها',
        'راهنمایی تهیه پورتفولیو',
        'برنامه‌ریزی زمان‌بندی اقدامات',
        'پشتیبانی تا زمان ورود به دانشگاه'
      ],
      duration: '۳-۶ ماه',
      price: 'تماس بگیرید',
      included: ['جلسات مشاوره آنلاین', 'راهنمایی تهیه مدارک', 'پیگیری فرآیند پذیرش']
    },
    {
      icon: Award,
      title: 'خدمات ویزا و مدارک',
      subtitle: 'کمک کامل در فرآیند اخذ ویزای تحصیلی',
      description: 'تیم متخصص ما در زمینه اخذ ویزای تحصیلی ایتالیا، شما را در تمام مراحل از تهیه مدارک تا مصاحبه سفارت همراهی می‌کند. ما بیش از ۹۸٪ موفقیت در اخذ ویزا داریم.',
      features: [
        'بررسی کامل مدارک',
        'ترجمه رسمی اسناد',
        'تنظیم فرم‌های درخواست',
        'راهنمایی مراحل سفارت',
        'پیگیری وضعیت ویزا'
      ],
      duration: '۲-۳ ماه',
      price: 'تماس بگیرید',
      included: ['چک‌لیست کامل مدارک', 'راهنمایی قدم به قدم', 'پشتیبانی تا صدور ویزا']
    },
    {
      icon: Globe,
      title: 'کلاس خصوصی زبان ایتالیایی',
      subtitle: 'آموزش زبان ایتالیایی از مبتدی تا پیشرفته',
      description: 'کلاس‌های آموزش زبان ایتالیایی ما با تمرکز بر مهارت‌های ضروری برای تحصیل و زندگی در ایتالیا طراحی شده است. از سطح مبتدی تا پیشرفته (A1 تا C1) با استادان باتجربه.',
      features: [
        'آموزش ۴ مهارت اصلی زبان',
        'تمرکز بر مکالمه عملی',
        'مواد آموزشی اختصاصی',
        'کلاس‌های انعطاف‌پذیر آنلاین',
        'تست تعیین سطح رایگان'
      ],
      duration: 'بر اساس سطح (۳-۱۲ ماه)',
      price: 'از ۵۰۰,۰۰۰ تومان',
      included: ['کتاب و منابع آموزشی', 'تمرینات تعاملی', 'گواهی پایان دوره']
    },
    {
      icon: FileText,
      title: 'دوره آمادگی آزمون CILS',
      subtitle: 'آماده‌سازی کامل برای آزمون CILS',
      description: 'دوره جامع آمادگی برای آزمون CILS (گواهینامه زبان ایتالیایی دانشگاه سیه‌نا) که برای ورود به دانشگاه‌های ایتالیا ضروری است. شامل تمرین تمام بخش‌های آزمون و تکنیک‌های پاسخ‌گویی.',
      features: [
        'آشنایی کامل با ساختار آزمون',
        'تمرین تمام بخش‌های آزمون',
        'آزمون‌های تجربی متعدد',
        'بررسی نقاط ضعف و قوت',
        'تکنیک‌های موثر پاسخ‌گویی'
      ],
      duration: '۲-۴ ماه',
      price: '۸۰۰,۰۰۰ تومان',
      included: ['منابع آمادگی اختصاصی', 'آزمون‌های تجربی', 'تحلیل عملکرد']
    },
    {
      icon: Video,
      title: 'کلاس شبیه‌سازی مصاحبه سفارت',
      subtitle: 'تمرین مصاحبه سفارت با شرایط واقعی',
      description: 'جلسات شبیه‌سازی مصاحبه سفارت ایتالیا برای افزایش اعتماد به نفس و آمادگی کامل شما. شامل سوالات متداول، نحوه پاسخ‌گویی مناسب، و تکنیک‌های موثر ارتباط.',
      features: [
        'شبیه‌سازی کامل شرایط مصاحبه',
        'بررسی سوالات متداول',
        'آموزش زبان بدن مناسب',
        'تمرین پاسخ‌گویی مؤثر',
        'فیدبک تخصصی و بازخورد'
      ],
      duration: '۴-۶ جلسه',
      price: '۶۰۰,۰۰۰ تومان',
      included: ['جلسات فردی', 'ضبط ویدیو برای بررسی', 'راهنمای آمادگی']
    },
    {
      icon: MessageSquare,
      title: 'مشاوره تخصصی انتخاب کنسرواتوار',
      subtitle: 'راهنمایی در انتخاب بهترین کنسرواتوار',
      description: 'خدمات مشاوره تخصصی برای انتخاب کنسرواتوار مناسب بر اساس رشته موسیقی، بودجه، شهر مورد نظر، و شرایط پذیرش. شامل معرفی اساتید برتر و امکانات هر کنسرواتوار.',
      features: [
        'معرفی کنسرواتوارهای برتر',
        'بررسی شرایط پذیرش',
        'مقایسه هزینه‌ها و امکانات',
        'معرفی اساتید مطرح',
        'راهنمایی انتخاب شهر مناسب'
      ],
      duration: '۲-۳ جلسه',
      price: '۴۰۰,۰۰۰ تومان',
      included: ['گزارش تخصصی', 'لیست کنسرواتوارهای توصیه‌شده', 'مشاوره پیگیری']
    }
  ];

  const toggleExpand = (index: number) => {
    setExpandedService(expandedService === index ? null : index);
  };

  return (
    <div dir="rtl" className="pt-20 pb-16 font-lateef font-bold text-2xl">
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Lalezar&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Lateef:wght@700&display=swap');
        .font-lalezar {
          font-family: 'Lalezar', sans-serif;
        }
        .font-lateef {
          font-family: 'Lateef', sans-serif;
          font-weight: 700;
        }
        [dir="rtl"] {
          direction: rtl;
          text-align: right;
        }
        .persian-numbers {
          font-family: 'Lateef', sans-serif;
          font-feature-settings: "numr" 1;
        }
      `}</style>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-emerald-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl font-lalezar mb-6">
            خدمات تخصصی ما
          </h1>
          <p className="text-xl lg:text-2xl text-blue-100 max-w-3xl mx-auto leading-relaxed font-lateef">
            مجموعه کاملی از خدمات برای راهنمایی شما در مسیر تحصیل موسیقی در ایتالیا
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              const isExpanded = expandedService === index;
              
              return (
                <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                  <div className="p-8 lg:p-12">
                    <div className="flex flex-col lg:flex-row lg:items-start lg:space-x-8 lg:space-x-reverse">
                      {/* Icon and Title */}
                      <div className="flex-shrink-0 mb-6 lg:mb-0">
                        <div className="bg-gradient-to-r from-blue-600 to-emerald-500 w-20 h-20 rounded-xl flex items-center justify-center mb-6">
                          <IconComponent className="h-10 w-10 text-white" />
                        </div>
                      </div>

                      {/* Content */}
                      <div className="flex-1">
                        <h3 className="text-2xl lg:text-3xl font-lalezar text-gray-900 mb-2">{service.title}</h3>
                        <p className="text-lg text-gray-600 mb-6 font-lateef">{service.subtitle}</p>
                        
                        <p className="text-gray-700 leading-relaxed mb-6 font-lateef">{service.description}</p>

                        {/* Key Features - Always Visible */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                          {service.features.slice(0, 4).map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center space-x-3 space-x-reverse">
                              <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                              <span className="text-gray-700 font-lateef">{feature}</span>
                            </div>
                          ))}
                        </div>

                        {/* Expandable Content */}
                        {isExpanded && (
                          <div className="border-t pt-8 mt-8 space-y-6">
                            {service.features.length > 4 && (
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {service.features.slice(4).map((feature, featureIndex) => (
                                  <div key={featureIndex} className="flex items-center space-x-3 space-x-reverse">
                                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                                    <span className="text-gray-700 font-lateef">{feature}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-gray-50 rounded-lg p-6">
                              <div>
                                <h4 className="font-lalezar text-gray-900 mb-2">مدت زمان</h4>
                                <p className="text-gray-600 font-lateef persian-numbers">{service.duration}</p>
                              </div>
                              <div>
                                <h4 className="font-lalezar text-gray-900 mb-2">هزینه</h4>
                                <p className="text-gray-600 font-lateef persian-numbers">{service.price}</p>
                              </div>
                              <div>
                                <h4 className="font-lalezar text-gray-900 mb-2">شامل</h4>
                                <ul className="text-gray-600 text-sm space-y-1 font-lateef">
                                  {service.included.map((item, i) => (
                                    <li key={i}>• {item}</li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Action Buttons */}
                        <div className="flex flex-col sm:flex-row gap-4 mt-8">
                          <button
                            onClick={() => setIsBookingOpen(true)}
                            className="bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white px-6 py-2 rounded-lg font-lateef text-lg transition-all duration-200 flex items-center justify-center space-x-2 space-x-reverse"
                          >
                            <span>رزرو مشاوره</span>
                            <ArrowLeft className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => toggleExpand(index)}
                            className="border-2 border-gray-300 hover:border-blue-500 hover:text-blue-600 text-gray-700 px-6 py-2 rounded-lg font-lateef text-lg transition-all duration-200"
                          >
                            {isExpanded ? 'کمتر نشان بده' : 'جزئیات بیشتر'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-800 to-emerald-600 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="text-3xl lg:text-4xl font-lalezar mb-6">
            آماده شروع مسیر تحصیل در ایتالیا هستید؟
          </h2>
          <p className="text-xl text-blue-100 mb-8 font-lateef">
            با تیم متخصص ما مشورت کنید و بهترین راه را برای رسیدن به هدفتان انتخاب کنید
          </p>
          <button
            onClick={() => setIsBookingOpen(true)}
            className="bg-white hover:bg-gray-100 text-blue-800 px-6 py-3 rounded-lg font-lateef text-xl transition-all duration-200 inline-flex items-center space-x-3 space-x-reverse"
          >
            <span>مشاوره رایگان رزرو کنید</span>
            <ArrowLeft className="h-5 w-5" />
          </button>
        </div>
      </section>

      <BookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} />
    </div>
  );
};

export default ServicesPage;