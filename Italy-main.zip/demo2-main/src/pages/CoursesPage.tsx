import React, { useState } from 'react';
import { Clock, Users, Award, Calendar, ArrowLeft, CheckCircle } from 'lucide-react';

// Utility function to convert numbers to Farsi digits
const toFarsiNumber = (num: string | number) => {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(num).replace(/[0-9]/g, (w) => farsiDigits[parseInt(w)]);
};

const CoursesPage = () => {
  const [selectedCourse, setSelectedCourse] = useState<number | null>(null);
  const [enrollForm, setEnrollForm] = useState({
    courseId: '',
    name: '',
    email: '',
    phone: '',
    level: '',
    message: ''
  });
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [enrollSuccess, setEnrollSuccess] = useState(false);

  const courses = [
    {
      id: 'italian-a1',
      title: 'کلاس زبان ایتالیایی سطح A1',
      subtitle: 'برای مبتدیان کامل',
      description: 'این دوره برای افرادی طراحی شده که هیچ پیش‌زمینه‌ای از زبان ایتالیایی ندارند. شامل آموزش حروف الفبا، واژگان پایه، و مکالمات ساده روزانه.',
      level: 'مبتدی',
      duration: '۳ ماه',
      sessions: '۲۴ جلسه (هفته‌ای ۲ جلسه)',
      price: `${toFarsiNumber('1500000')} تومان`,
      discount: '۲۰٪ تخفیف ثبت‌نام زودهنگام',
      features: [
        'آموزش حروف الفبا و تلفظ',
        'واژگان پایه و کاربردی',
        'گرامر مقدماتی',
        'مکالمات ساده روزانه',
        'تمرینات تعاملی آنلاین',
        'آزمون‌های مرحله‌ای',
        'گواهی پایان دوره',
        'پشتیبانی در طول دوره'
      ],
      schedule: [
        'دوشنبه و چهارشنبه ۱۸:۰۰-۱۹:۳۰',
        'شنبه و دوشنبه ۱۰:۰۰-۱۱:۳۰',
        'سه‌شنبه و پنج‌شنبه ۲۰:۰۰-۲۱:۳۰'
      ],
      nextStart: '۱۵ اسفند ۱۴۰۳'
    },
    {
      id: 'italian-a2',
      title: 'کلاس زبان ایتالیایی سطح A2',
      subtitle: 'پایه‌ای متوسط',
      description: 'برای دانشجویانی که سطح A1 را گذرانده‌اند. تمرکز بر توسعه مهارت‌های مکالمه و درک مطلب با موضوعات روزمره.',
      level: 'پایه‌ای',
      duration: '۴ ماه',
      sessions: '۳۲ جلسه (هفته‌ای ۲ جلسه)',
      price: `${toFarsiNumber('1800000')} تومان`,
      discount: '۱۵٪ تخفیف برای دانشجویان سطح A1',
      features: [
        'توسعه مهارت‌های مکالمه',
        'گرامر متوسط',
        'درک مطالب ساده',
        'نوشتار پایه',
        'موضوعات فرهنگی ایتالیا',
        'تمرین‌های گروهی',
        'آزمون‌های ماهانه',
        'منابع آموزشی تکمیلی'
      ],
      schedule: [
        'یکشنبه و سه‌شنبه ۱۷:۳۰-۱۹:۰۰',
        'شنبه و چهارشنبه ۱۴:۰۰-۱۵:۳۰',
        'دوشنبه و پنج‌شنبه ۱۹:۰۰-۲۰:۳۰'
      ],
      nextStart: '۱ فروردین ۱۴۰۴'
    },
    {
      id: 'italian-b1',
      title: 'کلاس زبان ایتالیایی سطح B1',
      subtitle: 'متوسط',
      description: 'دوره متوسط برای تقویت مهارت‌های زبانی و آمادگی برای زندگی و تحصیل در ایتالیا. شامل مکالمات پیچیده‌تر و موضوعات تخصصی.',
      level: 'متوسط',
      duration: '۵ ماه',
      sessions: '۴۰ جلسه (هفته‌ای ۲ جلسه)',
      price: `${toFarsiNumber('2200000')} تومان`,
      discount: 'پرداخت نقدی ۱۰٪ تخفیف',
      features: [
        'مکالمات پیچیده',
        'درک متون تخصصی',
        'نوشتار رسمی و غیررسمی',
        'گرامر پیشرفته',
        'آشنایی با فرهنگ ایتالیا',
        'شبیه‌سازی موقعیت‌های واقعی',
        'آمادگی برای آزمون CILS B1',
        'کلاس‌های تمرینی اضافه'
      ],
      schedule: [
        'شنبه و دوشنبه ۱۶:۰۰-۱۷:۳۰',
        'یکشنبه و چهارشنبه ۱۸:۳۰-۲۰:۰۰',
        'سه‌شنبه و جمعه ۱۰:۳۰-۱۲:۰۰'
      ],
      nextStart: '۱۵ فروردین ۱۴۰۴'
    },
    {
      id: 'cils-prep',
      title: 'دوره آمادگی آزمون CILS',
      subtitle: 'تضمین موفقیت در آزمون',
      description: 'دوره جامع آمادگی برای آزمون CILS تمام سطوح. شامل استراتژی‌های آزمون، تمرینات تخصصی، و آزمون‌های تجربی متعدد.',
      level: 'همه سطوح',
      duration: '۳ ماه',
      sessions: '۲۴ جلسه + ۸ جلسه آزمون تجربی',
      price: `${toFarsiNumber('2500000')} تومان`,
      discount: 'ضمانت بازپرداخت در صورت عدم قبولی',
      features: [
        'آشنایی کامل با ساختار آزمون',
        'تمرین تمام بخش‌های آزمون',
        '۸ آزمون تجربی کامل',
        'تحلیل عملکرد فردی',
        'استراتژی‌های پاسخ‌گویی',
        'تمرین مهارت listening',
        'تکنیک‌های writing',
        'شبیه‌سازی شرایط آزمون واقعی'
      ],
      schedule: [
        'شنبه و یکشنبه ۱۵:۰۰-۱۷:۰۰',
        'دوشنبه و سه‌شنبه ۱۹:۳۰-۲۱:۳۰',
        'چهارشنبه و پنج‌شنبه ۱۷:۰۰-۱۹:۰۰'
      ],
      nextStart: '۱ بهمن ۱۴۰۳'
    },
    {
      id: 'embassy-interview',
      title: 'ورکشاپ مصاحبه سفارت',
      subtitle: 'آمادگی کامل برای مصاحبه ویزا',
      description: 'ورکشاپ تخصصی برای آمادگی مصاحبه سفارت ایتالیا. شامل شبیه‌سازی کامل، تحلیل نقاط قوت و ضعف، و راهنمایی‌های عملی.',
      level: 'همه سطوح',
      duration: '۱ ماه',
      sessions: '۸ جلسه (هفته‌ای ۲ جلسه)',
      price: `${toFarsiNumber('1200000')} تومان`,
      discount: 'گروهی ۲۵٪ تخفیف',
      features: [
        'شبیه‌سازی کامل مصاحبه',
        'بررسی سوالات متداول',
        'تمرین پاسخ‌گویی مؤثر',
        'آموزش زبان بدن',
        'تحلیل ضعف‌ها و تقویت آن‌ها',
        'ضبط ویدیو برای بررسی',
        'راهنمای کامل آمادگی',
        'پیگیری تا زمان مصاحبه'
      ],
      schedule: [
        'شنبه و چهارشنبه ۱۴:۰۰-۱۶:۰۰',
        'دوشنبه و پنج‌شنبه ۱۸:۰۰-۲۰:۰۰',
        'یکشنبه و سه‌شنبه ۱۶:۳۰-۱۸:۳۰'
      ],
      nextStart: '۲۰ بهمن ۱۴۰۳'
    },
    {
      id: 'music-italian',
      title: 'زبان ایتالیایی تخصصی موسیقی',
      subtitle: 'ویژه دانشجویان موسیقی',
      description: 'دوره تخصصی زبان ایتالیایی برای دانشجویان موسیقی. شامل اصطلاحات موسیقایی، تاریخ موسیقی ایتالیا، و مکالمات تخصصی.',
      level: 'متوسط به بالا',
      duration: '۴ ماه',
      sessions: '۳۲ جلسه (هفته‌ای ۲ جلسه)',
      price: `${toFarsiNumber('2800000')} تومان`,
      discount: 'ویژه دانشجویان موسیقی',
      features: [
        'اصطلاحات موسیقی ایتالیایی',
        'تاریخ موسیقی کلاسیک ایتالیا',
        'مکالمه با اساتید موسیقی',
        'خواندن متون موسیقایی',
        'آشنایی با کنسرواتوارها',
        'شرح‌حال آهنگسازان مشهور',
        'واژگان تخصصی سازها',
        'شبیه‌سازی کلاس‌های موسیقی'
      ],
      schedule: [
        'یکشنبه و چهارشنبه ۱۵:۳۰-۱۷:۳۰',
        'شنبه و سه‌شنبه ۱۷:۳۰-۱۹:۳۰',
        'دوشنبه و پنج‌شنبه ۱۴:۰۰-۱۶:۰۰'
      ],
      nextStart: '۱۰ اسفند ۱۴۰۳'
    }
  ];

  const handleEnrollment = async (courseId: string) => {
    setEnrollForm({ ...enrollForm, courseId });
    setSelectedCourse(courses.findIndex(course => course.id === courseId));
  };

  const handleEnrollSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsEnrolling(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      console.log('Enrollment submitted:', enrollForm);
      setEnrollSuccess(true);
      setTimeout(() => {
        setEnrollSuccess(false);
        setSelectedCourse(null);
        setEnrollForm({
          courseId: '',
          name: '',
          email: '',
          phone: '',
          level: '',
          message: ''
        });
      }, 3000);
    } catch (error) {
      console.error('Enrollment error:', error);
    } finally {
      setIsEnrolling(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setEnrollForm({
      ...enrollForm,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="pt-20 pb-16 font-lateef font-bold" dir="rtl">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-emerald-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-lalezar mb-6">
            دوره‌های آموزشی ما
          </h1>
          <p className="text-2xl lg:text-3xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
            از مبتدی تا پیشرفته، تمام دوره‌هایی که برای تحصیل در ایتالیا نیاز دارید
          </p>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {courses.map((course, index) => (
              <div key={course.id} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="p-8">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div className="flex-1">
                      <span className="inline-block bg-blue-100 text-blue-800 text-base px-3 py-1 rounded-full mb-3">
                        {course.level}
                      </span>
                      <h3 className="text-2xl font-lalezar text-gray-900 mb-2">{course.title}</h3>
                      <p className="text-lg text-gray-600 mb-4">{course.subtitle}</p>
                    </div>
                    <div className="text-right ml-4">
                      <div className="text-3xl font-lalezar text-gray-900">{course.price}</div>
                      {course.discount && (
                        <div className="text-base text-green-600">{course.discount}</div>
                      )}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-lg text-gray-700 leading-relaxed mb-6">{course.description}</p>

                  {/* Course Info */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Clock className="h-5 w-5 text-gray-500" />
                      <span className="text-base text-gray-700">{course.duration}</span>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Users className="h-5 w-5 text-gray-500" />
                      <span className="text-base text-gray-700">{course.sessions}</span>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Calendar className="h-5 w-5 text-gray-500" />
                      <span className="text-base text-gray-700">{course.nextStart}</span>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="mb-8">
                    <h4 className="font-lalezar text-xl text-gray-900 mb-3">شامل:</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {course.features.slice(0, 6).map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2 space-x-reverse">
                          <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                          <span className="text-base text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    {course.features.length > 6 && (
                      <button className="text-blue-600 text-base mt-2 hover:text-blue-800">
                        + {toFarsiNumber(course.features.length - 6)} مورد دیگر
                      </button>
                    )}
                  </div>

                  {/* Schedule */}
                  <div className="mb-6">
                    <h4 className="font-lalezar text-xl text-gray-900 mb-2">زمان‌بندی کلاس‌ها:</h4>
                    <div className="space-y-1">
                      {course.schedule.map((time, timeIndex) => (
                        <div key={timeIndex} className="text-base text-gray-600">{time}</div>
                      ))}
                    </div>
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={() => handleEnrollment(course.id)}
                    className="w-full bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 text-white px-6 py-3 rounded-lg font-lalezar text-lg transition-all duration-200 flex items-center justify-center space-x-2 space-x-reverse"
                  >
                    <span>ثبت‌نام در دوره</span>
                    <ArrowLeft className="h-6 w-6" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enrollment Modal */}
      {selectedCourse !== null && (
        <div className="fixed inset-0 z-50 overflow-y-auto" dir="rtl">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setSelectedCourse(null)}></div>

            <div className="inline-block align-bottom bg-white rounded-lg text-right overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              {enrollSuccess ? (
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="text-center">
                    <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
                      <Award className="h-8 w-8 text-green-600" />
                    </div>
                    <h3 className="text-xl font-lalezar text-gray-900 mb-2">ثبت‌نام موفق!</h3>
                    <p className="text-base text-gray-600">
                      درخواست ثبت‌نام شما دریافت شد. به زودی با شما تماس خواهیم گرفت.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-lalezar text-gray-900">
                      ثبت‌نام در {courses[selectedCourse]?.title}
                    </h3>
                    <button
                      onClick={() => setSelectedCourse(null)}
                      className="text-gray-400 hover:text-gray-600 transition-colors duration-200 text-2xl"
                    >
                      ×
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                        نام و نام خانوادگی *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={enrollForm.name}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base font-lateef font-bold"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-base font-medium text-gray-700 mb-1">
                          ایمیل *
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={enrollForm.email}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base font-lateef font-bold"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-base font-medium text-gray-700 mb-1">
                          شماره تماس *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          value={enrollForm.phone}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base font-lateef font-bold"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                        سطح فعلی زبان ایتالیایی
                      </label>
                      <select
                        name="level"
                        value={enrollForm.level}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base font-lateef font-bold"
                      >
                        <option value="">انتخاب کنید</option>
                        <option value="beginner">مبتدی کامل</option>
                        <option value="elementary">مقدماتی</option>
                        <option value="intermediate">متوسط</option>
                        <option value="advanced">پیشرفته</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                        پیام یا سوال (اختیاری)
                      </label>
                      <textarea
                        name="message"
                        value={enrollForm.message}
                        onChange={handleInputChange}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base font-lateef font-bold"
                        placeholder="سوالات یا توضیحات اضافی..."
                      />
                    </div>

                    <div className="flex justify-end space-x-3 space-x-reverse pt-4 border-t">
                      <button
                        type="button"
                        onClick={() => setSelectedCourse(null)}
                        className="px-4 py-2 text-base font-lalezar text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200"
                      >
                        انصراف
                      </button>
                      <button
                        type="submit"
                        disabled={isEnrolling}
                        className="px-6 py-2 text-base font-lalezar text-white bg-gradient-to-r from-blue-600 to-emerald-500 hover:from-blue-700 hover:to-emerald-600 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isEnrolling ? 'در حال ثبت‌نام...' : 'ثبت‌نام'}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-800 to-emerald-600 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="text-4xl lg:text-5xl font-lalezar mb-6">
            سوال یا نیاز به راهنمایی دارید؟
          </h2>
          <p className="text-2xl text-blue-100 mb-8">
            تیم مشاوران ما آماده کمک به شما برای انتخاب بهترین دوره هستند
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white hover:bg-gray-100 text-blue-800 px-8 py-4 rounded-lg font-lalezar text-xl transition-all duration-200">
              مشاوره رایگان
            </button>
            <button className="border-2 border-white hover:bg-white hover:text-blue-800 text-white px-8 py-4 rounded-lg font-lalezar text-xl transition-all duration-200">
              مشاهده تقویم کلاس‌ها
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CoursesPage;