import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Calendar } from 'lucide-react';
import BookingModal from './BookingModal';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [tehranTime, setTehranTime] = useState(new Date());
  const [italyTime, setItalyTime] = useState(new Date());
  const location = useLocation();

  const navigation = [
    { name: 'خانه', href: '/', en: 'Home' },
    { name: 'خدمات', href: '/services', en: 'Services' },
    //{ name: 'دوره‌ها', href: '/courses', en: 'Courses' },
    { name: 'بلاگ', href: '/blog', en: 'Blog' },
    { name: 'درباره ما', href: '/about', en: 'About' },
    { name: 'تماس', href: '/contact', en: 'Contact' },
  ];

  // Update times every second
  useEffect(() => {
    const interval = setInterval(() => {
      setTehranTime(new Date());
      setItalyTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Format time and date for Tehran (Shamsi)
  const formatTehranDateTime = (date: Date) => {
    const options = {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
      timeZone: 'Asia/Tehran',
    };
    return date.toLocaleString('fa-IR', options);
  };

  // Format time and date for Italy (Miladi)
  const formatItalyDateTime = (date) => {
    const options = {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
      timeZone: 'Europe/Rome',
    };
    return date.toLocaleString('it-IT', options);
  };

  const tehranDateTime = formatTehranDateTime(tehranTime);
  const italyDateTime = formatItalyDateTime(italyTime);

  return (
    <>
      {/* Global styles for Lalezar font */}
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Lalezar&display=swap');
          .font-lalezar {
            font-family: 'Lalezar', sans-serif;
          }
        `}
      </style>
      {/* Header section */}
      <header dir="rtl" className="fixed w-full top-0 z-50 bg-white backdrop-blur-sm shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-3 space-x-reverse">
              <img
                src="https://ik.imagekit.io/amirfaramarzpour/Ali%20Mousavi/logo2.png?updatedAt=1758331231902"
                alt="Logo Placeholder"
                className="h-10 w-10 object-contain"
              />
              <div className="text-right">
                <div className="text-xl font-bold text-gray-900 font-lalezar">تحصیل موسیقی در ایتالیا</div>
                <div className="text-sm text-gray-600 font-lalezar">Music Studies in Italy</div>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-16 space-x-reverse">
              {navigation.map((item) => (
                <div key={item.name} className="relative">
                  <Link
                    to={item.href}
                    className={`text-base font-lalezar transition-colors duration-200 hover:text-blue-800 px-4 py-2 ${
                      location.pathname === item.href
                        ? 'text-blue-800 border-b-2 border-blue-800'
                        : 'text-gray-700'
                    }`}
                  >
                    {item.name}
                  </Link>
                  <div className="absolute -bottom-2 left-0 right-0 h-2 bg-transparent" />
                </div>
              ))}
              <div className="relative">
                <button
                  onClick={() => setIsBookingOpen(true)}
                  className="bg-gradient-to-r from-blue-800 to-emerald-600 text-white px-8 py-3 rounded-lg hover:from-blue-900 hover:to-emerald-700 transition-all duration-200 flex items-center space-x-3 space-x-reverse text-base font-lalezar"
                >
                  <Calendar className="h-5 w-5" />
                  <span>رزرو مشاوره رایگان</span>
                </button>
                <div className="absolute -bottom-2 left-0 right-0 h-2 bg-transparent" />
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-700 hover:text-blue-800 transition-colors duration-200"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Time Display Bar */}
          <div className="md:flex hidden bg-white/95 backdrop-blur-sm border-b border-blue-100">
            <div className="flex-1 flex justify-center items-center py-2 space-x-8 space-x-reverse">
              <div className="text-center text-xs font-medium text-gray-700 font-lalezar">
                <div className="flex items-center justify-right space-x-1 space-x-reverse mb-1">
                  <img
                    src="https://flagcdn.com/16x12/ir.png"
                    alt="Iran Flag"
                    className="h-3 w-4 mx-2"
                  />
                  <span>ایران:</span>
                </div>
                <div className="bg-white px-2 py-1 rounded-md shadow-sm">{tehranDateTime}</div>
              </div>
              <div className="text-center text-xs font-medium text-gray-700 font-lalezar">
                <div className="flex items-center justify-right space-x-1 space-x-reverse mb-1">
                  <img
                    src="https://flagcdn.com/16x12/it.png"
                    alt="Italy Flag"
                    className="h-3 w-4 mx-2"
                  />
                  <span>ایتالیا:</span>
                </div>
                <div className="bg-white px-2 py-1 rounded-md shadow-sm">{italyDateTime}</div>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden bg-white/95 backdrop-blur-sm border-t">
              <div className="px-4 pt-4 pb-4 space-y-3">
                {navigation.map((item) => (
                  <div key={item.name} className="relative">
                    <Link
                      to={item.href}
                      className={`block px-4 py-3 rounded-md text-lg font-lalezar transition-colors duration-200 ${
                        location.pathname === item.href
                          ? 'text-blue-800 bg-blue-50'
                          : 'text-gray-700 hover:text-blue-800 hover:bg-gray-50'
                      }`}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                    <div className="absolute -bottom-2 left-0 right-0 h-2 bg-transparent" />
                  </div>
                ))}
                <div className="relative">
                  <button
                    onClick={() => {
                      setIsBookingOpen(true);
                      setIsMenuOpen(false);
                    }}
                    className="w-full mt-3 bg-gradient-to-r from-blue-800 to-emerald-600 text-white px-6 py-3 rounded-lg hover:from-blue-900 hover:to-emerald-700 transition-all duration-200 flex items-center justify-center space-x-3 space-x-reverse text-lg font-lalezar"
                  >
                    <Calendar className="h-5 w-5" />
                    <span>رزرو مشاوره رایگان</span>
                  </button>
                  <div className="absolute -bottom-2 left-0 right-0 h-2 bg-transparent" />
                </div>
              </div>
            </div>
          )}
        </nav>
      </header>
      {/* Booking Modal */}
      <BookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} />
    </>
  );
};

export default Header;