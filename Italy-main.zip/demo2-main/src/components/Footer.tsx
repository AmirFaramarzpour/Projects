import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white rtl font-farsi">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Horizontal Layout */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          {/* Company Info with Logo */}
          <div className="flex items-center space-x-3 space-x-reverse">

            <div>
              <div className="text-lg font-bold font-farsi-display">تحصیل موسیقی در ایتالیا</div>
              <p className="text-gray-400 text-sm leading-relaxed font-farsi-body mt-2">
                راهنمای تخصصی شما برای تحصیل موسیقی در بهترین کنسرواتوارهای ایتالیا. با سال‌ها تجربه در زمینه مشاوره و آموزش.
              </p>
            </div>
          </div>

          {/* Contact Info in a Row */}
          <div className="flex flex-wrap items-center text-sm text-gray-400 font-farsi-body">
            <div className="flex items-center gap-x-1 mx-2">
              <Phone className="h-4 w-4" />
              <span>+98 912 345 6789</span>
            </div>
            <div className="flex items-center gap-x-1 mx-2">
              <Mail className="h-4 w-4" />
              <span>info@musicstudyitaly.com</span>
            </div>
            <div className="flex items-center gap-x-1 mx-2">
              <MapPin className="h-4 w-4" />
              <span>تهران، ایران</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm font-farsi-body">
            © 2025 تحصیل موسیقی در ایتالیا. تمام حقوق محفوظ است. طراحی: <a href="https://amirfaramarzpour.ir" className="underline hover:text-white font-en">Amir</a>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
