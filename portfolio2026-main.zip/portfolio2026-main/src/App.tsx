import { useState, useEffect } from 'react';
import {
  Download,
  Github,
  BookOpen,
  Send,
  Phone,
  MessageCircle,
  Mail,
  Youtube,
  Users,
  Linkedin,
  FileText,
  Star,
  ExternalLink,
  Loader2,
  AlertCircle,
} from 'lucide-react';

// ==========================================
// PLACEHOLDER VALUES - EDIT THESE
// ==========================================
const PLACEHOLDER = {
  // Personal Info
  name: 'Amir Faramarzpour',
  tagline: 'Mineral Processing Engineer (MSc) & Programmer',
  profileImage: 'https://ik.imagekit.io/amirfaramarzpour/AMIR/IMG_20251026_143939.jpg',
  cvLink: 'https://github.com/AmirFaramarzpour/Database/blob/main/CV_Amir_Revised3.pdf',

  // Bio paragraphs
  bioParagraph1: "I'm a mineral processing engineer with a strong academic foundation (MSc, ranked 1st in my cohort) and hands-on industry experience spanning flotation, iron ore and phosphate beneficiation, process control, and Geometallurgical modelling.My career sits at the intersection of traditional mineral processing and data-driven engineering. At Bafgh Mining Company, I increased crushing circuit capacity by 40% and applied Geometallurgical modelling to predict ore behavior before it reached production lines. As a consultant with Terravion Industries in Zambia, I designed flowsheets for complex, low-grade ores and translated technical outcomes into operational training materials — working across cultures and ore types in a fast-paced field environment.",
  bioParagraph2: "On the research side, I've published peer-reviewed work on froth flotation and calcite chemistry, contributed to a university textbook on phosphate ore processing, and actively collaborated on DFT simulation and nanoparticle adsorption studies.Im now building on this foundation with applied machine learning — developing soft sensors and computer vision tools for real-time flotation monitoring using Python, scikit-learn, and OpenCV. My goal is to bridge the gap between process expertise and intelligent automation in mineral processing plants.If you are working on flotation optimization, Geometallurgical, or ML applications in mineral processing, I'd be glad to connect",

  // Google Scholar
  scholarProfileUrl: 'https://scholar.google.com/citations?user=rAaf5VoAAAAJ&hl=en',
  hIndex: 1,
  papers: [
    { title: 'The impacts of treated wastewater on Pb-Zn sulfide flotation performance and potential improvement', year: 2026, url: 'https://doi.org/10.1016/j.wri.2026.100349' },
    { title: 'Calcite in froth flotation-A review', year: 2022, url: 'https://doi.org/10.1016/j.jmrt.2022.05.106' },
    { title: 'Phosphate Ore Processing by Flotation Method', year: 2021, url: 'https://opac.nlai.ir/opac-prod/bibliographic/8442492' },

  ],

  // GitHub
  githubUsername: 'AmirFaramarzpour',
  githubProfileUrl: 'https://github.com/amirfaramarzpour',


  // Social Links
  telegramChannel: 'https://t.me/hotchartmusic',
  telegramId: 'https://t.me/amir_faramarzpour',
  whatsapp: 'https://wa.me/9116812737',
  email: 'amirfaramarzpour@outlook.com',
  youtubeChannel: 'https://youtube.com/@rootkitraven?si=pxnmUb9tneKoXpnK',
  discordServer: 'https://discord.gg/zC4V6TFTjf',
  linkedin: 'https://www.linkedin.com/in/amirfaramarzpour',
  googleForm: 'https://forms.gle/srhAzRgRnnQvj8xQ8',
};

// GitHub Repo Type
interface GitHubRepo {
  id: number;
  name: string;
  description: string | null;
  html_url: string;
  stargazers_count: number;
  language: string | null;
}

// ==========================================
// COMPONENTS
// ==========================================

// Social Link Card Component
function SocialCard({
  icon: Icon,
  label,
  href,
  color = 'bg-green-mid',
}: {
  icon: React.ElementType;
  label: string;
  href: string;
  color?: string;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`group flex items-center gap-3 p-4 rounded-xl bg-white shadow-sm border border-gray-100
        hover:shadow-md hover:border-green-sage/30 transition-all duration-200`}
    >
      <div className={`${color} p-2.5 rounded-lg text-white group-hover:scale-105 transition-transform`}>
        <Icon size={20} />
      </div>
      <span className="font-medium text-slate-dark">{label}</span>
      <ExternalLink size={16} className="ml-auto text-gray-400 group-hover:text-green-mid transition-colors" />
    </a>
  );
}

// Paper Card Component
function PaperCard({ title, year, url }: { title: string; year: number; url: string }) {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="group flex items-start gap-3 p-4 rounded-lg bg-gray-50 hover:bg-white
        hover:shadow-md transition-all duration-200"
    >
      <BookOpen size={20} className="text-green-mid mt-0.5 flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-slate-dark group-hover:text-green-deep transition-colors line-clamp-2">
          {title}
        </h4>
        <span className="text-sm text-gray-500">{year}</span>
      </div>
      <ExternalLink size={16} className="text-gray-400 group-hover:text-green-mid transition-colors flex-shrink-0" />
    </a>
  );
}

// GitHub Repo Card Component
function RepoCard({ repo }: { repo: GitHubRepo }) {
  return (
    <a
      href={repo.html_url}
      target="_blank"
      rel="noopener noreferrer"
      className="group flex flex-col p-5 rounded-xl bg-white shadow-sm border border-gray-100
        hover:shadow-lg hover:border-green-sage/40 transition-all duration-200"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <h3 className="font-semibold text-slate-dark group-hover:text-green-deep transition-colors line-clamp-1">
          {repo.name}
        </h3>
        <div className="flex items-center gap-1 text-yellow-500 flex-shrink-0">
          <Star size={16} fill="currentColor" />
          <span className="text-sm font-medium">{repo.stargazers_count}</span>
        </div>
      </div>
      <p className="text-sm text-gray-600 line-clamp-2 flex-1">
        {repo.description || 'No description available'}
      </p>
      {repo.language && (
        <div className="mt-3 flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-green-sage" />
          <span className="text-xs text-gray-500">{repo.language}</span>
        </div>
      )}
    </a>
  );
}

// ==========================================
// MAIN APP
// ==========================================

function App() {
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [reposLoading, setReposLoading] = useState(true);
  const [reposError, setReposError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchRepos() {
      try {
        const response = await fetch(
          `https://api.github.com/users/${PLACEHOLDER.githubUsername}/repos?sort=updated&per_page=`
        );
        if (!response.ok) {
          if (response.status === 404) {
            throw new Error('GitHub user not found');
          }
          if (response.status === 403) {
            throw new Error('GitHub API rate limit reached. Please try again later.');
          }
          throw new Error('Failed to fetch repositories');
        }
        const data = await response.json();
        setRepos(data);
      } catch (err) {
        setReposError(err instanceof Error ? err.message : 'Failed to fetch repositories');
      } finally {
        setReposLoading(false);
      }
    }

    fetchRepos();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-green-sage/10">
      {/* Container */}
      <div className="max-w-4xl mx-auto px-4 py-12 md:py-20">

        {/* HERO SECTION */}
        <section className="text-center mb-16 md:mb-24">
          {/* Profile Image */}
          <div className="relative inline-block mb-6">
            <div className="w-36 h-36 md:w-44 md:h-44 rounded-full overflow-hidden ring-4 ring-white shadow-xl">
              <img
                src={PLACEHOLDER.profileImage}
                alt={PLACEHOLDER.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-2 -right-2 bg-green-mid text-white p-2 rounded-full shadow-lg">
              <BookOpen size={16} />
            </div>
          </div>

          {/* Name & Tagline */}
          <h1 className="text-3xl md:text-4xl font-bold text-slate-dark mb-2">
            {PLACEHOLDER.name}
          </h1>
          <p className="text-lg md:text-xl text-green-deep font-medium mb-6">
            {PLACEHOLDER.tagline}
          </p>

          {/* Bio */}
          <div className="max-w-2xl mx-auto space-y-4 text-gray-600 leading-relaxed mb-8">
            <p className="text-justify">{PLACEHOLDER.bioParagraph1}</p>
            <p className="text-justify">{PLACEHOLDER.bioParagraph2}</p>
          </div>

          {/* Download CV Button */}
          <a
            href={PLACEHOLDER.cvLink}
            download
            className="inline-flex items-center gap-2 px-6 py-3 bg-green-mid text-white font-semibold
              rounded-xl shadow-lg hover:bg-green-deep transform hover:-translate-y-0.5
              transition-all duration-200"
          >
            <Download size={20} />
            Download CV
          </a>
        </section>

        {/* GITHUB SECTION */}
        <section className="mb-16 md:mb-24">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-gray-900 rounded-lg text-white">
                  <Github size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-dark">GitHub Repositories</h2>
                  <p className="text-sm text-gray-500">{PLACEHOLDER.githubUsername}</p>
                </div>
              </div>
              <a
                href={PLACEHOLDER.githubProfileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-green-sage/20
                  text-slate-dark rounded-lg font-medium transition-colors"
              >
                <Github size={18} />
                <span className="hidden sm:inline">Profile</span>
                <ExternalLink size={16} />
              </a>
            </div>

            {/* Repos Grid */}
            {reposLoading ? (
              <div className="flex items-center justify-center py-12 text-green-mid">
                <Loader2 className="animate-spin mr-2" size={24} />
                <span>Loading repositories...</span>
              </div>
            ) : reposError ? (
              <div className="flex items-center justify-center py-12 text-red-500">
                <AlertCircle className="mr-2" size={20} />
                <span>{reposError}</span>
              </div>
            ) : repos.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                No public repositories found
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {repos.map((repo) => (
                  <RepoCard key={repo.id} repo={repo} />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* GOOGLE SCHOLAR SECTION */}
        <section className="mb-16 md:mb-24">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-green-deep rounded-lg text-white">
                  <BookOpen size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-dark">Google Scholar</h2>
                  <p className="text-sm text-gray-500">Academic Publications</p>
                </div>
              </div>
              <a
                href={PLACEHOLDER.scholarProfileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-green-sage/20
                  text-slate-dark rounded-lg font-medium transition-colors"
              >
                <BookOpen size={18} />
                <span className="hidden sm:inline">Profile</span>
                <ExternalLink size={16} />
              </a>
            </div>

            {/* H-Index Badge */}
            <div className="flex items-center gap-4 mb-6 p-4 bg-gradient-to-r from-green-deep/5 to-green-sage/10 rounded-xl">
              <div className="text-center">
                <div className="text-4xl font-bold text-green-deep">{PLACEHOLDER.hIndex}</div>
                <div className="text-sm text-gray-600 font-medium">H-Index</div>
              </div>
              <div className="h-12 w-px bg-gray-200" />
              <div className="flex-1">
                <p className="text-gray-600">
                  Citations : 53 Since 2021
                </p>
              </div>
            </div>

            {/* Papers List */}
            <div className="space-y-3">
              {PLACEHOLDER.papers.map((paper, index) => (
                <PaperCard key={index} {...paper} />
              ))}
            </div>
          </div>
        </section>

        {/* CONNECT / SOCIALS SECTION */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-slate-dark mb-2">Connect</h2>
            <p className="text-gray-600">Reach out through any of these channels</p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <SocialCard
              icon={Send}
              label="Telegram Channel"
              href={PLACEHOLDER.telegramChannel}
              color="bg-blue-500"
            />
            <SocialCard
              icon={Phone}
              label="Telegram ID"
              href={PLACEHOLDER.telegramId}
              color="bg-blue-500"
            />
            <SocialCard
              icon={MessageCircle}
              label="WhatsApp"
              href={PLACEHOLDER.whatsapp}
              color="bg-green-500"
            />
            <SocialCard
              icon={Mail}
              label="Email"
              href={`mailto:${PLACEHOLDER.email}`}
              color="bg-red-500"
            />
            <SocialCard
              icon={Youtube}
              label="YouTube Channel"
              href={PLACEHOLDER.youtubeChannel}
              color="bg-red-600"
            />
            <SocialCard
              icon={Users}
              label="Discord Server"
              href={PLACEHOLDER.discordServer}
              color="bg-indigo-500"
            />
            <SocialCard
              icon={Linkedin}
              label="LinkedIn"
              href={PLACEHOLDER.linkedin}
              color="bg-blue-600"
            />
            <SocialCard
              icon={FileText}
              label="Contact Form"
              href={PLACEHOLDER.googleForm}
              color="bg-green-mid"
            />
          </div>
        </section>
      </div>
    </div>
  );
}

export default App;
