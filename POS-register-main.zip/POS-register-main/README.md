# Fahrenheit Café — Waiter Ordering App

سیستم ثبت سفارش گارسون برای کافه فارنهایت.

## Fixes applied

1. **`window.storage` → `localStorage`**  
   The original used a non-browser API. Persistence now works in any normal website via `localStorage`.

2. **Stable menu item IDs**  
   IDs were generated with `uid()` on every load, so favorites broke after refresh. IDs are now derived from category + index + name.

3. **Order screen layout**  
   Missing closing `</div>` nested the order panel inside the menu column. Panel is now a proper sibling so the desktop 2-column grid works.

4. **Storage key** bumped to `fahrenheit-cafe-state-v3` (new ID scheme).

## Run locally

```bash
cd fahrenheit-cafe
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

## Production build

```bash
npm run build
```

Output is in `dist/`. Serve that folder with any static host (Nginx, Vercel, Netlify, GitHub Pages, etc.).

## Stack

- React 18
- Vite 5
- No backend — all state in `localStorage`
- RTL Persian UI (Vazirmatn font)
