import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";

/* ============================================================
   FAHRENHEIT CAFÉ — Waiter Ordering App (v2)
   Dark theme: near-black green background, gold accents,
   green = available, orange = active order.
   ============================================================ */

const THEME = {
  bg: "#0D1512",
  bgHeader: "linear-gradient(180deg,#132019 0%,#0D1512 100%)",
  card: "#152520",
  cardAlt: "#101B16",
  border: "rgba(233,224,201,0.09)",
  borderStrong: "rgba(233,224,201,0.16)",
  green: "#3FA66B",
  greenSoft: "rgba(63,166,107,0.16)",
  orange: "#E0932E",
  orangeSoft: "rgba(224,147,46,0.16)",
  gold: "#D9A94E",
  goldSoft: "rgba(217,169,78,0.16)",
  goldDeep: "#B9862E",
  cream: "#F2ECDC",
  text: "#F2ECDC",
  textSoft: "#9BA79C",
  textFaint: "#71806F",
  danger: "#E2624B",
  dangerSoft: "rgba(226,98,75,0.14)",
};

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap');`;

/* ---------- Helpers ---------- */
const fmt = (n) => `${Math.round(n).toLocaleString("fa-IR")} تومان`;
const uid = (p = "id") => `${p}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
const two = (n) => String(n).padStart(2, "0");
const timeStr = (d) => `${two(d.getHours())}:${two(d.getMinutes())}`;
const dateKey = (d) => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
const persianDate = (d) => {
  try {
    return new Intl.DateTimeFormat("fa-IR-u-ca-persian", { weekday: "long", day: "numeric", month: "long" }).format(d);
  } catch (e) {
    return d.toLocaleDateString();
  }
};

/* ============================================================
   MENU DATA — imported exactly from the café's App.tsx source
   pricing: { type:"single", price } | { type:"variant", prices:{hr,commercial,special} }
   ============================================================ */
const CATEGORIES = [
  { id: "espresso-based", label: "اسپرسو بار" },
  { id: "brewed-coffee", label: "قهوه های دمی" },
  { id: "hot-drinks", label: "نوشیدنی های گرم" },
  { id: "tea", label: "چای و دمنوش" },
  { id: "cold-espresso", label: "نوشیدنی های سرد بر پایه اسپرسو" },
  { id: "machabar", label: "ماچا بار" },
  { id: "milkshakes", label: "میلک شیک ها" },
  { id: "smoothies", label: "اسموتی ها" },
  { id: "flavored-milk", label: "شیر طعم دار" },
  { id: "cold-drinks", label: "نوشیدنی های سرد" },
  { id: "icecream", label: "بستنی", note: "همگی قیمت‌ها برای یک اسکوپ بستنی لحاظ شده است." },
  { id: "waffle", label: "وافل" },
  { id: "special", label: "آیتم‌های ویژه" },
];

const V = (hr, commercial, special) => ({ type: "variant", prices: { hr, commercial, special } });
const S = (price) => ({ type: "single", price });

const RAW_MENU = [
  // اسپرسو بار
  ["espresso-based", "اسپرسو سولو", "", V(120, 130, 150)],
  ["espresso-based", "اسپرسو دوپیو", "", V(145, 160, 185)],
  ["espresso-based", "آمریکانو", "اسپرسو- آب جوش", V(150, 165, 190)],
  ["espresso-based", "آمریکانو شیرعسلی", "اسپرسو- آب جوش- شیر عسلی", V(180, 195, 220)],
  ["espresso-based", "لاته", "اسپرسو- شیر- فوم شیر", V(220, 240, 280)],
  ["espresso-based", "لاته نوتلا", "اسپرسو- شیر- فوم شیر- نوتلا", V(255, 275, 310)],
  ["espresso-based", "لاته کارامل", "اسپرسو- شیر- فوم شیر- کارامل", V(240, 260, 300)],
  ["espresso-based", "لاته عسل دارچین", "اسپرسو- شیر- فوم شیر- عسل- دارچین", V(255, 275, 310)],
  ["espresso-based", "کوکولاته", "اسپرسو- شیر- فوم شیر- سیروپ نارگیل- پودر نارگیل", V(255, 275, 310)],
  ["espresso-based", "موکا", "اسپرسو- شیر- فوم شیر- سیروپ شکلات- سس شکلات", V(240, 260, 300)],
  ["espresso-based", "کاپوچینو", "اسپرسو- شیر- فوم شیر زیاد", V(210, 220, 290)],
  ["espresso-based", "کورتادو", "اسپرسو- شیر", V(200, 210, 280)],

  // قهوه های دمی
  ["brewed-coffee", "وی60", "", S(260)],
  ["brewed-coffee", "ترک", "", S(180)],
  ["brewed-coffee", "فرانسه", "", S(200)],
  ["brewed-coffee", "پرشین", "قهوه اصیل ایرانی به همراه هل و زعفران- شیرزعفران", S(210)],

  // نوشیدنی های گرم
  ["hot-drinks", "هات لوتوس", "کرم لوتوس- شکلات سفید- شیر- فوم شیر", S(380)],
  ["hot-drinks", "هات پسته", "کرم پسته- پودر پسته- شکلات سفید- شیر- فوم شیر", S(390)],
  ["hot-drinks", "هات پینات", "کره بادام زمینی- بادام زمینی- شکلات دارک- شیر- فوم شیر", S(340)],
  ["hot-drinks", "هات زعفران", "زعفران- پودر هل- شکلات سفید- شیر- فوم شیر", S(270)],
  ["hot-drinks", "ماسالا", "ترکیبی از ادویه های هندی باطبع گرم- شیر- فوم شیر", S(265)],
  ["hot-drinks", "هات چاکلت", "پودر شکلات- شکلات رنده شده- شیر- فوم شیر", S(265)],
  ["hot-drinks", "هات چاکلت مارشملو", "پودر شکلات- شکلات رنده شده- مارشمالو- شیر- فوم شیر", S(310)],
  ["hot-drinks", "هات چاکلت فندق", "پودر شکلات- شکلات فندق- فندق- شیر- فوم شیر", S(310)],
  ["hot-drinks", "هات چاکلت بستنی", "پودر شکلات- شکلات رنده شده- شیر- بستنی وانیلی", S(310)],
  ["hot-drinks", "شیر کاکائو", "پودر کاکائو- شیر- شکر", S(250)],
  ["hot-drinks", "شیر گرم", "", S(120)],
  ["hot-drinks", "شیر دارچین", "", S(120)],
  ["hot-drinks", "شیر کارامل", "", S(150)],
  ["hot-drinks", "شیر زعفران", "", S(155)],
  ["hot-drinks", "شیر نوتلا", "", S(170)],
  ["hot-drinks", "شیر بادام زمینی", "شیر- بادام زمینی", S(170)],

  // چای و دمنوش
  ["tea", "چای سیاه", "", S(95)],
  ["tea", "چای هلو", "چای سیاه آسام- هلو- زردآلو", S(140)],
  ["tea", "چای سبز لوندر", "چای سبز اعلاء- لوندر", S(140)],
  ["tea", "کوئین بری", "توت فرنگی- کرن بری- گل های معطر- زرشک وحشی", S(165)],
  ["tea", "استرابری کیس", "توت فرنگی- انبه- آناناس- سیب- آلوئه‌ورا- پاپایا- شیرین بیان", S(165)],
  ["tea", "گلدن وانیلا", "سیب- وانیل- میخک- شیرین بیان- دارچین", S(165)],
  ["tea", "اپل پارادایس", "سیب، به- دارچین", S(165)],
  ["tea", "مولن روژ", "به- ریشه چغندر- گل رز- گل ختمی", S(165)],
  ["tea", "ویکتوریا سان ست", "زردچوبه- زنجبیل- فلفل سیاه- دارچین", S(165)],
  ["tea", "لمون گرس", "لمون گرس- زنجبیل- نعنا", S(165)],
  ["tea", "چای لاهیجان", "چای سیاه دستچین لاهیجان", S(110)],
  ["tea", "چای زعفران", "چای سیاه- زعفران", S(120)],
  ["tea", "چای مراکشی", "چای سیاه- نعنا- نبات", S(140)],

  // نوشیدنی های سرد بر پایه اسپرسو
  ["cold-espresso", "آیس آمریکانو", "اسپرسو- آب، یخ", V(150, 165, 190)],
  ["cold-espresso", "آیس رومانو تونیک", "اسپرسو- سیروپ لیمو- آب لیمو- آب گازدار", V(280, 295, 325)],
  ["cold-espresso", "آیس لاته", "اسپرسو- شیر- یخ", V(220, 240, 280)],
  ["cold-espresso", "آیس موکا", "اسپرسو- شیر- سیروپ شکلات- یخ", V(240, 260, 300)],
  ["cold-espresso", "آیس لاته کارامل", "اسپرسو- شیر- سیروپ کارامل- یخ", V(240, 260, 300)],
  ["cold-espresso", "فراپه کارامل", "اسپرسو- شیر- یک اسکوپ بستنی- سیروپ کارامل- یخ", S(280)],
  ["cold-espresso", "فراپه فندق", "اسپرسو- شیر- یک اسکوپ بستنی- سیروپ فندق- یخ", S(280)],
  ["cold-espresso", "فراپه شکلات", "اسپرسو- شیر- یک اسکوپ بستنی- سیروپ شکلات- یخ", S(280)],
  ["cold-espresso", "آفوگاتو", "اسپرسو- یک اسکوپ بستنی", S(225)],
  ["cold-espresso", "آفوگاتو نوتلا (شکلات فندقی)", "اسپرسو- یک اسکوپ بستنی- شکلات فندقی", S(265)],
  ["cold-espresso", "آفوگاتو لوتوس", "اسپرسو- یک اسکوپ بستنی- کرم لوتوس- بیسکوئیت لوتوس", S(265)],
  ["cold-espresso", "آفوگاتو پسته", "اسپرسو- یک اسکوپ بستنی- کره پسته- پودر پسته", S(265)],

  // ماچا بار
  ["machabar", "لاته ماچا", "پودر چای ماچا- شیر- فوم شیر", S(285)],
  ["machabar", "آیس ماچا", "ماچا- شیر- یخ", S(285)],
  ["machabar", "منگو ماچا", "ماچا- شیر- پوره انبه", S(340)],
  ["machabar", "ماچا بری", "ماچا- شیر- پوره توت فرنگی", S(340)],
  ["machabar", "ماچا رویا", "", S(305)],

  // میلک شیک ها
  ["milkshakes", "شیک نوتلا", "بستنی شکلاتی- نوتلا", S(380)],
  ["milkshakes", "شیک لوتوس", "بستنی وانیلی- کرم لوتوس", S(380)],
  ["milkshakes", "شیک پینات بِری", "بستی کاراملی- کره بادام زمینی- پوره توت فرنگی", S(320)],
  ["milkshakes", "شیک چابانا", "بستنی شکلاتی- موز- شکلات", S(380)],
  ["milkshakes", "شیک استوایی", "بستنی وانیلی- توت فرنگی- هلو- انبه- آناناس- نارگیل", S(380)],
  ["milkshakes", "شیک بری", "بستنی وانیلی- توت فرنگی - شاه توت", S(380)],
  ["milkshakes", "شیک منگونات", "بستنی وانیلی- کره پسته- انبه- نارگیل", S(430)],
  ["milkshakes", "شیک چوکونات", "بستنی شکلاتی- کره بادام زمینی- بادام زمینی- شکلات", S(300)],
  ["milkshakes", "شیک نسکافه", "بستنی وانیلی- پودر قهوه", S(290)],
  ["milkshakes", "شیک لواشک", "بستنی ترش- آب آلبالو، لواشک", S(330)],

  // اسموتی ها
  ["smoothies", "مِلون بِری", "هندوانه- گلاب- لیمو- شاه‌توت- شکر", S(280)],
  ["smoothies", "دراگون", "انبه- آب انبه- شاه‌توت- آب شاه‌توت", S(370)],
  ["smoothies", "آمور", "توت فرنگی- شاه‌توت- آلبالو- آناناس- هلو- آب اناز", S(340)],
  ["smoothies", "گرین آیلند", "طالبی- آب آلوئه‌ورا- نارگیل", S(290)],
  ["smoothies", "کوکوکیس", "انبه- آناناس- نارگیل- هلو- آب آناناس", S(330)],

  // شیر طعم دار
  ["flavored-milk", "شیر موز", "", S(230)],
  ["flavored-milk", "شیر موز پسته", "شیر- موز- کره پسته- پودر پسته", S(270)],
  ["flavored-milk", "شیر پسته", "شیر- پسته- پودر پسته", S(290)],
  ["flavored-milk", "شیر انبه", "شیر- میوه طبیعی انبه", S(240)],
  ["flavored-milk", "شیر موز انبه", "شیر- میوه های طبیعی موز و انبه", S(290)],

  // نوشیدنی های سرد
  ["cold-drinks", "موهیتو", "لیمو- نعنا فلفلی- سودا", S(260)],
  ["cold-drinks", "رد موهیتو", "لیمو- نعنا فلفلی- پوره توت فرنگی- سیروپ کرن بری- سودا", S(290)],
  ["cold-drinks", "لیموناد", "لیمو- سیروپ لیمو- سودا", S(230)],
  ["cold-drinks", "دراگون فلای", "پوره دراگون فروت- پوره توت فرنگی- لیمو- آب انبه- آب پرتغال- سیروپ پشن فروت- سودا", S(330)],
  ["cold-drinks", "کوکو بلو", "آب آناناس- آب نارگیل- آب آلوئورا- اسپرولینا- سودا", S(300)],
  ["cold-drinks", "بلواسکای", "لیمو- آب آناناس- آب پرتغال- سیروپ بلوکارسائو- سودا", S(290)],

  // بستنی — همه ۸۰ تومان
  ["icecream", "یک اسکوپ بستنی وانیلی", "", S(80)],
  ["icecream", "یک اسکوپ بستنی شکلات تکه‌ای", "", S(80)],
  ["icecream", "یک اسکوپ بستنی کارامل", "", S(80)],
  ["icecream", "یک اسکوپ بستنی استوایی", "", S(80)],
  ["icecream", "یک اسکوپ بستنی معجون ترش", "", S(80)],
  ["icecream", "یک اسکوپ بستنی زعفران پسته", "", S(80)],
  ["icecream", "یک اسکوپ بستنی شکلات کارامل", "", S(80)],

  // وافل
  ["waffle", "وافل فارنهایت", "وافل- میوه فصل- مغزیجات- یک اسکوپ بستنی و یک تاپینگ به دلخواه", S(390), true],
  ["waffle", "پینات کلاب", "دو عدد وافل- کره بادام زمینی- بادام زمینی", S(330)],
  ["waffle", "فروتی نات", "دو عدد وافل- کره بادام زمینی- بادام زمینی- میوه فصل", S(370)],
  ["waffle", "نوتلا کلاب", "دو عدد وافل- نوتلا- فندق", S(330)],
  ["waffle", "فروتی‌لا", "دو عدد وافل- نوتلا- فندق- میوه فصل", S(370)],
  ["waffle", "لوتوس کلاب", "دو عدد وافل- کرم لوتوس- پرک بادام درختی", S(330)],
  ["waffle", "بیسکوفروت", "دو عدد وافل- کرم لوتوس- پرک بادام درختی- میوه فصل", S(370)],

  // آیتم‌های ویژه
  ["special", "شوکوبری پسته", "توت فرنگی- سس شکلات- یک اسکوپ بستنی- کره پسته- پودر پسته- شعریه", S(480)],
  ["special", "شوکوبری", "توت فرنگی- سس شکلات- یک اسکوپ بستنی", S(430)],
  ["special", "اسپیرولینا بری", "اسپیرولینا- شیر- پوره توت فرنگی", S(330)],
  ["special", "شوکوبری نوتلا", "توت فرنگی- سس شکلات- نوتلا- یک اسکوپ بستنی", S(460)],
];

/* Stable IDs so favorites survive page reloads */
const MENU_ITEMS = RAW_MENU.map(([category, name, description, pricing, customizable], idx) => ({
  id: `item_${category}_${idx}_${String(name).replace(/\s+/g, "_")}`,
  category,
  name,
  description,
  pricing,
  customizable: !!customizable,
  active: true,
}));

const WAFFLE_ICE_CREAM = ["وانیل", "شکلات", "کارامل", "معجون ترش", "استوایی", "زعفران پسته"];
const WAFFLE_TOPPINGS = ["کره بادام زمینی", "کره پسته", "نوتلا", "لوتوس", "سس شکلات", "کارامل نمکی"];

const TABLE_COUNT = 4;
const STORAGE_KEY = "fahrenheit-cafe-state-v3";

/* ============================================================
   Global style (font + scrollbar hiding + responsive grid)
   ============================================================ */
function GlobalStyle() {
  return (
    <style>{`
      ${FONT_IMPORT}
      * { box-sizing: border-box; }
      .fc-app, .fc-app *, .fc-app input, .fc-app textarea, .fc-app button, .fc-app select {
        font-family: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif;
      }
      .fc-scroll-x { overflow-x: auto; -ms-overflow-style: none; scrollbar-width: none; }
      .fc-scroll-x::-webkit-scrollbar { display: none; }
      .fc-order-layout { display: grid; grid-template-columns: 1fr; gap: 18px; }
      .fc-menu-layout { display: grid; grid-template-columns: 1fr; gap: 14px; }
      .fc-category-sidebar {
        display: flex;
        flex-direction: row;
        gap: 8px;
        overflow-x: auto;
        padding: 4px;
        scrollbar-width: thin;
      }
      .fc-category-sidebar::-webkit-scrollbar { height: 5px; }
      .fc-category-sidebar::-webkit-scrollbar-thumb { background: rgba(233,224,201,0.18); border-radius: 99px; }
      .fc-category-item { flex-shrink: 0; }
      @media (min-width: 900px) {
        .fc-order-layout { grid-template-columns: minmax(0, 1fr) 350px; align-items: flex-start; }
        .fc-order-panel-wrap { position: sticky; top: 16px; }
        .fc-menu-layout { grid-template-columns: 190px minmax(0, 1fr); align-items: start; }
        .fc-category-sidebar {
          flex-direction: column;
          overflow-y: auto;
          overflow-x: hidden;
          max-height: calc(100vh - 185px);
          position: sticky;
          top: 16px;
          padding: 4px;
          scrollbar-width: thin;
        }
        .fc-category-item { width: 100%; }
      }
      .fc-item-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
      @media (min-width: 640px) { .fc-item-grid { grid-template-columns: repeat(3, 1fr); } }
      @media (min-width: 900px) { .fc-item-grid { grid-template-columns: repeat(3, 1fr); } }
      .fc-table-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
      .fc-tap:active { transform: scale(0.97); }
      input::placeholder, textarea::placeholder { color: ${THEME.textFaint}; }
    `}</style>
  );
}

/* ============================================================
   Root component
   ============================================================ */
export default function App() {
  const [ready, setReady] = useState(false);
  const [tables, setTables] = useState(() =>
    Array.from({ length: TABLE_COUNT }, (_, i) => ({ id: `table_${i + 1}`, name: `میز ${toFa(i + 1)}`, status: "available" }))
  );
  const [orders, setOrders] = useState({});
  const [dailyOrders, setDailyOrders] = useState([]);
  const [orderCounter, setOrderCounter] = useState(0);
  const [favorites, setFavorites] = useState([]);
  const [view, setView] = useState("tables"); // tables | order | daily | menu
  const [activeTableId, setActiveTableId] = useState(null);
  const [toast, setToast] = useState(null);
  const [resetConfirmTableId, setResetConfirmTableId] = useState(null);
  const saveTimer = useRef(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (data.tables) setTables(data.tables);
        if (data.orders) setOrders(data.orders);
        if (data.dailyOrders) setDailyOrders(data.dailyOrders);
        if (typeof data.orderCounter === "number") setOrderCounter(data.orderCounter);
        if (data.favorites) setFavorites(data.favorites);
      }
    } catch (e) {
      /* first run or corrupt data */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      try {
        localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({ tables, orders, dailyOrders, orderCounter, favorites })
        );
      } catch (e) {
        console.error("save failed", e);
      }
    }, 250);
    return () => clearTimeout(saveTimer.current);
  }, [ready, tables, orders, dailyOrders, orderCounter, favorites]);

  const showToast = useCallback((msg) => setToast({ msg, id: uid("toast") }), []);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(t);
  }, [toast]);

  const openTable = (tableId) => {
    setActiveTableId(tableId);
    setView("order");
  };

  const orderTotal = (order) => (order ? order.items.reduce((s, it) => s + it.unitPrice * it.qty, 0) : 0);
  const orderCount = (order) => (order ? order.items.reduce((s, it) => s + it.qty, 0) : 0);

  const ensureOrder = (tableId) => {
    setOrders((prev) => {
      if (prev[tableId]) return prev;
      return { ...prev, [tableId]: { items: [], note: "", startedAt: Date.now() } };
    });
    setTables((prev) => prev.map((t) => (t.id === tableId ? { ...t, status: "active" } : t)));
  };

  const addItem = (tableId, menuItem, variant, unitPrice, qty, customization) => {
    setOrders((prev) => {
      const cur = prev[tableId] || { items: [], note: "", startedAt: Date.now() };
      const lineKey = `${menuItem.id}__${variant || "single"}__${customization || ""}`;
      const idx = cur.items.findIndex((it) => it.lineKey === lineKey);
      let items;
      if (idx >= 0) {
        items = cur.items.map((it, i) => (i === idx ? { ...it, qty: it.qty + qty } : it));
      } else {
        items = [
          ...cur.items,
          { id: uid("line"), lineKey, itemId: menuItem.id, name: menuItem.name, variant: variant || null, unitPrice, qty, customization: customization || null },
        ];
      }
      return { ...prev, [tableId]: { ...cur, items } };
    });
    setTables((prev) => prev.map((t) => (t.id === tableId ? { ...t, status: "active" } : t)));
  };

  const changeQty = (tableId, lineId, delta) => {
    setOrders((prev) => {
      const cur = prev[tableId];
      if (!cur) return prev;
      let removedName = null;
      const items = cur.items
        .map((it) => (it.id === lineId ? { ...it, qty: it.qty + delta } : it))
        .filter((it) => {
          if (it.qty <= 0) {
            removedName = it.name;
            return false;
          }
          return true;
        });
      if (removedName) showToast(`${removedName} حذف شد`);
      return { ...prev, [tableId]: { ...cur, items } };
    });
  };

  const removeLine = (tableId, lineId, name) => {
    setOrders((prev) => {
      const cur = prev[tableId];
      if (!cur) return prev;
      return { ...prev, [tableId]: { ...cur, items: cur.items.filter((it) => it.id !== lineId) } };
    });
    showToast(`${name} حذف شد`);
  };

  const setNote = (tableId, note) => {
    setOrders((prev) => {
      const cur = prev[tableId] || { items: [], note: "", startedAt: Date.now() };
      return { ...prev, [tableId]: { ...cur, note } };
    });
  };

  const saveOrder = (tableId) => {
    ensureOrder(tableId);
    showToast("سفارش ذخیره شد");
    setView("tables");
  };

  // Finish table: archive the current order (including its total) into daily sales,
  // then remove the active order and free the table.
  const completeOrder = (tableId) => {
    const order = orders[tableId];
    if (!order || order.items.length === 0) return;
    const table = tables.find((t) => t.id === tableId);
    const total = orderTotal(order);
    const nextNumber = orderCounter + 1;
    const completed = {
      id: uid("order"),
      number: nextNumber,
      tableId,
      tableName: table.name,
      items: order.items,
      note: order.note,
      total,
      startedAt: order.startedAt,
      completedAt: Date.now(),
    };
    setDailyOrders((prev) => [completed, ...prev]);
    setOrderCounter(nextNumber);
    setOrders((prev) => {
      const next = { ...prev };
      delete next[tableId];
      return next;
    });
    setTables((prev) => prev.map((t) => (t.id === tableId ? { ...t, status: "available" } : t)));
    showToast(`سفارش #${toFa(String(nextNumber).padStart(3, "0"))} ثبت شد`);
    setView("tables");
  };

  /* Free / reset a table WITHOUT logging a sale — for mistaken orders */
  const freeTable = (tableId) => {
    setOrders((prev) => {
      const next = { ...prev };
      delete next[tableId];
      return next;
    });
    setTables((prev) => prev.map((t) => (t.id === tableId ? { ...t, status: "available" } : t)));
    showToast("میز آزاد شد");
    if (view === "order" && activeTableId === tableId) setView("tables");
  };

  const toggleFavorite = (itemId) => {
    setFavorites((prev) => (prev.includes(itemId) ? prev.filter((x) => x !== itemId) : [...prev, itemId]));
  };

  const activeCount = tables.filter((t) => t.status === "active").length;
  const todayKey = dateKey(new Date());
  const todayRevenue = dailyOrders.filter((o) => dateKey(new Date(o.completedAt)) === todayKey).reduce((s, o) => s + o.total, 0);

  return (
    <div className="fc-app" dir="rtl" style={{ minHeight: "100vh", background: THEME.bg, color: THEME.text }}>
      <GlobalStyle />
      <Header view={view} setView={setView} activeCount={activeCount} totalTables={tables.length} todayRevenue={todayRevenue} />
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "16px 16px 110px" }}>
        {view === "tables" && (
          <TablesScreen
            tables={tables}
            orders={orders}
            openTable={openTable}
            orderTotal={orderTotal}
            orderCount={orderCount}
            onQuickReset={(id) => setResetConfirmTableId(id)}
          />
        )}
        {view === "order" && activeTableId && (
          <OrderScreen
            table={tables.find((t) => t.id === activeTableId)}
            order={orders[activeTableId]}
            favorites={favorites}
            onToggleFavorite={toggleFavorite}
            onBack={() => setView("tables")}
            onAddItem={(menuItem, variant, price, qty, customization) => addItem(activeTableId, menuItem, variant, price, qty, customization)}
            onChangeQty={(lineId, delta) => changeQty(activeTableId, lineId, delta)}
            onRemoveLine={(lineId, name) => removeLine(activeTableId, lineId, name)}
            onSetNote={(note) => setNote(activeTableId, note)}
            onSave={() => saveOrder(activeTableId)}
            onComplete={() => completeOrder(activeTableId)}
            onFree={() => setResetConfirmTableId(activeTableId)}
            onStart={() => ensureOrder(activeTableId)}
            orderTotal={orderTotal}
          />
        )}
        {view === "daily" && <DailyOrdersScreen dailyOrders={dailyOrders} />}
        {view === "menu" && <MenuBrowseScreen favorites={favorites} onToggleFavorite={toggleFavorite} />}
      </div>

      <BottomNav view={view} setView={setView} />
      {toast && <Toast msg={toast.msg} onClose={() => setToast(null)} />}

      {resetConfirmTableId && (
        <ConfirmModal
          title="آزادسازی میز؟"
          body={
            <div>
              <div style={{ marginBottom: 6 }}>میز: {tables.find((t) => t.id === resetConfirmTableId)?.name}</div>
              <div style={{ color: THEME.textSoft, fontSize: 13 }}>
                سفارش جاری این میز پاک می‌شود و در فروش روزانه ثبت نخواهد شد. میز برای مشتری جدید آزاد می‌شود.
              </div>
            </div>
          }
          cancelLabel="انصراف"
          confirmLabel="آزادسازی میز"
          danger
          onCancel={() => setResetConfirmTableId(null)}
          onConfirm={() => {
            freeTable(resetConfirmTableId);
            setResetConfirmTableId(null);
          }}
        />
      )}
    </div>
  );
}

/* Persian digit helper */
const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
function toFa(input) {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[+d]);
}

/* ============================================================
   Header
   ============================================================ */
function Header({ view, setView, activeCount, totalTables, todayRevenue }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);
  return (
    <div style={{ background: THEME.bgHeader, borderBottom: `1px solid ${THEME.border}` }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "16px 16px 14px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10, flexWrap: "wrap" }}>
          <div style={{ fontSize: 12.5, color: THEME.textSoft, paddingTop: 4 }}>{persianDate(now)}</div>
          <button
            onClick={() => setView("daily")}
            className="fc-tap"
            style={{
              minHeight: 40,
              padding: "9px 16px",
              borderRadius: 999,
              border: "none",
              background: THEME.gold,
              color: "#1B140A",
              fontWeight: 800,
              fontSize: 13,
              cursor: "pointer",
            }}
          >
            فروش امروز
          </button>
        </div>
        <div style={{ textAlign: "center", marginTop: 4 }}>
          <div style={{ fontSize: 26, fontWeight: 800, color: THEME.gold, letterSpacing: 0.3 }}>Fahrenheit Café</div>
          <div style={{ fontSize: 13, color: THEME.textSoft, marginTop: 2 }}>سیستم ثبت سفارش گارسون</div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
          <StatPill label="میزهای باز" value={`${toFa(activeCount)} از ${toFa(totalTables)}`} />
          <StatPill label="فروش امروز" value={`${toFa(todayRevenue.toLocaleString("en-US"))} T`} />
        </div>
      </div>
    </div>
  );
}

function StatPill({ label, value }) {
  return (
    <div style={{ flex: 1, background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 14, padding: "10px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <span style={{ fontSize: 12.5, color: THEME.textSoft }}>{label}</span>
      <span style={{ fontSize: 14.5, fontWeight: 800, color: THEME.text }}>{value}</span>
    </div>
  );
}

/* ============================================================
   Bottom nav
   ============================================================ */
function BottomNav({ view, setView }) {
  const items = [
    { id: "tables", label: "میزها", icon: TableIcon },
    { id: "daily", label: "سفارش‌ها", icon: ClipboardIcon },
    { id: "menu", label: "منو", icon: GridIcon },
  ];
  return (
    <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: THEME.cardAlt, borderTop: `1px solid ${THEME.border}`, zIndex: 40 }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex" }}>
        {items.map((it) => {
          const active = view === it.id;
          const Icon = it.icon;
          return (
            <button
              key={it.id}
              onClick={() => setView(it.id)}
              className="fc-tap"
              style={{
                flex: 1,
                background: "none",
                border: "none",
                padding: "10px 6px 12px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 4,
                cursor: "pointer",
                color: active ? THEME.gold : THEME.textFaint,
              }}
            >
              <Icon color={active ? THEME.gold : THEME.textFaint} />
              <span style={{ fontSize: 11.5, fontWeight: 700 }}>{it.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function TableIcon({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="10" width="18" height="3" rx="1" stroke={color} strokeWidth="1.8" />
      <path d="M5 13v6M19 13v6" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function ClipboardIcon({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="5" y="4" width="14" height="17" rx="2" stroke={color} strokeWidth="1.8" />
      <path d="M9 4V3h6v1" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <path d="M8 11h8M8 15h5" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function GridIcon({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.4" stroke={color} strokeWidth="1.8" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.4" stroke={color} strokeWidth="1.8" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.4" stroke={color} strokeWidth="1.8" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.4" stroke={color} strokeWidth="1.8" />
    </svg>
  );
}
function HeartIcon({ color, filled }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill={filled ? color : "none"}>
      <path
        d="M12 20.5s-7.5-4.6-10-9.3C0.3 7.6 2.3 4 6 4c2.1 0 3.7 1.2 6 3.6C14.3 5.2 15.9 4 18 4c3.7 0 5.7 3.6 4 7.2-2.5 4.7-10 9.3-10 9.3z"
        stroke={color}
        strokeWidth="1.6"
      />
    </svg>
  );
}
function ResetIcon({ color }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path d="M4 4v6h6" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M4.5 15a8 8 0 1 0 2-8.5L4 10" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ============================================================
   Tables screen
   ============================================================ */
function TablesScreen({ tables, orders, openTable, orderTotal, orderCount, onQuickReset }) {
  return (
    <div>
      <div className="fc-table-grid" style={{ marginTop: 6 }}>
        {tables.map((t) => {
          const order = orders[t.id];
          const active = t.status === "active";
          const total = orderTotal(order);
          const count = orderCount(order);
          const started = order?.startedAt ? new Date(order.startedAt) : null;
          return (
            <button
              key={t.id}
              onClick={() => openTable(t.id)}
              className="fc-tap"
              style={{
                position: "relative",
                textAlign: "right",
                cursor: "pointer",
                background: THEME.card,
                border: `1px solid ${active ? "rgba(224,147,46,0.35)" : THEME.border}`,
                borderRadius: 20,
                padding: "22px 20px",
                minHeight: 148,
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ width: 10, height: 10, borderRadius: 99, background: active ? THEME.orange : THEME.green, boxShadow: `0 0 0 4px ${active ? THEME.orangeSoft : THEME.greenSoft}` }} />
                {active && (
                  <span
                    role="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onQuickReset(t.id);
                    }}
                    style={{ width: 30, height: 30, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(255,255,255,0.05)" }}
                  >
                    <ResetIcon color={THEME.textSoft} />
                  </span>
                )}
              </div>
              <div style={{ fontSize: 24, fontWeight: 800, color: THEME.text, marginTop: 10 }}>{t.name}</div>
              {active ? (
                <div>
                  <div style={{ color: THEME.orange, fontWeight: 700, fontSize: 13.5, marginTop: 2 }}>سفارش فعال</div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: 10 }}>
                    <div>
                      <div style={{ color: THEME.textSoft, fontSize: 12.5 }}>{toFa(count)} آیتم</div>
                      {started && <div style={{ color: THEME.textFaint, fontSize: 11, marginTop: 2 }}>شروع {timeStr(started)}</div>}
                    </div>
                    <div style={{ fontSize: 18, fontWeight: 800, color: THEME.gold }}>{fmt(total)}</div>
                  </div>
                </div>
              ) : (
                <div style={{ color: THEME.green, fontWeight: 700, fontSize: 13.5, marginTop: 2 }}>آزاد</div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================
   Order screen
   ============================================================ */
function OrderScreen({ table, order, favorites, onToggleFavorite, onBack, onAddItem, onChangeQty, onRemoveLine, onSetNote, onSave, onComplete, onFree, onStart, orderTotal }) {
  const [category, setCategory] = useState(CATEGORIES[0].id);
  const [query, setQuery] = useState("");
  const [showFavOnly, setShowFavOnly] = useState(false);
  const [variantItem, setVariantItem] = useState(null);
  const [waffleItem, setWaffleItem] = useState(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const panelRef = useRef(null);

  const total = orderTotal(order);
  const hasOrder = order && order.items.length > 0;

  const filteredItems = useMemo(() => {
    let list = MENU_ITEMS.filter((it) => it.active);
    if (query.trim()) {
      list = list.filter((it) => it.name.includes(query.trim()));
    } else if (showFavOnly) {
      list = list.filter((it) => favorites.includes(it.id));
    } else {
      list = list.filter((it) => it.category === category);
    }
    return list;
  }, [category, query, showFavOnly, favorites]);

  const activeCatNote = CATEGORIES.find((c) => c.id === category)?.note;

  const handleTap = (item) => {
    if (item.customizable) return setWaffleItem(item);
    if (item.pricing.type === "variant") return setVariantItem(item);
    onAddItem(item, null, item.pricing.price, 1, null);
  };

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14, gap: 10, flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={onBack} className="fc-tap" style={circleBtnStyle}>→</button>
          <div style={{ fontSize: 20, fontWeight: 800, color: THEME.text }}>{table.name}</div>
        </div>
        <div style={{ background: THEME.goldSoft, color: THEME.gold, borderRadius: 12, padding: "9px 16px", fontWeight: 800, fontSize: 15 }}>
          جمع فعلی: {fmt(total)}
        </div>
      </div>

      {!hasOrder && (
        <div style={{ background: THEME.card, border: `1px dashed ${THEME.border}`, borderRadius: 18, padding: 26, textAlign: "center", marginBottom: 16 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: THEME.text, marginBottom: 6 }}>سفارش فعالی وجود ندارد</div>
          <div style={{ color: THEME.textSoft, fontSize: 13.5, marginBottom: 14 }}>یک آیتم از منو انتخاب کنید یا سفارش را آغاز کنید</div>
          <button onClick={onStart} className="fc-tap" style={goldBtnStyle}>شروع سفارش</button>
        </div>
      )}

      <div className="fc-order-layout">
        {/* MENU */}
        <div>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جستجوی آیتم… مثلاً لاته"
            style={{ width: "100%", boxSizing: "border-box", padding: "13px 16px", borderRadius: 14, border: `1px solid ${THEME.border}`, background: THEME.card, color: THEME.text, fontSize: 14.5, outline: "none", textAlign: "right", marginBottom: 12 }}
          />

          <div className="fc-menu-layout">
            {!query.trim() && (
              <aside className="fc-category-sidebar" aria-label="دسته‌بندی‌های منو">
                <CatChip active={showFavOnly} onClick={() => setShowFavOnly((v) => !v)} label="❤ پسندیده‌ها" heart className="fc-category-item" />
                {CATEGORIES.map((c) => (
                  <CatChip
                    key={c.id}
                    active={!showFavOnly && category === c.id}
                    onClick={() => { setShowFavOnly(false); setCategory(c.id); }}
                    label={c.label}
                    className="fc-category-item"
                  />
                ))}
              </aside>
            )}

            <div style={{ minWidth: 0 }}>
              {activeCatNote && !query.trim() && !showFavOnly && (
                <div style={{ color: THEME.textFaint, fontSize: 12, marginBottom: 10 }}>{activeCatNote}</div>
              )}

              <div className="fc-item-grid">
            {filteredItems.map((item) => {
              const priceLabel = item.pricing.type === "single" ? fmt(item.pricing.price) : fmt(item.pricing.prices.commercial);
              const isFav = favorites.includes(item.id);
              return (
                <button key={item.id} onClick={() => handleTap(item)} className="fc-tap" style={itemCardStyle}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <span style={{ width: 8, height: 8, borderRadius: 99, background: THEME.green, marginTop: 4, flexShrink: 0 }} />
                    <span
                      role="button"
                      onClick={(e) => { e.stopPropagation(); onToggleFavorite(item.id); }}
                      style={{ padding: 2 }}
                    >
                      <HeartIcon color={isFav ? THEME.orange : THEME.textFaint} filled={isFav} />
                    </span>
                  </div>
                  <div style={{ fontSize: 14.5, fontWeight: 700, color: THEME.text, marginTop: 8 }}>{item.name}</div>
                  {item.description && <div style={{ fontSize: 11.5, color: THEME.textSoft, marginTop: 3, lineHeight: 1.5 }}>{item.description}</div>}
                  <div style={{ fontSize: 13, fontWeight: 800, color: THEME.gold, marginTop: "auto", paddingTop: 8 }}>
                    {item.pricing.type === "variant" ? `از ${priceLabel}` : priceLabel}
                  </div>
                </button>
              );
            })}
                {filteredItems.length === 0 && <div style={{ color: THEME.textSoft, padding: 20, gridColumn: "1/-1" }}>موردی یافت نشد</div>}
              </div>
            </div>
          </div>
        </div>

        {/* ORDER PANEL */}
        <div className="fc-order-panel-wrap" ref={panelRef}>
          <div style={{ background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 18, padding: 16 }}>
            <div style={{ fontWeight: 800, fontSize: 15, color: THEME.text, marginBottom: 12 }}>سفارش جاری — {table.name}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, maxHeight: 360, overflowY: "auto" }}>
              {!hasOrder && <div style={{ color: THEME.textFaint, fontSize: 13.5 }}>هنوز آیتمی اضافه نشده</div>}
              {order &&
                order.items.map((line) => (
                  <div key={line.id} style={{ borderBottom: `1px solid ${THEME.border}`, paddingBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 13.5, color: THEME.text }}>{line.name}</div>
                        {line.variant && (
                          <div style={{ fontSize: 11, color: THEME.textSoft }}>
                            {line.variant === "hr" ? "High Robusta" : line.variant === "commercial" ? "Commercial" : "Special"}
                          </div>
                        )}
                        {line.customization && <div style={{ fontSize: 11, color: THEME.textSoft }}>{line.customization}</div>}
                      </div>
                      <div style={{ fontWeight: 700, fontSize: 13.5, color: THEME.gold, whiteSpace: "nowrap" }}>{fmt(line.unitPrice * line.qty)}</div>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8 }}>
                      <QtyBtn onClick={() => onChangeQty(line.id, -1)}>−</QtyBtn>
                      <div style={{ minWidth: 20, textAlign: "center", fontWeight: 700, color: THEME.text }}>{toFa(line.qty)}</div>
                      <QtyBtn onClick={() => onChangeQty(line.id, 1)}>+</QtyBtn>
                      <button onClick={() => onRemoveLine(line.id, line.name)} style={{ marginRight: "auto", border: "none", background: "none", color: THEME.danger, fontSize: 12, cursor: "pointer" }}>
                        حذف
                      </button>
                    </div>
                  </div>
                ))}
            </div>

            <div style={{ marginTop: 14 }}>
              <label style={{ fontSize: 12, color: THEME.textSoft, display: "block", marginBottom: 6 }}>یادداشت سفارش (اختیاری)</label>
              <textarea
                value={order?.note || ""}
                onChange={(e) => onSetNote(e.target.value)}
                placeholder="مثلاً: بدون شکر، کم‌یخ"
                rows={2}
                style={{ width: "100%", boxSizing: "border-box", borderRadius: 10, border: `1px solid ${THEME.border}`, background: THEME.cardAlt, color: THEME.text, padding: 10, fontSize: 12.5, resize: "none", textAlign: "right" }}
              />
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "16px 0 4px" }}>
              <div style={{ fontWeight: 700, color: THEME.textSoft, fontSize: 13 }}>جمع سفارش</div>
              <div style={{ fontWeight: 800, fontSize: 19, color: THEME.gold }}>{fmt(total)}</div>
            </div>

            <button onClick={onSave} disabled={!hasOrder} className="fc-tap" style={{ ...goldBtnStyle, width: "100%", marginTop: 10, opacity: hasOrder ? 1 : 0.4 }}>
              ثبت سفارش
            </button>
            <button onClick={() => setConfirmClose(true)} disabled={!hasOrder} className="fc-tap" style={{ ...outlineBtnStyle, width: "100%", marginTop: 10, opacity: hasOrder ? 1 : 0.4 }}>
              اتمام میز و ثبت فروش
            </button>
            {hasOrder && (
              <button onClick={onFree} className="fc-tap" style={{ width: "100%", marginTop: 10, background: "none", border: "none", color: THEME.danger, fontSize: 12.5, cursor: "pointer", padding: 8 }}>
                لغو سفارش و آزادسازی میز
              </button>
            )}
          </div>
        </div>
      </div>

      {variantItem && <VariantModal item={variantItem} onAdd={(key, price, qty) => { onAddItem(variantItem, key, price, qty, null); setVariantItem(null); }} onClose={() => setVariantItem(null)} />}
      {waffleItem && (
        <WaffleModal
          item={waffleItem}
          onAdd={(customization, qty) => { onAddItem(waffleItem, null, waffleItem.pricing.price, qty, customization); setWaffleItem(null); }}
          onClose={() => setWaffleItem(null)}
        />
      )}
      {confirmClose && (
        <ConfirmModal
          title="بستن سفارش؟"
          body={
            <div>
              <div style={{ marginBottom: 6 }}>میز: {table.name}</div>
              <div>مجموع: {fmt(total)}</div>
              <div style={{ marginTop: 10, color: THEME.textSoft, fontSize: 13 }}>
                با تأیید، مبلغ {fmt(total)} به فروش روزانه اضافه می‌شود، سفارش ثبت می‌شود و میز برای مشتری بعدی آزاد خواهد شد.
              </div>
            </div>
          }
          cancelLabel="لغو"
          confirmLabel="تأیید و بستن سفارش"
          onCancel={() => setConfirmClose(false)}
          onConfirm={() => { setConfirmClose(false); onComplete(); }}
        />
      )}
    </div>
  );
}

function CatChip({ active, onClick, label, heart, className = "" }) {
  return (
    <button
      onClick={onClick}
      className={`fc-tap ${className}`}
      style={{
        whiteSpace: "nowrap",
        minHeight: 44,
        padding: "9px 16px",
        borderRadius: 12,
        border: `1px solid ${active ? THEME.gold : THEME.border}`,
        background: active ? THEME.goldSoft : THEME.card,
        color: active ? THEME.gold : heart ? THEME.orange : THEME.textSoft,
        fontWeight: 700,
        fontSize: 13,
        cursor: "pointer",
        flexShrink: 0,
      }}
    >
      {label}
    </button>
  );
}

const itemCardStyle = {
  textAlign: "right",
  cursor: "pointer",
  background: THEME.card,
  border: `1px solid ${THEME.border}`,
  borderRadius: 16,
  padding: "13px 13px",
  minHeight: 108,
  display: "flex",
  flexDirection: "column",
};

function QtyBtn({ children, onClick }) {
  return (
    <button onClick={onClick} className="fc-tap" style={{ width: 34, height: 34, borderRadius: 9, border: `1px solid ${THEME.border}`, background: THEME.cardAlt, fontSize: 16, fontWeight: 800, color: THEME.gold, cursor: "pointer" }}>
      {children}
    </button>
  );
}

const circleBtnStyle = { minHeight: 44, minWidth: 44, borderRadius: 12, border: `1px solid ${THEME.border}`, background: THEME.card, cursor: "pointer", fontSize: 18, color: THEME.text };
const goldBtnStyle = { minHeight: 54, padding: "14px 22px", borderRadius: 14, border: "none", background: THEME.gold, color: "#1B140A", fontWeight: 800, fontSize: 15.5, cursor: "pointer" };
const outlineBtnStyle = { minHeight: 54, padding: "14px 22px", borderRadius: 14, border: `1.5px solid ${THEME.gold}`, background: "transparent", color: THEME.gold, fontWeight: 800, fontSize: 15.5, cursor: "pointer" };

/* ---------- Variant picker modal (with qty stepper, matches mockup) ---------- */
function VariantModal({ item, onAdd, onClose }) {
  const p = item.pricing.prices;
  const opts = [
    ["hr", "High Robusta", p.hr],
    ["commercial", "Commercial", p.commercial],
    ["special", "Special", p.special],
  ];
  const [selected, setSelected] = useState("commercial");
  const [qty, setQty] = useState(1);
  const price = opts.find((o) => o[0] === selected)[2];

  return (
    <ModalShell onClose={onClose} title={item.name} subtitle={item.description}>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 18 }}>
        {opts.map(([key, label, prc]) => {
          const active = selected === key;
          return (
            <button
              key={key}
              onClick={() => setSelected(key)}
              className="fc-tap"
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                minHeight: 54,
                padding: "0 16px",
                borderRadius: 12,
                border: `1.5px solid ${active ? THEME.gold : THEME.border}`,
                background: active ? THEME.goldSoft : THEME.cardAlt,
                cursor: "pointer",
                fontSize: 14.5,
                fontWeight: 700,
                color: THEME.text,
              }}
            >
              <span style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ width: 18, height: 18, borderRadius: 99, border: `2px solid ${active ? THEME.orange : THEME.border}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {active && <span style={{ width: 9, height: 9, borderRadius: 99, background: THEME.orange }} />}
                </span>
                {label}
              </span>
              <span style={{ color: THEME.gold }}>{fmt(prc)}</span>
            </button>
          );
        })}
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <div>
          <div style={{ fontSize: 11.5, color: THEME.textSoft }}>جمع کل</div>
          <div style={{ fontSize: 17, fontWeight: 800, color: THEME.gold }}>{fmt(price * qty)}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <QtyBtn onClick={() => setQty((q) => Math.max(1, q - 1))}>−</QtyBtn>
          <div style={{ minWidth: 20, textAlign: "center", fontWeight: 800, color: THEME.text }}>{toFa(qty)}</div>
          <QtyBtn onClick={() => setQty((q) => q + 1)}>+</QtyBtn>
        </div>
      </div>
      <button onClick={() => onAdd(selected, price, qty)} className="fc-tap" style={{ ...goldBtnStyle, width: "100%", marginTop: 18 }}>
        افزودن به سفارش
      </button>
    </ModalShell>
  );
}

/* ---------- Waffle customization modal ---------- */
function WaffleModal({ item, onAdd, onClose }) {
  const [iceCream, setIceCream] = useState(null);
  const [toppings, setToppings] = useState([]);
  const [qty, setQty] = useState(1);
  const toggleTopping = (t) => setToppings((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  const confirm = () => {
    const parts = [];
    if (iceCream) parts.push(`بستنی: ${iceCream}`);
    if (toppings.length) parts.push(`تاپینگ: ${toppings.join("، ")}`);
    onAdd(parts.join(" | ") || null, qty);
  };
  return (
    <ModalShell onClose={onClose} title={item.name} subtitle={item.description}>
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontWeight: 700, fontSize: 12.5, color: THEME.textSoft, marginBottom: 8 }}>بستنی</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {WAFFLE_ICE_CREAM.map((f) => (
            <Chip key={f} active={iceCream === f} onClick={() => setIceCream(iceCream === f ? null : f)} label={f} />
          ))}
        </div>
      </div>
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontWeight: 700, fontSize: 12.5, color: THEME.textSoft, marginBottom: 8 }}>تاپینگ</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {WAFFLE_TOPPINGS.map((t) => (
            <Chip key={t} active={toppings.includes(t)} onClick={() => toggleTopping(t)} label={t} />
          ))}
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 11.5, color: THEME.textSoft }}>جمع کل</div>
          <div style={{ fontSize: 17, fontWeight: 800, color: THEME.gold }}>{fmt(item.pricing.price * qty)}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <QtyBtn onClick={() => setQty((q) => Math.max(1, q - 1))}>−</QtyBtn>
          <div style={{ minWidth: 20, textAlign: "center", fontWeight: 800, color: THEME.text }}>{toFa(qty)}</div>
          <QtyBtn onClick={() => setQty((q) => q + 1)}>+</QtyBtn>
        </div>
      </div>
      <button onClick={confirm} className="fc-tap" style={{ ...goldBtnStyle, width: "100%" }}>
        افزودن به سفارش
      </button>
    </ModalShell>
  );
}

function Chip({ active, onClick, label }) {
  return (
    <button
      onClick={onClick}
      className="fc-tap"
      style={{
        minHeight: 42,
        padding: "8px 14px",
        borderRadius: 999,
        border: `1px solid ${active ? THEME.gold : THEME.border}`,
        background: active ? THEME.goldSoft : THEME.cardAlt,
        color: active ? THEME.gold : THEME.text,
        fontWeight: 700,
        fontSize: 12.5,
        cursor: "pointer",
      }}
    >
      {label}
    </button>
  );
}

/* ---------- Generic modal shell ---------- */
function ModalShell({ title, subtitle, children, onClose }) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 50, padding: 0 }}>
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ background: THEME.card, borderRadius: "22px 22px 0 0", padding: 22, width: "100%", maxWidth: 460, boxShadow: "0 -10px 40px rgba(0,0,0,0.5)", border: `1px solid ${THEME.border}`, borderBottom: "none" }}
      >
        <div style={{ width: 40, height: 4, borderRadius: 99, background: THEME.border, margin: "0 auto 16px" }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: THEME.text }}>{title}</div>
            {subtitle && <div style={{ fontSize: 12, color: THEME.textSoft, marginTop: 3 }}>{subtitle}</div>}
          </div>
          <button onClick={onClose} style={{ border: "none", background: "none", fontSize: 20, cursor: "pointer", color: THEME.textSoft }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ---------- Confirm modal ---------- */
function ConfirmModal({ title, body, cancelLabel, confirmLabel, onCancel, onConfirm, danger }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 60, padding: 20 }}>
      <div style={{ background: THEME.card, borderRadius: 20, padding: 24, width: "100%", maxWidth: 400, border: `1px solid ${THEME.border}`, boxShadow: "0 20px 50px rgba(0,0,0,0.5)" }}>
        <div style={{ fontSize: 18, fontWeight: 800, color: THEME.text, marginBottom: 10 }}>{title}</div>
        <div style={{ fontSize: 13.5, color: THEME.text, marginBottom: 20 }}>{body}</div>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={onCancel} className="fc-tap" style={{ ...outlineBtnStyle, flex: 1, minHeight: 50 }}>{cancelLabel}</button>
          <button
            onClick={onConfirm}
            className="fc-tap"
            style={{ ...goldBtnStyle, flex: 1, minHeight: 50, background: danger ? THEME.danger : THEME.gold, color: danger ? "#fff" : "#1B140A" }}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- Toast ---------- */
function Toast({ msg, onClose }) {
  return (
    <div
      style={{
        position: "fixed",
        bottom: 82,
        left: "50%",
        transform: "translateX(-50%)",
        background: THEME.cardAlt,
        border: `1px solid ${THEME.border}`,
        color: THEME.text,
        padding: "12px 18px",
        borderRadius: 12,
        fontSize: 13,
        fontWeight: 600,
        boxShadow: "0 10px 30px rgba(0,0,0,0.4)",
        zIndex: 80,
        display: "flex",
        alignItems: "center",
        gap: 14,
        whiteSpace: "nowrap",
      }}
    >
      {msg}
      <button onClick={onClose} style={{ border: "none", background: "none", color: THEME.gold, fontWeight: 700, cursor: "pointer" }}>بستن</button>
    </div>
  );
}

/* ============================================================
   Daily orders screen
   ============================================================ */
function DailyOrdersScreen({ dailyOrders }) {
  const dates = useMemo(() => Array.from(new Set(dailyOrders.map((o) => dateKey(new Date(o.completedAt))))).sort().reverse(), [dailyOrders]);
  const [selectedDate, setSelectedDate] = useState(dateKey(new Date()));
  const [expanded, setExpanded] = useState(null);
  const allDateOptions = dates.includes(selectedDate) ? dates : [selectedDate, ...dates];

  const dayOrders = useMemo(
    () => dailyOrders.filter((o) => dateKey(new Date(o.completedAt)) === selectedDate).sort((a, b) => b.completedAt - a.completedAt),
    [dailyOrders, selectedDate]
  );
  const revenue = dayOrders.reduce((s, o) => s + o.total, 0);
  const avg = dayOrders.length ? revenue / dayOrders.length : 0;

  const mostOrdered = useMemo(() => {
    const counts = {};
    dayOrders.forEach((o) => o.items.forEach((it) => (counts[it.name] = (counts[it.name] || 0) + it.qty)));
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [dayOrders]);

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 16 }}>
        <div style={{ fontSize: 19, fontWeight: 800, color: THEME.text }}>سفارش‌های امروز</div>
        <select
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          style={{ padding: "10px 14px", borderRadius: 999, border: `1px solid ${THEME.border}`, background: THEME.card, color: THEME.text, fontSize: 13, minHeight: 44 }}
        >
          {allDateOptions.map((d) => (
            <option key={d} value={d} style={{ background: THEME.card }}>{d}</option>
          ))}
        </select>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px,1fr))", gap: 12, marginBottom: 20 }}>
        <StatCard label="مجموع فروش روز" value={fmt(revenue)} />
        <StatCard label="تعداد سفارش" value={toFa(dayOrders.length)} />
        <StatCard label="میانگین سفارش" value={fmt(avg)} />
      </div>

      {mostOrdered.length > 0 && (
        <div style={{ background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 16, padding: 16, marginBottom: 20 }}>
          <div style={{ fontWeight: 800, color: THEME.text, marginBottom: 10, fontSize: 14 }}>پرفروش‌ترین آیتم‌ها</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {mostOrdered.map(([name, qty], i) => (
              <div key={name} style={{ display: "flex", justifyContent: "space-between", fontSize: 13.5, color: THEME.text }}>
                <span>{toFa(i + 1)}. {name}</span>
                <span style={{ fontWeight: 700, color: THEME.gold }}>{toFa(qty)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ fontWeight: 800, color: THEME.text, marginBottom: 10, fontSize: 14 }}>سفارش‌های تکمیل‌شده</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {dayOrders.length === 0 && <div style={{ color: THEME.textSoft }}>سفارشی در این تاریخ ثبت نشده</div>}
        {dayOrders.map((o) => {
          const isOpen = expanded === o.id;
          return (
            <div key={o.id} style={{ background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 14, overflow: "hidden" }}>
              <button
                onClick={() => setExpanded(isOpen ? null : o.id)}
                className="fc-tap"
                style={{ width: "100%", textAlign: "right", cursor: "pointer", background: "none", border: "none", padding: "14px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}
              >
                <div>
                  <div style={{ fontWeight: 800, fontSize: 14, color: THEME.text }}>سفارش #{toFa(String(o.number).padStart(3, "0"))}</div>
                  <div style={{ fontSize: 12, color: THEME.textSoft, marginTop: 2 }}>
                    {o.tableName} · {timeStr(new Date(o.completedAt))} · {toFa(o.items.reduce((s, it) => s + it.qty, 0))} آیتم
                  </div>
                </div>
                <div style={{ fontWeight: 800, color: THEME.gold, fontSize: 14 }}>{fmt(o.total)}</div>
              </button>
              {isOpen && (
                <div style={{ padding: "0 16px 14px", borderTop: `1px solid ${THEME.border}` }}>
                  {o.items.map((it) => (
                    <div key={it.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "8px 0", borderBottom: `1px solid ${THEME.border}`, color: THEME.text }}>
                      <div>
                        {it.name} {it.variant && <span style={{ color: THEME.textSoft }}>({it.variant === "hr" ? "High Robusta" : it.variant === "commercial" ? "Commercial" : "Special"})</span>}
                        {it.customization && <div style={{ color: THEME.textSoft, fontSize: 11.5 }}>{it.customization}</div>}
                      </div>
                      <div>×{toFa(it.qty)} — {fmt(it.unitPrice * it.qty)}</div>
                    </div>
                  ))}
                  {o.note && <div style={{ marginTop: 10, fontSize: 12.5, color: THEME.textSoft }}>یادداشت: {o.note}</div>}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div style={{ background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 16, padding: "16px 16px" }}>
      <div style={{ fontSize: 12, color: THEME.textSoft, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 19, fontWeight: 800, color: THEME.gold }}>{value}</div>
    </div>
  );
}

/* ============================================================
   Menu browse screen (reference only, no table context)
   ============================================================ */
function MenuBrowseScreen({ favorites, onToggleFavorite }) {
  const [category, setCategory] = useState(CATEGORIES[0].id);
  const [query, setQuery] = useState("");
  const items = useMemo(() => {
    if (query.trim()) return MENU_ITEMS.filter((it) => it.name.includes(query.trim()));
    return MENU_ITEMS.filter((it) => it.category === category);
  }, [category, query]);

  return (
    <div>
      <div style={{ fontSize: 19, fontWeight: 800, color: THEME.text, marginBottom: 14 }}>منوی کافه</div>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="جستجو در منو…"
        style={{ width: "100%", boxSizing: "border-box", padding: "13px 16px", borderRadius: 14, border: `1px solid ${THEME.border}`, background: THEME.card, color: THEME.text, fontSize: 14.5, outline: "none", textAlign: "right", marginBottom: 12 }}
      />
      {!query.trim() && (
        <div className="fc-scroll-x" style={{ display: "flex", gap: 8, paddingBottom: 4, marginBottom: 14 }}>
          {CATEGORIES.map((c) => (
            <CatChip key={c.id} active={category === c.id} onClick={() => setCategory(c.id)} label={c.label} />
          ))}
        </div>
      )}
      <div className="fc-item-grid">
        {items.map((item) => {
          const isFav = favorites.includes(item.id);
          return (
            <div key={item.id} style={{ ...itemCardStyle, cursor: "default" }}>
              <div style={{ display: "flex", justifyContent: "flex-end" }}>
                <span role="button" onClick={() => onToggleFavorite(item.id)} style={{ cursor: "pointer" }}>
                  <HeartIcon color={isFav ? THEME.orange : THEME.textFaint} filled={isFav} />
                </span>
              </div>
              <div style={{ fontSize: 14.5, fontWeight: 700, color: THEME.text, marginTop: 4 }}>{item.name}</div>
              {item.description && <div style={{ fontSize: 11.5, color: THEME.textSoft, marginTop: 3, lineHeight: 1.5 }}>{item.description}</div>}
              <div style={{ fontSize: 12.5, fontWeight: 700, color: THEME.gold, marginTop: "auto", paddingTop: 8 }}>
                {item.pricing.type === "single" ? fmt(item.pricing.price) : `${fmt(item.pricing.prices.hr)} / ${fmt(item.pricing.prices.commercial)} / ${fmt(item.pricing.prices.special)}`}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
