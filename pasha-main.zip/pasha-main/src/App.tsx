import React, { useState } from 'react';
import { Coffee, Egg, Globe2, Croissant, Salad, Sandwich, UtensilsCrossed, ChevronUp, MapPin, Instagram, Send, Phone, X } from 'lucide-react';

interface MenuItem {
  name: string;
  price: string;
  //description: string;
  //image: string;
}

interface MenuCategory {
  name: string;
  icon: React.ReactNode;
  items: MenuItem[];
}

const menuData: MenuCategory[] = [
  {
    name: 'Omelette | املت',
    icon: <Egg className="w-6 h-6" />,
    items: [
                { name: 'املت گوجه', price: '195 T'},
                { name: 'املت گوجه اِسپایسی', price: '210 T'},
                { name: 'املت اسفناج', price: '215 T'},
                { name: 'املت سوجوک', price: '295 T'},
                { name: 'املت پپرونی', price: '275 T'},
                { name: 'املت اسفناج بیکن', price: '290 T'},
                { name: 'املت شکاری', price: '298 T'},
                { name: 'املت گوشت', price: '320 T'},
                { name: 'املت مرغ', price: '285 T'},
                { name: 'املت بیکن', price: '275 T'},
                { name: 'املت سالامی', price: '275 T'},
                { name: 'املت خرما', price: '215 T'},
                { name: 'املت تن‌ماهی', price: '245 T'},
                { name: 'املت بوقلمون', price: '285 T'},
                { name: 'املت شاپوری', price: '198 T'},
                { name: 'نیمرو', price: '145 T'},
                { name: 'املت قارچ و خامه', price: '255 T'},
                { name: 'املت سیب‌زمینی', price: '192 T' }
    ]
  },
    {
    name: 'Croissant | کروسان',
    icon: <Croissant className="w-6 h-6" />,
    items: [
                { name: 'کروسان بیکن تخم‌مرغ', price: '350 T'},
                { name: 'کروسان بیکن ', price: '335 T'},
                { name: 'کروسان برگر', price: '415 T'},
                { name: 'کروسان چیکن پستو', price: '320 T'},
                { name: 'کروسان نوتلا', price: '325 T'}
    ]
  },
  {
    name: 'Nations | ملل',
    icon: <Globe2 className="w-6 h-6" />,
    items: [
                { name: 'برانچ میگو', price: '498 T' },
                { name: 'چیکن پاشا', price: '392 T' },
                { name: 'اسکرامبل اگ', price: '387 T' },
                { name: 'گواکامولی بیکن', price: '425 T'},
                { name: 'لازانیا', price: '425 T'},
                { name: 'پاستا', price: '330 T'},
    ]
  },
  {
    name: 'Sandwich | ساندویچ (پنینی)',
    icon: <Sandwich className="w-6 h-6" />,
    items: [
                { name: 'تن‌ماهی', price: '298 T'},
                { name: 'پستو مرغ', price: '335 T'},
                { name: 'گوشت', price: '368 T'},
                { name: 'بوقلمون', price: '315 T'},
                { name: 'مرغ و اسنفاج', price: '340 T'},
                { name: 'شکاری', price: '292 T'},
                { name: 'سیب سرخی', price: '205 T'}
    ]
  },
  {
    name: 'خوراک',
    icon: <UtensilsCrossed className="w-6 h-6" />,
    items: [
                { name: 'خوراک زبان', price: '395 T'},
                { name: 'خوراک جگر (استانبولی)', price: '365 T'},
                { name: 'خوراک مرغ', price: '320 T'},
                { name: 'خوراک گوشت', price: '370 T'},
                { name: 'کباب تابه‌ای', price: '375 T'},
                { name: 'لوبیا کباب', price: '335 T'},
                { name: 'بشقاب رژیمی', price: '350 T'},
                { name: 'جگر بره (دو نفره)', price: '446 T'}
    ]
  },
    {
    name: 'Salad | سالاد',
    icon: <Salad className="w-6 h-6" />,
    items: [
                { name: 'سالاد سزار پاشا', price: '350 T'}
    ]
  },
  {
    name: 'Drinks | نوشیدنی‌ها',
    icon: <Coffee className="w-6 h-6" />,
    items: [
                { name: 'چای', price: '-'},
                { name: 'آبمیوه طبیعی', price: '-'},
                { name: 'کوکا', price: '-'},
                { name: 'ماشعیر', price: '-'},
                { name: 'اسموتی', price: '-'}
    ]
  }
];

function App() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const toggleCategory = (categoryName: string) => {
    setExpandedCategory(expandedCategory === categoryName ? null : categoryName);
  };

  const closeAllCategories = () => {
    setExpandedCategory(null);
  };

  return (
    <div className="min-h-screen bg-[#FBE4D6]">
      {/* Header */}
      <header
        className="relative text-white py-6 px-4 text-center sticky top-0 z-50"
        style={{
          backgroundImage: "url('https://ik.imagekit.io/amirfaramarzpour/pasha_breakfast_cafe/8287.jpg?updatedAt=1744734924726')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          opacity: 1,
        }}
      >
        <div className="container mx-auto flex items-center justify-center gap-4">
          <img
            src="https://ik.imagekit.io/amirfaramarzpour/pasha_breakfast_cafe/logo.png?updatedAt=1735419450707"
            alt="Cafe Logo"
            className="w-24 h-24 rounded-full object-cover border-1 border-[#1DCD9F]"
          />
          <div>
            <h1
              className="text-[#FDFAF6] text-2xl md:text-4xl font-bold mb-2"
              style={{
                fontFamily: '"Pacifico", cursive',
                fontWeight: 400,
                fontStyle: 'normal',
                backgroundColor: '',
                padding: '0px 0px',
                borderRadius: '4px',
                display: 'inline-block',
              }}
            >
              Pasha Breakfast Cafe
            </h1>
            <p className="text-[#1DCD9F] text-lg"></p>
          </div>
        </div>
      </header>

      {/* Menu Categories */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col gap-4 mb-12">
          {menuData.map((category) => (
            <div key={category.name}>
              <button
                onClick={() => toggleCategory(category.name)}
                className={`w-full bg-[#143D60] rounded-lg p-4 text-white transition-all duration-300 transform hover:scale-105 ${
                  expandedCategory === category.name ? 'ring-4 ring-[#FFA725]' : ''
                } flex items-center justify-between`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-[#693382] rounded-full">
                    {category.icon}
                  </div>
                  <h2
                    className="text-xl font-semibold rakkas-regular"
                    style={{
                      fontFamily: '"Rakkas", serif',
                      fontWeight: 400,
                      fontStyle: 'normal',
                    }}
                  >
                    {category.name}
                  </h2>
                </div>
                <span className="text-sm text-[#FFA725]">
                  {category.items.length} items
                </span>
              </button>
              {/* Expanded Category Items */}
              {expandedCategory === category.name && (
                <div className="bg-[#1e4387] rounded-lg p-6 mt-2">
                  <div className="flex items-center justify-between mb-6">
                    <h2
                      className="text-3xl font-bold text-white rakkas-regular"
                      style={{
                        fontFamily: '"Rakkas", serif',
                        fontWeight: 400,
                        fontStyle: 'normal',
                      }}
                    >
                      {category.name}
                    </h2>
                    <button
                      onClick={() => setExpandedCategory(null)}
                      className="text-[#FFA725] hover:text-white transition-colors"
                    >
                      <ChevronUp className="w-8 h-8" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 gap-6">
                    {category.items.map((item) => (
                      <div
                        key={item.name}
                        className="bg-[#3E3F5B] rounded-lg overflow-hidden shadow-lg"
                      >
                        <div className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-lg font-bold text-[#FFA725]">
                              {item.price}
                            </span>
                            <h3
                              className="text-xl font-semibold text-white text-right lalezar-regular"
                              style={{
                                fontFamily: '"Lalezar", system-ui',
                                fontWeight: 400,
                                fontStyle: 'normal',
                              }}
                            >
                              {item.name}
                            </h3>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer
        className="text-white py-8 px-4"
        style={{
          backgroundImage: "url('https://ik.imagekit.io/amirfaramarzpour/pasha_breakfast_cafe/8287.jpg?updatedAt=1744734924726')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          fontFamily: '"Saira", sans-serif',
          fontOpticalSizing: 'auto',
          fontWeight: 400,
          fontStyle: 'normal',
          fontVariationSettings: '"wdth" 100',
        }}
      >
        <div className="container mx-auto flex flex-col items-center gap-2">
          <div className="flex items-center gap-2">
            <MapPin className="w-6 h-6 text-[#FFA725]" />
            <a
              href="https://maps.app.goo.gl/x4BRFLJvD1iAMLQs9"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#FFA725] transition-colors"
            >
              Mazandaran, Sari, Saba St. No.3
            </a>
          </div>
          <p className="mt-2">8:00 AM - 5:00 PM</p>
          <p className="mt-2 font-bold">Contact US:</p>
          <div className="flex gap-4 items-center">
            <div
              className="flex items-center gap-2 cursor-pointer hover:text-[#FFA725] transition-colors"
              onClick={() => navigator.clipboard.writeText("+98 911 156 3237")}
            >
              <Phone className="w-5 h-5" />
              <p>+98 911 156 3237</p>
            </div>
            <div
              className="flex items-center gap-2 cursor-pointer hover:text-[#FFA725] transition-colors"
              onClick={() => navigator.clipboard.writeText("+98 911 511 7291")}
            >
              <Phone className="w-5 h-5" />
              <p>+98 911 511 7291</p>
            </div>
          </div>
          <p className="mt-2 font-bold">Follow US:</p>
          <div className="flex gap-4">
            <a
              href="https://www.instagram.com/breakfast_pasha"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#FFA725] transition-colors flex items-center gap-2"
            >
              <Instagram className="w-5 h-5" />
              <span>Instagram</span>
            </a>
            <a
              href="https://t.me/+989115117291"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#FFA725] transition-colors flex items-center gap-2"
            >
              <Send className="w-5 h-5" />
              <span>Telegram</span>
            </a>
          </div>
          <p className="mt-2">© 2025 Pasha Business Group. All rights reserved</p>
          <p className="mt-2">Design:{" "}
            <a
              href="https://amirfaramarzpour.ir"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white underline"
            >
              AmirFaramarzpour
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;