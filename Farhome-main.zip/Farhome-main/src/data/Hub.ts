export interface HubPost {
  id: string;
  title: string;
  excerpt: string;
  description: string;
  otherDescription?: string;
  author: string;
  date: string;
  category: string;
  location: string;
  contactNumbers: string[];
  images: string[];
  videos?: string[];
  brochureUrl?: string;
  website?: string;
  instagram?: string;
  teaserUrl?: string;
}

export const hubPosts: HubPost[] = [
  {
    id: 'alomsar',
    title: 'گروه صنعتی آلومسار',
    excerpt: 'تولید کننده انواع پنجــــــــره‌های دو جـــــداره و مجری انواع نمای شیشه‌ای با بیش از نیم قرن سابقه',
    description: ' گروه صنعتی آلومسار در سال ۱۳۵۹ با نام پروفیل ولیعصر فعالیت خود را در زمینه ساخت درب و پنجره آلومینیومی و فروش پروفیل آغاز نمود و در این مدت افتخار داشت مجری طرح‌ها و پروژه‌های کوچک و بزرگ در شهر ساری و استان مازندران باشد.  پس از کسب تجربه در طی سالیان متوالی، در سال ۱۳۸۸ در راستای جلب رضایت مشتری و حرکت به‌سوی ارائه محصولات با کیفیت، با نگرشی نوین و تخصصی به صنعت، تصمیم بر آن شد تا تجربیات را با مهندسی صنایع در هم آمیزد و با بهره‌گیری از تکنولوژی روز دنیا، فعالیت خود را در زمینه ساخت درب و پنجره‌های دو جداره اختصاصی آلومینیوم و UPVC ادامه دهد. ',
    otherDescription: 'محصولات:\n -آلـــــــومینیوم اختـــــصاصی نرمال و ترمال بریک\n -یو پــــــــی وی ســــــــی\n -کرتـــــیـــــن وال \n -فریـــــــــم لس \n -اسپـــــــــایدر \n -هندریل شیشه ای پله \n -تراس شیشه ای \n -سقف شیشه ای ( اسکای لایت ) \n -پنجره گیــــــوتینی \n -پنجره لیفت اند اسلاید \n -پنجره های سه ریل و چهار ریل \n -پنجره آکاردئـــــــــــونی \n -پارتیشن شیشه ای \n -انواع پنجــــــــــره خم ، قوس و مدلینگ \n -انواع توری پلیسه ای و اختصاصی \n -شیشه بالکنی \n',
    author: 'جناب آقای شجری',
    date: '2025-08-07',
    category: 'تولید کننده انواع پنجــــــــره‌های دو جـــــداره و مجری انواع نمای شیشه‌ای',
    location: 'ساری - بلوار امام رضا - جنب آتش نشانی',
    contactNumbers: ['09114080066','01133288070'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Alomsar/Alomsar-LogoHD.png?updatedAt=1754573227231',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Alomsar/Logo-En.jpg?updatedAt=1754569360911',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Alomsar/Logo-Fa.jpg?updatedAt=1754569361143',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Alomsar/Brand-Intro.jpg?updatedAt=1754569361837',
    ],
    brochureUrl: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Alomsar/katalog_compressed.pdf?updatedAt=1754569372360',
    videos: ['https://aparat.com/v/ybqc505'],
    website: 'alomsar.ir',
    instagram: 'https://www.instagram.com/alomsar',
    teaserUrl: 'https://aparat.com/v/ied34oj'
  },

    {
    id: 'Dayk_decor',
    title: 'دایک دکور',
    excerpt: 'کلینیک ساختمانی دایک دکور، بزرگ‌ترین دپوی پارکت و کف‌پوش لمینیت در سه استان شمالی کشور (مازندران، گلستان و گیلان)',
    description: 'کلینیک ساختمانی دایک دکور از سال ۱۳۸۰ به مدیریت آقای مجید مجیدی فعالیت خود را آغاز کرد. این مجموعه امروز به عنوان بزرگ‌ترین دپوی پارکت و کف‌پوش لمینیت در سه استان شمالی کشور (مازندران، گلستان و گیلان) شناخته می‌شود و هدف خود را ارائه‌ی محصولات باکیفیت، خدمات متفاوت و قیمت‌های رقابتی قرار داده است.   \n دایک دکور در طول سال‌ها همکاری با برندهای معتبر جهانی و اجرای پروژه‌های متنوع، تجربه‌ای ارزشمند در حوزه‌ی طراحی داخلی کسب کرده است. بخشی از این پروژه‌ها شامل طراحی و اجرای سالن‌های VIP و CIP فرودگاه‌های ساری، نوشهر و بندر امیرآباد، سالن‌های کنفرانس سازمان‌ها و طراحی داخلی بانک‌ها می‌باشد.',
    otherDescription: 'امروز، با پشتوانه‌ی ۲۴ سال تجربه و بهره‌گیری از تیمی جوان و متخصص، دایک دکور در مسیر ارائه‌ی بهترین خدمات و خلق فضاهایی مدرن، زیبا و ماندگار برای مشتریان خود گام برمی‌دارد',
    author: 'جناب آقای مهندس مجیدی',
    date: '2025-09-04',
    category: 'دپوی پارکت و کف‌پوش لمینیت ',
    location: 'ساری - خیابان سلمان فارسی - مردانشاهی',
    contactNumbers: ['09111510308'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/1.jpg?updatedAt=1756986691391',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/photo_2025-09-04_15-18-27.jpg?updatedAt=1756986677004',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/photo_2025-09-04_15-18-28.jpg?updatedAt=1756986676891',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/photo_2025-09-04_15-18-21.jpg?updatedAt=1756986676295',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/photo_2025-09-04_15-18-30.jpg?updatedAt=1756986676231',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/photo_2025-09-04_15-18-30%20(2).jpg?updatedAt=1756986676189',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/photo_2025-09-04_15-18-29.jpg?updatedAt=1756986675856',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/ConstructionHub/Dyke-decor/photo_2025-09-04_15-18-29%20(2).jpg?updatedAt=1756986675118',

    ],
    brochureUrl: 'https://www.farhome.ir/404.html',
    videos: ['https://www.farhome.ir/404.html'],
    website: 'https://www.farhome.ir/404.html',
    instagram: 'https://www.instagram.com/Dayk_decor',
    teaserUrl: 'https://www.farhome.ir/404.html'
  },
    //{
    //id: '',
    //title: '',
    //excerpt: '',
    //description: '',
    //otherDescription: '',
    //author: '',
    //date: '2025-08-07',
    //category: '',
    //location: '',
    //contactNumbers: ['',''],
    //images: [

    //brochureUrl: '',
    //videos: [''],
    //website: '',
    //instagram: '',
    //teaserUrl: ''
  //}
];