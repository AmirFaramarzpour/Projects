export interface Property {
  id: string;
  title: string;
  location: string;
  priceValue: number;
  type: 'buy' | 'rent';
  propertyType: 'house' | 'apartment' | 'villa' | 'office' | 'shop' | 'penthouse' | 'land' | 'tower';
  bedrooms: number;
  bathrooms: number;
  sqft: number;
  furnished: boolean;
  images: string[]; // Added array for multiple images
  description: string;
  agent: string;
  agentPhone: string;
  features: string[];
  dateAdded: string;
}

export interface Agent {
  id: string;
  name: string;
  image: string;
  phone: string;
  email: string;
  specialization: string;
  experience: string;
  languages: string[];
  rating: number;
  reviewCount: number;
}

export const properties: Property[] = [
  {
    id: '1',
    title: 'مسکونی 173 متری تهران',
    location: ' تهران، میدان هروی، f-0302، tehran',
    priceValue: 17000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 173,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0302/0302-1-b.jpg?updatedAt=1752161310092',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0302/0302-2-b.jpg?updatedAt=1752161310203',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0302/0302-3-b.jpg?updatedAt=1752161309831',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0302/0302-4-b.jpg?updatedAt=1752161309951',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0302/0302-5-b.jpg?updatedAt=1752161310058',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0302/0302-6-b.jpg?updatedAt=1752161310331',

    ],
    description: ' ۵ طبقه واحد ۲ ، ۳ پارکینگ سند دارد',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['نوساز', '5 طبقه', 'سال ساخت 1403', 'Rooftop Terrace'],
    dateAdded: '2025-07-10'
  },
  {
    id: '2',
    title: '95 متری مسکونی در تهران',
    location: 'تهران، گیشا، f-0303، tehran',
    priceValue: 18000000000,
    type: 'buy',
    propertyType: 'house',
    bedrooms: 2,
    bathrooms: 1,
    sqft: 95,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0303/0303-1-b.jpg?updatedAt=1752161775590',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0303/0303-2-b.jpg?updatedAt=1752161775600',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0303/0303-3-b.jpg?updatedAt=1752161775615',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0303/0303-4-b.jpg?updatedAt=1752161775663',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Tehran/0303/0303-5-b.jpg?updatedAt=1752161775484',
    ],
    description: 'سند تک برگ ، سنگ کف اسلب ، نما بی‌نظیر ، نورگیر عالی',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: [ 'انباری', 'پارکینگ', 'آسانسور'],
    dateAdded: '2025-07-10'
  },
  {
    id: '3',
    title: 'ویلا در شیراز',
    location: 'شیراز، قصرالدشت، f-0305، shiraz',
    priceValue: 40800000000,
    type: 'buy',
    propertyType: 'villa',
    bedrooms: 4,
    bathrooms: 2,
    sqft: 400,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-1-b.jpg?updatedAt=1752162236379',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-2-b.jpg?updatedAt=1752162236205',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-3-b.jpg?updatedAt=1752162236247',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-4-b.jpg?updatedAt=1752162236074',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-5-b.jpg?updatedAt=1752162236210',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-6-b.jpg?updatedAt=1752162236210',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-7-b.jpg?updatedAt=1752162236196',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-8-b.jpg?updatedAt=1752162236208',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Shiraz/0305/0305-9-b.jpg?updatedAt=1752162236211',
    ],
    description: 'دارای ۲۰۰ متر حیاط',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['سالن میز بیلیارد', 'سرویس ناهار خوری',],
    dateAdded: '2025-07-10'
  },
  {
    id: '4',
    title: 'پنت هاوس رامسر',
    location: 'رامسر، برج آفرینش، طبقه 23، f-0304، ramsar',
    priceValue: 46200000000,
    type: 'buy',
    propertyType: 'penthouse',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 277,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Ramsar/0304/0304-1-b.jpg?updatedAt=1752163092147',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Ramsar/0304/0304-2-b.jpg?updatedAt=1752163092149',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Ramsar/0304/0304-3-b.jpg?updatedAt=1752163091974',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Ramsar/0304/0304-4-b.jpg?updatedAt=1752163092385',
    ],
    description: 'با چشم‌انداز دریا و جنگل - دارای لابی',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['سالن ورزشی بانوان و آقایان', 'نگهبان ۲۴ ساعته', 'سونا جکوزی', 'استخر سر پوشیده','دسترسی اختصاصی به ساحل','سیستم کنترل هوشمند  دما ، نور ، پرده‌ها','آنتن مرکزی اینترنت پر سرعت'],
    dateAdded: '2025-07-10'
  },
  {
    id: '5',
    title: 'خانه ویلایی در اصفهان',
    location: 'اصفهان، ناژوان، f-0301، esfahan',
    priceValue: 13350000000,
    type: 'buy',
    propertyType: 'villa',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 260,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-1-b.jpg?updatedAt=1752163618296',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-2-b.jpg?updatedAt=1752163617969',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-3-b.jpg?updatedAt=1752163617923',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-4-b.jpg?updatedAt=1752163616517',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-5-b.jpg?updatedAt=1752163616778',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-6-b.jpg?updatedAt=1752163614490',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-7-b.jpg?updatedAt=1752163616582',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-8-b.jpg?updatedAt=1752163618254',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Isfahan/0301-9-b.jpg?updatedAt=1752163618270',
    ],
    description: 'پتینه‌کاری شده و طلاکوبی شده با طلای 24 عیار ایتالیایی',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['دسترسی عالی به مراکز تفریحی', '2 پارکینگ','سال ساخت 1403','طبقه 4', 'آشپزخانه چوبی و طراحی نقشه زیبا'],
    dateAdded: '2025-07-10'
  },
  {
    id: '6',
    title: 'پنت هاوس 240 متری بابلسر',
    location: 'بابلسر، پلاک یک دریا، f-0307، babolsar',
    priceValue: 32000000000,
    type: 'buy',
    propertyType: 'shop',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 240,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-1-b.jpg?updatedAt=1752164255588',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-2-b.jpg?updatedAt=1752164254398',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-3-b.jpg?updatedAt=1752164255879',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-4-b.jpg?updatedAt=1752164253746',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-5-b.jpg?updatedAt=1752164256298',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-6-b.jpg?updatedAt=1752164255389',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-7-b.jpg?updatedAt=1752164257129',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Babolsar/0307/0307-8-b.jpg?updatedAt=1752164255248',
    ],
    description: 'سال ساخت ۱۴۰۲ ، پنت‌هاوس',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['دارای استخر و جکوزی چهار فصل رو باز در روف', 'باشگاه ورزشی', 'سرایدار ۲۴ ساعته', 'Storage Room'],
    dateAdded: '2025-07-10'
  },
  {
    id: '7',
    title: 'اپارتمان بلوار پرستار',
    location: 'ساری ، بلوار پرستار ، f-01، sari',
    priceValue: 21000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 297,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/01/01-1-b.JPG?updatedAt=1752164684149',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/01/01-2-b.JPG?updatedAt=1752164685596',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/01/01-3-b.JPG?updatedAt=1752164685608',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/01/01-4-b.JPG?updatedAt=1752164685626',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/01/01-5-b.JPG?updatedAt=1752164685018',
    ],
    description: 'کاربری : مسکونی',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['-'],
    dateAdded: '2025-07-10'
  },
  {
    id: '8',
    title: 'اپارتمان جاده دریا',
    location: 'f-جاده دریا ساری، 02، sari',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 266,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-1-b.JPG?updatedAt=1752165048966',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-2-b.JPG?updatedAt=1752165051139',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-3-b.JPG?updatedAt=1752165050440',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-4-b.JPG?updatedAt=1752165052108',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-5-b.JPG?updatedAt=1752165049980',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-6-b.JPG?updatedAt=1752165052896',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-7-b.JPG?updatedAt=1752165047044',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-8-b.JPG?updatedAt=1752165053057',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/02/02-9-b.JPG?updatedAt=1752165052801',
    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['-'],
    dateAdded: '2025-07-10'
  },
  {
    id: '9',
    title: 'اپارتمان ولایت فقیه',
    location: 'ساری، ولایت فقیه، f-010، sari',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 2,
    bathrooms: 1,
    sqft: 118,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/010/010-1-b.jpg?updatedAt=1752166267169',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/010/010-2-b.jpg?updatedAt=1752166266700',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/010/010-3-b.jpg?updatedAt=1752166266809',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/010/010-4-b.jpg?updatedAt=1752166266725',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/010/010-5-b.jpg?updatedAt=1752166266329',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/010/010-6-b.jpg?updatedAt=1752166265231',
    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2024-01-18'
  },
  {
    id: '10',
    title: 'اپارتمان ۱۶۰ متری',
    location: 'ساری، سلمان فارسی، f-011، sari',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 4,
    bathrooms: 3,
    sqft: 160,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-1-b.jpg?updatedAt=1752166790565',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-2-b.jpg?updatedAt=1752166785729',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-3-b.jpg?updatedAt=1752166777717',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-4-b.jpg?updatedAt=1752166791432',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-5-b.jpg?updatedAt=1752166784374',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-6-b.jpg?updatedAt=1752166783096',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-7-b.jpg?updatedAt=1752166776773',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-8-b.jpg?updatedAt=1752166789936',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/011/011-9-b.jpg?updatedAt=1752166791774',
    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-10'
  },
  {
    id: '11',
    title: 'اپارتمان ۱۴۰ متری',
    location: 'f-ساری، سلمان فارسی، 023، sari',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 1,
    sqft: 140,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-1-b.jpg?updatedAt=1752167294841',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-2-b.jpg?updatedAt=1752167295253',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-3-b.jpg?updatedAt=1752167296120',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-4-b.jpg?updatedAt=1752167294608',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-5-b.jpg?updatedAt=1752167295806',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-6-b.jpg?updatedAt=1752167295450',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-7-b.jpg?updatedAt=1752167291088',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/023/023-b-8.jpg?updatedAt=1752167295953',
    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-10'
  },
  {
    id: '12',
    title: 'اپارتمان ۲۱۵ متری',
    location: 'ساری، خیابان پیروزی، f-024، sari',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 215,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-1-b.jpg?updatedAt=1752167829392',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-2-b.jpg?updatedAt=1752167829227',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-3-b.jpg?updatedAt=1752167825122',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-4-b.jpg?updatedAt=1752167831111',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-5-b.jpg?updatedAt=1752167831038',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-6-b.jpg?updatedAt=1752167826000',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-7-b.jpg?updatedAt=1752167827152',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-8-b.jpg?updatedAt=1752167829525',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/024/024-9-b.jpg?updatedAt=1752167829468',
    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-10'
  },
  {
    id: '13',
    title: 'اپارتمان ۱۴۰ متری ',
    location: 'f-ساری، ولایت فقیه، 025، sari',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 140,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/025/025-1-b.jpg?updatedAt=1752168154225',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/025/025-2-b.jpg?updatedAt=1752168154271',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/025/025-3-b.jpg?updatedAt=1752168150602',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/025/025-4-b.jpg?updatedAt=1752168153476',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/025/025-5-b.jpg?updatedAt=1752168153746',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/025/025-6-b.jpg?updatedAt=1752168153535',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/025/025-7-b.jpg?updatedAt=1752168152443',
    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-10'
  },
  {
    id: '14',
    title: 'اپارتمان با ویو پارک ملل',
    location: 'ساری، صابونچی، f-026، sari',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 180,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/026/026-1-b%20.jpg?updatedAt=1752168408896',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/026/026-2-b.jpg?updatedAt=1752168406833',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/026/026-3-b%20.jpg?updatedAt=1752168406464',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/026/026-4-b.jpg?updatedAt=1752168409053',
    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-10'
  },
  {
    id: '15',
    title: 'اپارتمان ۲۰۰ متری',
    location: 'ساری، قرجه، f-027، sari',
    priceValue: 11000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 200,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/027/027-1-b.JPG?updatedAt=1752168711841',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/027/027-2-b.JPG?updatedAt=1752168712565',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/027/027-3-b.JPG?updatedAt=1752168711812',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/027/027-4-b.JPG?updatedAt=1752168712569',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/027/027-5-b.JPG?updatedAt=1752168712196',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/027/027-6-b.JPG?updatedAt=1752168712415',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/027/027-7-b.JPG?updatedAt=1752168711714',

    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-10'
  },
  {
    id: '16',
    title: 'پنت هاوس تجاری',
    location: 'ساری، خیابان شهابی، f-022، sari',
    priceValue: 16000000000,
    type: 'buy',
    propertyType: 'penthouse',
    bedrooms: 2,
    bathrooms: 2,
    sqft: 227,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-1-b.jpg?updatedAt=1752169428508',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-2-b.jpg?updatedAt=1752169428581',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-3-b.jpg?updatedAt=1752169428215',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-4-b.jpg?updatedAt=1752169426882',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-5-b.jpg?updatedAt=1752169514966',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-6-b.jpg?updatedAt=1752169427262',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-7-b.jpg?updatedAt=1752169427839',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-8-b.jpg?updatedAt=1752169423850',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-9-b.jpg?updatedAt=1752169427759',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-10-b.jpg?updatedAt=1752169428481',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-11-b.jpg?updatedAt=1752169432847',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-12-b-.jpg?updatedAt=1752169438229',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/022-13-b.jpg?updatedAt=1752169439951',



    ],
    description: 'جهت اطلاع از قیمت و دریافت مشاوره با کارشناسان ما تماس بگیرید',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : تجاری'],
    dateAdded: '2025-07-10'
  },
  {
    id: '17',
    title: 'اپارتمان مسکونی 174 متری خیابان پیروزی',
    location: 'ساری، پیروزی ، نبش محتشم، f-07',
    priceValue: 11310000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 174,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-1.jpg?updatedAt=1752950359043',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-2.jpg?updatedAt=1752950359016',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-3.jpg?updatedAt=1752950356912',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-4.jpg?updatedAt=1752950355845',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-5.jpg?updatedAt=1752950358364',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-6.jpg?updatedAt=1752950353691',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-7.jpg?updatedAt=1752950354693',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-8.jpg?updatedAt=1752950354854',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-9.jpg?updatedAt=1752950365267',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-10.jpg?updatedAt=1752950368094',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-11.jpg?updatedAt=1752950469567',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/07/07-b-12.jpg?updatedAt=1752950469514',




    ],
    description: ' تعداد طبقات: 11/31',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-19'
  },
  {
    id: '18',
    title: 'اپارتمان مسکونی 140 متری خیابان پیروزی',
    location: 'f-ساری، پیروزی ، نبش محتشم، 018',
    priceValue: 9100000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 140,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-1.jpg?updatedAt=1752951368373',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-2.jpg?updatedAt=1752951368652',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-3.jpg?updatedAt=1752951361169',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-4.jpg?updatedAt=1752951359292',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-5.jpg?updatedAt=1752951362377',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-6.jpg?updatedAt=1752951363693',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-7.jpg?updatedAt=1752951368432',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-8.jpg?updatedAt=1752951360129',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-9.jpg?updatedAt=1752951355391',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/018/018-b-10.jpg?updatedAt=1752951365105',



    ],
    description: ' سال ساخت 1404، تعداد طبقات 11/31',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-19'
  },
  {
    id: '19',
    title: 'اپارتمان 200 متری 13 ابان',
    location: 'f-ساری، کوچه ۱۳ آبان، 066',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 200,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/1.jpg?updatedAt=1752953360752',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/2.jpg?updatedAt=1752953360741',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/3.jpg?updatedAt=1752953360304',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/4.jpg?updatedAt=1752953360060',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/5.jpg?updatedAt=1752953360124',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/6.jpg?updatedAt=1752953359602',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/7.jpg?updatedAt=1752953359492',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/066/8.jpg?updatedAt=1752953360202',




    ],
    description: 'مشابه ۲۷۰ متری ۴ خواب هم موجود است',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-19'
  },
  {
    id: '20',
    title: 'اپارتمان مسکونی 110 متری در ساری',
    location: 'ساری، کوچه فرشادی، f-070',
    priceValue: 6600000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 2,
    bathrooms: 1,
    sqft: 110,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/070/1.jpg?updatedAt=1752954011523',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/070/2.jpg?updatedAt=1752954011813',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/070/3.jpg?updatedAt=1752954011671',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/070/4.jpg?updatedAt=1752954011339',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/070/5.jpg?updatedAt=1752954011658',




    ],
    description: 'مشابه  ۱۵۰ متری و ۲۲۰ متری',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-19'
  },
  {
    id: '21',
    title: 'زمین 1000 متری در مهدشت',
    location: 'f-ساری، مهدشت، 0032',
    priceValue: 20000000000,
    type: 'buy',
    propertyType: 'land',
    bedrooms: 1,
    bathrooms: 1,
    sqft: 1000,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0032/1.jpg?updatedAt=1752954604611',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0032/2.jpg?updatedAt=1752954604897',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0032/3.jpg?updatedAt=1752954604845',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0032/4.jpg?updatedAt=1752954604824',




    ],
    description: 'قیمت : متری 20 میلیون تومان، زمین ۲ کله ، از هر سمت ۳۳ متر بر ، آب و برق و گاز پایین زمین ',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : زمین '],
    dateAdded: '2025-07-19'
  },
  {
    id: '22',
    title: 'اپارتمان مسکونی 210 متری',
    location: 'f-ساری، کوچه فرشادی، 072',
    priceValue: 14700000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 210,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/1.jpg?updatedAt=1752973842170',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/2.jpg?updatedAt=1752973842202',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/3.jpg?updatedAt=1752973842267',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/4.jpg?updatedAt=1752973842450',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/5.jpg?updatedAt=1752973842529',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/6.jpg?updatedAt=1752973842221',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/7.jpg?updatedAt=1752973842161',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/8.jpg?updatedAt=1752973842265',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/9.jpg?updatedAt=1752973842513',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/10.jpg?updatedAt=1752973842488',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/11.jpg?updatedAt=1752973846517',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/072/12.jpg?updatedAt=1752973846806',
      



    ],
    description: ' سال ساخت : ۱۴۰۴، در طبقات ۱ ، ۴، ۷، ۸ ، ۹',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-20'
  },
  {
    id: '23',
    title: 'اپارتمان مسکونی نو ساخت',
    location: 'f-ساری، شهابی شبستان، 032',
    priceValue: 14000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 200,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/1.jpg?updatedAt=1752975168933',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/2.jpg?updatedAt=1752975168728',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/3.jpg?updatedAt=1752975168718',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/4.jpg?updatedAt=1752975168496',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/5.jpg?updatedAt=1752975168676',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/6.jpg?updatedAt=1752975168358',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/7.jpg?updatedAt=1752975168628',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/8.jpg?updatedAt=1752975168423',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/9.jpg?updatedAt=1752975168548',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/10.jpg?updatedAt=1752975168507',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/032/11.jpg?updatedAt=1752975172760',





    ],
    description: 'سال ساخت : ۱۴۰۱، قیمت : طبقه ۲ متری ۶۰ و طبقه ۶ متری ۷۰ میلیون تومان، تعداد طبقات : ۶/۶',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-20'
  },
    {
    id: '24',
    title: 'اپارتمان مسکونی 180 متری طبرستان',
    location: 'ساری ، اوایل طبرستان ، sari, f-0105',
    priceValue: 9000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 180,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0105/1.jpg?updatedAt=1753702874730',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0105/11.jpg?updatedAt=1753702874601',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0105/2.jpg?updatedAt=1753702874601',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0105/3.jpg?updatedAt=1753702874737',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0105/4.jpg?updatedAt=1753702874604',






    ],
    description: 'سال ساخت: 1404، تعداد طبقات : 7 نما',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-28'
  },
      {
    id: '25',
    title: 'واحد اپارتمان نوساز در لسانی',
    location: 'ساری ، لسانی، f-096',
    priceValue: 3250000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 133,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/096/1.jpg?updatedAt=1753703084733',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/096/2.jpg?updatedAt=1753703084391',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/096/3.jpg?updatedAt=1753703084686',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/096/4.jpg?updatedAt=1753703084004',





    ],
    description: 'سال ساخت: 1404، دارای آسانسور و انباری، عکس ها متعلق به طبقات بالا هست - ۶طبقه و ۶ واحد-ملک طبقه ی اول است',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-28'
  },
      {
    id: '26',
    title: 'اپارتمان نوساز 147 متری',
    location: 'ساری ، پارک افتاب، sari، f-086',
    priceValue: 5350000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 147,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/086/1.jpg?updatedAt=1753703413632',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/086/2.jpg?updatedAt=1753703413493',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/086/3.jpg?updatedAt=1753703414053',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/086/4.jpg?updatedAt=1753703413925',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/086/5.jpg?updatedAt=1753703413737',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/086/6.jpg?updatedAt=1753703414006',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/086/7.jpg?updatedAt=1753703413470',





    ],
    description: 'سال ساخت: 1403، یک خواب مستر - 2 خواب تراس - واحد طبقه ی 2 نما است',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: [' اسانسور، پارکینگ، انباری، کاربری : مسکونی'],
    dateAdded: '2025-07-28'
  },
      {
    id: '27',
    title: 'ویلای لوکس جاده پلاژ',
    location: 'ساری ، sari، جاده پلاژ، f-0036',
    priceValue: 15000000000,
    type: 'buy',
    propertyType: 'villa',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 330,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/1%20(2).jpg?updatedAt=1753704083472',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/1.jpg?updatedAt=1753704079848',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/2.jpg?updatedAt=1753704077402',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/3.jpg?updatedAt=1753704080272',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/5.jpg?updatedAt=1753704082486',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/6.jpg?updatedAt=1753704083594',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/7.jpg?updatedAt=1753704084414',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/8.jpg?updatedAt=1753704084722',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/9.jpg?updatedAt=1753704079920',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/10.jpg?updatedAt=1753704081064',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/11.jpg?updatedAt=1753704076664',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/12.jpg?updatedAt=1753704079523',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/13.jpg?updatedAt=1753704080844',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/14.jpg?updatedAt=1753704077235',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/15.jpg?updatedAt=1753704079305',



    ],
    description: 'متراژ : ۳۳۰ متر بنا ، ۲۳۰ متر زمین، تعداد طبقات : تریپلکس، سال ساخت : 1404، استخر در همکف',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-28'
  },
      {
    id: '28',
    title: 'فروش زمین 300 متری میدان خزر ساری',
    location: 'ساری ، میدان خزر، پشت اداره پست ، sari، f-0035',
    priceValue: 7500000000,
    type: 'buy',
    propertyType: 'land',
    bedrooms: 0,
    bathrooms: 0,
    sqft: 300,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0035/1.jpg?updatedAt=1753704848923',





    ],
    description: 'قیمت : متری ۳۵، سند دارد ، یک سمت اداره پست ، یک سمت پارک ، یک سمت مسکونی ، یک سمت زمین',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-28'
  },
      {
    id: '29',
    title: 'اپارتمان 90 متری بهمن شرقی',
    location: 'ساری ، بهمن شرقی ، sari ,  f-081 ',
    priceValue: 8190000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 2,
    bathrooms: 1,
    sqft: 200,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/081/1.jpg?updatedAt=1753705055996',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/081/2.jpg?updatedAt=1753705054829',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/081/3.jpg?updatedAt=1753705058839',





    ],
    description: 'تعداد طبقات : 11، سال ساخت: 1404، واحد طبقه پنجم است - نما',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: [' اسانسور2 لاین -پارکینک ، کاربری : مسکونی'],
    dateAdded: '2025-07-28'
  },


      {
    id: '30',
    title: 'اپارتمان مسکونی نوساز 220 متری بلوار خزر ساری',
    location: 'ساری ، بلوار خزر ، sari، f-089',
    priceValue: 9000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 220,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/1.jpg?updatedAt=1753705699917',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/2.jpg?updatedAt=1753705700690',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/3.jpg?updatedAt=1753705699657',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/4.jpg?updatedAt=1753705700536',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/5.jpg?updatedAt=1753705700914',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/6.jpg?updatedAt=1753705701070',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/7.jpg?updatedAt=1753705700255',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/8.jpg?updatedAt=1753705700075',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/9.jpg?updatedAt=1753705699807',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/10.jpg?updatedAt=1753705700020',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/11.jpg?updatedAt=1753705704454',
    ],
    description: 'تعداد طبقات : ۷ طبقه / ۱۳ واحد، سال ساخت : 1404، طبقه 2 و 3',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-28'
  },


      {
    id: '31',
    title: 'تجاری 115 متری در سلمان فارسی',
    location: 'ساری ، سلمان فارسی، sari , f-079',
    priceValue: 8000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 2,
    bathrooms: 1,
    sqft: 115,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/1.jpg?updatedAt=1753706287446',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/2.jpg?updatedAt=1753706285032',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/3.jpg?updatedAt=1753706286759',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/4.jpg?updatedAt=1753706284980',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/5.jpg?updatedAt=1753706286203',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/6.jpg?updatedAt=1753706286662',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/7.jpg?updatedAt=1753706286773',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/8.jpg?updatedAt=1753706285328',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/9.jpg?updatedAt=1753706284965',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/10.jpg?updatedAt=1753706286519',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/11.jpg?updatedAt=1753706290984',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/12.jpg?updatedAt=1753706290653',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/13.jpg?updatedAt=1753706292055',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/14.jpg?updatedAt=1753706292192',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/15.jpg?updatedAt=1753706291938',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/16.jpg?updatedAt=1753706292322',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/17.jpg?updatedAt=1753706291964',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/18.jpg?updatedAt=1753706292627',

    ],
    description: ' سال ساخت : 1404، تعداد طبقات : ۱۰ طبقه / ۲۰ واحد',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : تجاری'],
    dateAdded: '2025-07-28'
  },
      {
    id: '32',
    title: 'رهن و اجاره واحد تجاری 160 متری در باغ سنگ',
    location: 'ساری ، باغ سنگ ، sari, f-11',
    priceValue: 4000000000,
    type: 'rent',
    propertyType: 'apartment',
    bedrooms: 1,
    bathrooms: 1,
    sqft: 160,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/1.jpg?updatedAt=1753707406495',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/2.jpg?updatedAt=1753707407523',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/3.jpg?updatedAt=1753707406976',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/4.jpg?updatedAt=1753707407461',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/5.jpg?updatedAt=1753707406583',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/6.jpg?updatedAt=1753707407099',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/7.jpg?updatedAt=1753707407570',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/8.jpg?updatedAt=1753707402685',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/9.jpg?updatedAt=1753707407598',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/10.jpg?updatedAt=1753707407497',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/11.jpg?updatedAt=1753707409331',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/12.jpg?updatedAt=1753707411456',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/11/13.jpg?updatedAt=1753707412316',





    ],
    description: 'متراژ : ۱۶۰ بنا / ۸۰ متر تراس، تعداد واحد : ۸ طبقه / ۱۵ واحد، طبقه : ۸ پنت هاوس، طبقه : ۸ پنت هاوس، رهن و اجاره قابل تبدیل می‌باشد ',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : تجاری', 'رهن : ۴،۰۰۰،۰۰۰،۰۰۰'],
    dateAdded: '2025-07-28'
  },
      {
    id: '33',
    title: 'رهن و اجاره واحد مسکونی 110 متری در باغ سنگ',
    location: 'ساری ، باغ سنگ ، sari, f-12',
    priceValue: 1650000000,
    type: 'rent',
    propertyType: 'apartment',
    bedrooms: 1,
    bathrooms: 1,
    sqft: 110,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/12/1.jpg?updatedAt=1753707985172',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/12/2.jpg?updatedAt=1753707985529',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/12/3.jpg?updatedAt=1753707985142',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/12/4.jpg?updatedAt=1753707984585',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/12/5.jpg?updatedAt=1753707984766',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/12/6.jpg?updatedAt=1753707985213',





    ],
    description: 'سال ساخت : ۴۰۴، طبقه : ۱ و ۷ نما، تعداد واحد : ۸ طبقه / ۱۵ واحد، تعداد خواب : فلت',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی','رهن : ۱،۶۵۰،۰۰۰،۰۰۰ '],
    dateAdded: '2025-07-28'
  },
      {
    id: '34',
    title: 'اپارتمان مسکونی 300 متری سلمان فارسی',
    location: 'ساری ، سلمان فارسی ، sari, f-076 ',
    priceValue: 18000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 4,
    bathrooms: 3,
    sqft: 300,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/1.jpg?updatedAt=1753740937566',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/2.jpg?updatedAt=1753740940099',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/3.jpg?updatedAt=1753740941936',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/4.jpg?updatedAt=1753740938137',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/5.jpg?updatedAt=1753740941310',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/6.jpg?updatedAt=1753740939224',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/7.jpg?updatedAt=1753740938701',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/8.jpg?updatedAt=1753740940708',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/9.jpg?updatedAt=1753740943216',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/10.jpg?updatedAt=1753740942605',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/11.jpg?updatedAt=1753740935352',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/12.jpg?updatedAt=1753740936359',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/13.jpg?updatedAt=1753740936972',



    ],
    description: ' تعداد طبقات : ۹ طبقه / ۹ واحد، سال ساخت : 1404',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-29'
  },
      {
    id: '35',
    title: 'اپارتمان 180 متری سلمان فارسی',
    location: 'ساری ، سلمان فارسی، f-0106',
    priceValue: 12600000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 180,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/1.jpg?updatedAt=1753742019583',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/2.jpg?updatedAt=1753741994029',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/3.jpg?updatedAt=1753742004476',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/4.jpg?updatedAt=1753741987630',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/5.jpg?updatedAt=1753741990995',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/6.jpg?updatedAt=1753741989653',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/7.jpg?updatedAt=1753741998078',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/8.jpg?updatedAt=1753741994631',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/9.jpg?updatedAt=1753741992620',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/10.jpg?updatedAt=1753741994430',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/11.jpg?updatedAt=1753742022779',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/12.jpg?updatedAt=1753742013112',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/13.jpg?updatedAt=1753742023286',



    ],
    description: 'تعداد طبقات : ۱۲ طبقه / ۲۰ واحد، سال ساخت : 1404، توضیحات : طبقه دوم نما،   ',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-07-29'
  },
  {
    id: '36',
    title: 'اپارتمان مسکونی 155 متری در پیروزی',
    location: 'ساری ، خیابان پیروزی ، sari , f-60 ',
    priceValue: 600000000,
    type: 'rent',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 155,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/1.jpg?updatedAt=1755797692830',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/2.jpg?updatedAt=1755797692156',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/3.jpg?updatedAt=1755797690215',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/4.jpg?updatedAt=1755797690394',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/5.jpg?updatedAt=1755797691529',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/6.jpg?updatedAt=1755797691037',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/7.jpg?updatedAt=1755797691192',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/8.jpg?updatedAt=1755797692201',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/60/9.jpg?updatedAt=1755797690003',




    ],
    description: 'امکانات : اسانسور-پارکینگ-انباری، توضیحات : واحد طبقه ی 6 نما ، سال ساخت : 1404، تعداد طبقات : 8/16،  رهن :600/000/000، اجاره : ،30/000/000',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',  
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-08-21'
  },
  {
    id: '37',
    title: 'ویلای 350 متری مرزن آباد',
    location: ' مرزن آباد ، marzan abad',
    priceValue: 45000000000,
    type: 'buy',
    propertyType: 'villa',
    bedrooms: 3,
    bathrooms: 3,
    sqft: 350,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/1.jpg?updatedAt=1755798636356',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/2.jpg?updatedAt=1755798635140',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/3.jpg?updatedAt=1755798640796',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/4.jpg?updatedAt=1755798638761',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/5.jpg?updatedAt=1755798640600',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/6.jpg?updatedAt=1755798637151',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/7.jpg?updatedAt=1755798636818',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/8.jpg?updatedAt=1755798634458',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/9.jpg?updatedAt=1755798635073',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/10.jpg?updatedAt=1755798637546',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/11.jpg?updatedAt=1755798644801',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/12.jpg?updatedAt=1755798645244',




    ],
    description: 'ملک دارای سند تک‌برگ معتبر بوده و با قیمت ۴۵ میلیارد تومان عرضه می‌شود. همچنین امکان تهاتر با ملک یا خودرو نیز وجود دارد.',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',  
    features: ['کاربری : مسکونی'],
    dateAdded: '2025-08-21'
  },
  {
    id: '38',
    title: 'برج مسکونی لوکس در سرخ‌رود',
    location: 'سرخ‌رود ، سرخرود ، sorkhrud',
    priceValue: 0,
    type: 'buy',
    propertyType: 'tower',
    bedrooms: 3,
    bathrooms: 3,
    sqft: 350,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/FINALL-RENDER01(P).jpg?updatedAt=1755801160812',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/FINALL-RENDER05(P).jpg?updatedAt=1755801165687',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/FINALL-RENDER06.jpg?updatedAt=1755801144890',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/map.png?updatedAt=1755801316556',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/WhatsApp%20Image%202025-08-21%20at%2019.02.30_3fb1a0d8.jpg?updatedAt=1755801220272',




    ],
    description: 'امکانات برج شامل استخر، جکوزی و باشگاه روی بام است و موقعیت عالی آن امکان ترکیب آرامش ساحل با دسترسی راحت به مراکز شهری را فراهم می‌کند. این پروژه فرصتی استثنایی برای سرمایه‌گذاری و زندگی لوکس در شمال کشور به شمار می‌رود.',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',  
    features: [' کاربری : مسکونی | جهت دریافت قیمت تماس حاصل فرمائید'],
    dateAdded: '2025-08-21'
  },
  {
    id: '39',
    title: 'ویلای مسکونی جاده فرح آباد',
    location: 'ساری ، کیلومتر ۶ جاده فرح آباد، f-0012',
    priceValue: 0,
    type: 'buy',
    propertyType: 'tower',
    bedrooms: 2,
    bathrooms: 2,
    sqft: 400,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/2.jpg?updatedAt=1752974556526',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/4.jpg?updatedAt=1752974556469',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/1.jpg?updatedAt=1752974556510',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/3.jpg?updatedAt=1752974556129',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/4.jpg?updatedAt=1752974556469',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/5.jpg?updatedAt=1752974556501',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/6.jpg?updatedAt=1752974556478',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/7.jpg?updatedAt=1752974556649',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/8.jpg?updatedAt=1752974556506',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/9.jpg?updatedAt=1752974556198',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/10.jpg?updatedAt=1752974556315',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/11.jpg?updatedAt=1752974559921',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/12.jpg?updatedAt=1752974559787',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/13.jpg?updatedAt=1752974560026',
    ],
    description: ' متر دوبلکس 200 + 200 متر زمین ',
    agent: 'کارشناسان فرهوم',
    agentPhone: '09115800059',  
    features: [' کاربری : مسکونی | جهت دریافت مشاوره با کارشناسان ما تماس بگیرید'],
    dateAdded: '2025-08-20'
  },
    {
    id: '40',
    title: 'فروش آپارتمان لوکس دوبلکس در آلانیا – برج گلد سیتی',
    location: 'turkey , alanya ، آلانیا ترکیه , f-0144',
    priceValue: 0,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 2,
    bathrooms: 3,
    sqft: 140,
    furnished: true,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/1.jpg?updatedAt=1756988668677',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/2.jpg?updatedAt=1756988659551',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/3.jpg?updatedAt=1756988669700',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/4.jpg?updatedAt=1756988668853',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/5.jpg?updatedAt=1756988666219',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/6.jpg?updatedAt=1756988668720',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/7.jpg?updatedAt=1756988665002',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/8.jpg?updatedAt=1756988663054',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/9.jpg?updatedAt=1756988668653',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/10.jpg?updatedAt=1756988662473',

    ],
    description: 'متراژ: ۱۴۰ متر - دارای ۲ خواب مستر - دوبلکس شیک و مدرن - واقع در طبقه ۱۳ برج لوکس گلد سیتی - فول فرنیش (مبله کامل و آماده سکونت) - خدمات هتلی در مجموعه - پارک آبی و استخر اختصاصی - لوکیشن ممتاز در شهر آلانیا',
    agent: 'عاملیت فروش: فرهوم گروپ، قیمت: ۱۸۰,۰۰۰ دلار، امکان تهاتر با ملک در ساری  ',
    agentPhone: '09115800059',  
    features: [' کاربری : مسکونی | عاملیت فروش: فرهوم گروپ، قیمت: ۱۸۰,۰۰۰ دلار، امکان تهاتر با ملک در ساری  '],
    dateAdded: '2025-09-04'
  },
      {
    id: '41',
    title: 'فروش ویژه ملک صنعتی – اداری در موقعیت ممتاز',
    location: 'بابل به بابلسر،  هادی شهر، کوچه صنعت،  جنب کارخانه فرش و موکت بابل ، babol , f-0046',
    priceValue: 0,
    type: 'buy',
    propertyType: 'land',
    bedrooms: 1,
    bathrooms: 1,
    sqft: 7800,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-03.jpg?updatedAt=1756988157032',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-02.jpg?updatedAt=1756988157699',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-41-59.jpg?updatedAt=1756988155695',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-05.jpg?updatedAt=1756988161576',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-06.jpg?updatedAt=1756988162157',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-04.jpg?updatedAt=1756988162932',

    ],
    description: 'یک فرصت استثنایی برای سرمایه‌گذاران و صاحبان صنعت! ملکی با مساحت ۷۸۰۰ متر زمین و ۲۵۰۰ متر سوله استاندارد در بهترین نقطه صنعتی منطقه، واقع در جاده بابل به بابلسر، هادی‌شهر، کوچه صنعت، جنب کارخانه فرش و موکت بابل',
    agent: 'فرهوم گروپ',
    agentPhone: '09115800059',  
    features: [' کاربری : صنعتی | جهت دریافت مشاوره و قیمت با کارشناسان ما تماس بگیرید'],
    dateAdded: '2025-09-04'
  },
      {
    id: '42',
    title: 'آپارتمان ۲۰۰ متری در ساختمانی برند',
    location: ' ساری ، میدان سلمان فارسی ، ساختمان ایساتیس ، sari , f-022',
    priceValue: 10000000000,
    type: 'buy',
    propertyType: 'apartment',
    bedrooms: 3,
    bathrooms: 3,
    sqft: 200,
    furnished: false,
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/1.jpg?updatedAt=1756987504773',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/2.jpg?updatedAt=1756987504269',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/3.jpg?updatedAt=1756987504306',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/4.jpg?updatedAt=1756987505168',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/5.jpg?updatedAt=1756987426858',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/6.jpg?updatedAt=1756987503262',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/7.jpg?updatedAt=1756987504499',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/8.jpg?updatedAt=1756987432174',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/9.jpg?updatedAt=1756987505169',

    ],
    description: 'دارای ۲ لاین آسانسور / دراری ژنراتور برق، 8 طبقه ، 6 سال ساخت',
    agent: 'فرهوم گروپ',
    agentPhone: '09115800059',  
    features: [' کاربری : مسکونی | جهت دریافت مشاوره با کارشناسان ما تماس بگیرید'],
    dateAdded: '2025-09-04'
  },
];
  //{
    //id: '',
    //title: '',
    //location: '',
    //priceValue: 0,
    //type: 'buy',
    //propertyType: 'penthouse',
    //bedrooms: 2,
    //bathrooms: 2,
    //sqft: 174,
    //furnished: false,
    //images: [
      //'',
      //'',
      //'',
      //'',




    //],
    //description: '',
    //agent: 'کارشناسان فرهوم',
    //agentPhone: '09335317304',
    //features: ['کاربری : تجاری'],
    //dateAdded: '2025-07-19'
  //},
 

export const agents: Agent[] = [
  {
    id: '1',
    name: 'Iman Khorshidi',
    image: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Main-Team/imankh.jpg?updatedAt=1752169677598',
    phone: '+989113562491',
    email: 'iman.khorshidi@farhome.ir',
    specialization: 'Marketing',
    experience: '3 سال',
    languages: ['Farsi'],
    rating: 0,
    reviewCount: 0
  },
  {
    id: '2',
    name: 'Abolfazl Nori',
    image: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Main-Team/aboln.jpg?updatedAt=1752169730898',
    phone: '+989114090087',
    email: 'support@farhome.ir',
    specialization: 'Marketing',
    experience: '1 سال',
    languages: ['Farsi'],
    rating: 0,
    reviewCount: 0
  },
  //{
    //id: '4',
    //name: 'Nita Hashemi',
    //image: '',
    //phone: '+989965921325',
    //email: 'support@farhome.ir',
    //specialization: 'Office secretary',
    //experience: '1 years',
    //languages: ['Farsi'],
    //rating: 0,
    //reviewCount: 0
  //},
];