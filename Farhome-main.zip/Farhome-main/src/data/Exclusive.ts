export interface ExclusiveProject {
  id: string;
  title: string;
  excerpt: string;
  description: string;
  otherDescription?: string;
  developer: string;
  date: string;
  category: string;
  location: string;
  contactNumbers: string[];
  images: string[];
  videos?: string[];
  brochureUrl?: string;
  modelUrl?: string;
}

export const exclusiveProjects: ExclusiveProject[] = [
  {
    id: 'project1',
    title: 'ملک مسکونی با معماری مدرن',
    excerpt: 'این ملک زیبا با طراحی معماری کم‌نظیر، تمامی فاکتورهای یک سازه لوکس و بی‌نقص را در خود جای داده است. ',
    description: 'فرهوم به عنوان عاملیت فروش انحصاری پروژه نام برده فعالیت می‌کند',
    otherDescription: 'پیش‌فروش برج مسکونی لوکس در کوچه بن‌بست، شامل تنها ۴ پلاک زمین و طراحی مدرن وافل بی‌ستون؛ این پروژه دارای پارکینگ منفی با رمپ استاندارد، همکف با لابی با سقف ۵ متر و اتاق ورزش و بخار، طبقات با سقف ۴ متر، کلیه نورها لاین مگنتی، سرویس‌های حمام و مستر اسلپ، کف سرامیک یک متری اسپانیا و اسانسور سوپر سالن و موتور ایتالیا است. فاضلاب بوش فیت آلمان، سرمایش وی‌آر‌اف، نما با بهترین متریال، پنجره‌ها ترمال آلومینیوم با یراق اسپانیایی رنگ مشکی، ارتفاع درب‌ها ۳ متر، دستگیره‌های مدرن، ورودی‌ها الکترونیک فلاندی فیلیپس، درب‌های ضدحریق و ضدسرقت عالی، شیرآلات توکار دکمه‌ای راسان و فضای سبز فوق‌العاده در پشت‌بام از دیگر امکانات برج هستند.',
    developer: 'دفتر فروش : فرهوم',
    date: '2025-07-19',
    category: 'مسکونی',
    location: 'ساری، خیابان سلمان فارسی',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2238.jpg?updatedAt=1752952326663',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2241.jpg?updatedAt=1752952328038',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2242.jpg?updatedAt=1752952327068',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2246.jpg?updatedAt=1752952328090',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2247.jpg?updatedAt=1752952328521',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2254.jpg?updatedAt=1752952326528',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2259.jpg?updatedAt=1752952327692',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2260.jpg?updatedAt=1752952328281',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/IMG_2273.jpg?updatedAt=1752952328186',
      

    ],
    brochureUrl: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/Loghmani/3d.pdf?updatedAt=1752953042272',
    modelUrl: '/3d-tours/marina-bay'
  },
  {
    id: 'project2',
    title: 'برج مسکونی لوکس در سرخ‌رود',
    excerpt: 'پیش‌فروش برج مسکونی لوکس در سرخ‌رود میدان نسیم و خط دریا',
    description: 'فرهوم به عنوان عاملیت فروش انحصاری پروژه نام برده فعالیت می‌کند',
    otherDescription: 'پیش‌فروش برج مسکونی لوکس در سرخرود، میدان نسیم و خط دریا؛ این برج ۱۷ طبقه با طراحی مدرن و چشم‌انداز بی‌نظیر، از طبقه اول تا سیزدهم سه‌واحدی و از طبقه سیزدهم به بالا دو‌واحدی ارائه می‌دهد. واحدها شامل تیپ‌های ۱۱۵، ۱۴۵ و ۱۶۵ متری نما‌دار و همچنین پنت‌هاوس‌های ۱۹۵ و ۲۲۵ متری با ویوی تمام‌قد دریا هستند. امکانات برج شامل استخر، جکوزی و باشگاه روی بام است و موقعیت عالی آن امکان ترکیب آرامش ساحل با دسترسی راحت به مراکز شهری را فراهم می‌کند. این پروژه فرصتی استثنایی برای سرمایه‌گذاری و زندگی لوکس در شمال کشور به شمار می‌رود.',
    developer: 'دفتر فروش : فرهوم',
    date: '2025-08-21',
    category: 'مسکونی',
    location: 'سرخرود ، سرخ‌رود ، sorkhrud',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/FINALL-RENDER01(P).jpg?updatedAt=1755801160812',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/FINALL-RENDER05(P).jpg?updatedAt=1755801165687',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/FINALL-RENDER06.jpg?updatedAt=1755801144890',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/map.png?updatedAt=1755801316556',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/WhatsApp%20Image%202025-08-21%20at%2019.02.30_3fb1a0d8.jpg?updatedAt=1755801220272',



    ],
    brochureUrl: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/bruchure.pdf?updatedAt=1755801338185',
    modelUrl: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Exclusive/sorkhrood/WhatsApp%20Image%202025-08-21%20at%2019.02.30_3fb1a0d8.jpg?updatedAt=1755801220272'
  }
];