export interface FeaturedProject {
  id: string;
  title: string;
  excerpt: string;
  description: string;
  otherDescription?: string;
  developer: string;
  date: string;
  category: string;
  location: string;
  contactNumbers: string[];
  images: string[];
  videos?: string[];
  brochureUrl?: string;
  modelUrl?: string;
}

export const featuredData: FeaturedProject[] = [
  {
    id: 'featured1',
    title: 'پنت هاوس تجاری',
    excerpt: '** فروخته شد **',
    description: "",
    otherDescription: 'جهت دریافت مشاوره با کارشناسان ما تماس بگیرید',
    developer: 'عاملیت فروش : فرهوم- قیمت : ۱۶٫۰۰۰٫۰۰۰٫۰۰۰ تومان',
    date: '2025-07-09',
    category: 'ملک ممتاز، تجاری، پنت‌هاوس',
    location: 'ساری، خیابان شهابی، sari ',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022-soldout/soldout-022-1-b.jpg?updatedAt=1756985349104',
    ],
    brochureUrl: '/downloads/featured1-brochure.pdf',
    modelUrl: '/3d-tours/featured1'
  },
    {
    id: 'featured2',
    title: 'ویلای مسکونی جاده فرح آباد',
    excerpt: ' کد فایل : f-0012',
    description: " 200 متر  دوبلکس + 200 متر زمین، خواب :2 ، سرویس :2 ",
    otherDescription: 'جهت دریافت مشاوره با کارشناسان ما تماس بگیرید',
    developer: 'عاملیت فروش : فرهوم، قیمت : ۱۲٫۰۰۰٫۰۰۰٫۰۰۰',
    date: '2025-07-20',
    category: 'ویلا، مسکونی ',
    location: 'ساری ، کیلومتر ۶ جاده فرح آباد، f-0012',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/2.jpg?updatedAt=1752974556526',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/4.jpg?updatedAt=1752974556469',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/1.jpg?updatedAt=1752974556510',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/3.jpg?updatedAt=1752974556129',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/4.jpg?updatedAt=1752974556469',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/5.jpg?updatedAt=1752974556501',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/6.jpg?updatedAt=1752974556478',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/7.jpg?updatedAt=1752974556649',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/8.jpg?updatedAt=1752974556506',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/9.jpg?updatedAt=1752974556198',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/10.jpg?updatedAt=1752974556315',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/11.jpg?updatedAt=1752974559921',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/12.jpg?updatedAt=1752974559787',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0012/13.jpg?updatedAt=1752974560026',


    ],
    brochureUrl: '/downloads/featured1-brochure.pdf',
    modelUrl: '/3d-tours/featured1'
  },
    {
    id: 'featured3',
    title: ' ویلای مسکونی جاده پلاژ',
    excerpt: 'کد فایل : f-0036',
    description: "متراژ : ۳۳۰ متر بنا ، ۲۳۰ متر زمین، تعداد طبقات : تریپلکس، سال ساخت : 1404، استخر در همکف، 3 خواب ، 2 سرویس",
    otherDescription: 'جهت دریافت مشاوره با کارشناسان ما تماس بگیرید',
    developer: 'عاملیت فروش : فرهوم، قیمت : ۱۵٫۰۰۰٫۰۰۰٫۰۰۰',
    date: '2025-07-28',
    category: 'ویلا، مسکونی ',
    location: 'ساری ، جاده پلاژ، sari , f-0036',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/1.jpg?updatedAt=1753704079848',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/1%20(2).jpg?updatedAt=1753704083472',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/2.jpg?updatedAt=1753704077402',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/3.jpg?updatedAt=1753704080272',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/5.jpg?updatedAt=1753704082486',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/6.jpg?updatedAt=1753704083594',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/7.jpg?updatedAt=1753704084414',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/8.jpg?updatedAt=1753704084722',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/9.jpg?updatedAt=1753704079920',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/10.jpg?updatedAt=1753704081064',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/11.jpg?updatedAt=1753704076664',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/12.jpg?updatedAt=1753704079523',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/13.jpg?updatedAt=1753704080844',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/14.jpg?updatedAt=1753704077235',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0036/15.jpg?updatedAt=1753704079305',


    ],
    brochureUrl: '/downloads/featured1-brochure.pdf',
    modelUrl: '/3d-tours/featured1'
  },
    {
    id: 'featured4',
    title: 'اپارتمان مسکونی 220 متری بلوار خزر ساری',
    excerpt: 'کد فایل : f-089',
    description: "تعداد طبقات : ۷ ط / ۱۳ واحد، سال ساخت : صفر، طبقه دوم و سوم، 3 خواب، 2 سرویس، 220 متر مربع ",
    otherDescription: 'جهت دریافت مشاوره با کارشناسان ما تماس بگیرید',
    developer: 'عاملیت فروش : فرهوم، قیمت : ۹٫۰۰۰٫۰۰۰٫۰۰۰ تومان',
    date: '2025-07-28',
    category: 'اپارتمان، مسکونی ',
    location: 'ساری ، بلوار خزر، sari , f-089',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/1.jpg?updatedAt=1753705699917',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/2.jpg?updatedAt=1753705700690',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/3.jpg?updatedAt=1753705699657',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/4.jpg?updatedAt=1753705700536',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/5.jpg?updatedAt=1753705700914',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/6.jpg?updatedAt=1753705701070',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/7.jpg?updatedAt=1753705700255',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/8.jpg?updatedAt=1753705700075',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/9.jpg?updatedAt=1753705699807',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/10.jpg?updatedAt=1753705700020',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/089/11.jpg?updatedAt=1753705704454',


    ],
    brochureUrl: '/downloads/featured1-brochure.pdf',
    modelUrl: '/3d-tours/featured1'
  },
    {
    id: 'featured5',
    title: 'تجاری 115 متری در سلمان فارسی',
    excerpt: 'کد فایل : f-079',
    description: "امکانات : فول، سال ساخت : صفر، تعداد طبقات : ۱۰ طبقه / ۲۰ واحد، 2 خواب، 1 سرویس",
    otherDescription: 'جهت دریافت مشاوره با کارشناسان ما تماس بگیرید',
    developer: 'عاملیت فروش : فرهوم، قیمت : ۸٫۰۰۰٫۰۰۰٫۰۰۰ تومان',
    date: '2025-07-28',
    category: 'اپارتمان، تجاری ',
    location: 'ساری ، سلمان فارسی، sari, f-079',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/1.jpg?updatedAt=1753706287446',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/2.jpg?updatedAt=1753706285032',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/3.jpg?updatedAt=1753706286759',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/4.jpg?updatedAt=1753706284980',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/5.jpg?updatedAt=1753706286203',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/6.jpg?updatedAt=1753706286662',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/7.jpg?updatedAt=1753706286773',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/8.jpg?updatedAt=1753706285328',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/9.jpg?updatedAt=1753706284965',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/10.jpg?updatedAt=1753706286519',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/11.jpg?updatedAt=1753706290984',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/12.jpg?updatedAt=1753706290653',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/13.jpg?updatedAt=1753706292055',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/14.jpg?updatedAt=1753706292192',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/15.jpg?updatedAt=1753706291938',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/16.jpg?updatedAt=1753706292322',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/17.jpg?updatedAt=1753706291964',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/079/18.jpg?updatedAt=1753706292627',


    ],
    brochureUrl: '/downloads/featured1-brochure.pdf',
    modelUrl: '/3d-tours/featured1'
  },
    {
    id: 'featured6',
    title: 'اپارتمان مسکونی 300 متری سلمان فارسی',
    excerpt: 'کد فایل : f-076',
    description: "تعداد طبقات : ۹ طبقه / ۹ واحد، سال ساخت : ۱۴۰۳، 4 خواب، 3 سرویس، 300 متر مربع ",
    otherDescription: 'جهت دریافت مشاوره با کارشناسان ما تماس بگیرید',
    developer: 'عاملیت فروش : فرهوم، قیمت : ۱۸٫۰۰۰٫۰۰۰٫۰۰۰ تومان',
    date: '2025-07-29',
    category: 'اپارتمان، مسکونی ',
    location: 'sari , f-076 , ساری ، سلمان فارسی',
    contactNumbers: ['09115800059'],
    images: [
     'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/1.jpg?updatedAt=1753740937566',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/2.jpg?updatedAt=1753740940099',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/3.jpg?updatedAt=1753740941936',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/4.jpg?updatedAt=1753740938137',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/5.jpg?updatedAt=1753740941310',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/6.jpg?updatedAt=1753740939224',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/7.jpg?updatedAt=1753740938701',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/8.jpg?updatedAt=1753740940708',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/9.jpg?updatedAt=1753740943216',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/10.jpg?updatedAt=1753740942605',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/11.jpg?updatedAt=1753740935352',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/12.jpg?updatedAt=1753740936359',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/076/13.jpg?updatedAt=1753740936972',


    ],
    brochureUrl: '/downloads/featured1-brochure.pdf',
    modelUrl: '/3d-tours/featured1'
  },
    {
    id: 'featured7',
    title: 'اپارتمان 180 متری سلمان فارسی',
    excerpt: ' کد فایل : f-0106',
    description: " تعداد طبقات : ۱۲ طبقه / ۲۰ واحد، سال ساخت : 1404، طبقه دوم نما، 3 خواب، 2 سرویس، 180 متر مربع ",
    otherDescription: 'جهت دریافت مشاوره با کارشناسان ما تماس بگیرید',
    developer: 'عاملیت فروش : فرهوم، قیمت : ۱۲٫۶۰۰٫۰۰۰٫۰۰۰ تومان',
    date: '2025-07-29',
    category: 'اپارتمان، مسکونی ',
    location: 'ساری ، سلمان فارسی ، sari , f-106',
    contactNumbers: ['09115800059'],
    images: [
            'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/1.jpg?updatedAt=1753742019583',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/2.jpg?updatedAt=1753741994029',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/3.jpg?updatedAt=1753742004476',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/4.jpg?updatedAt=1753741987630',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/5.jpg?updatedAt=1753741990995',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/6.jpg?updatedAt=1753741989653',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/7.jpg?updatedAt=1753741998078',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/8.jpg?updatedAt=1753741994631',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/9.jpg?updatedAt=1753741992620',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/10.jpg?updatedAt=1753741994430',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/11.jpg?updatedAt=1753742022779',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/12.jpg?updatedAt=1753742013112',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/13.jpg?updatedAt=1753742023286',


    ],
    brochureUrl: 'https://www.farhome.ir/404.html',
    modelUrl: 'https://www.farhome.ir/404.html'
  },
  {
    id: 'featured8',
    title: 'ویلا در شهرک اختصاصی اکسیژن (مرزن آباد)',
    excerpt: ' کد فایل : f-0044',
    description: " در شهرک اختصاصی سفیدکوهک مرزن‌آباد (شهر اکسیژن)، ویلای دوبلکس ۳۵۰ متری روی زمینی ۹۰۰ متری آماده واگذاری است. این ویلا دارای سه خواب مستر، کف پارکت چوب روسی، پنجره‌های قدی با کرکره برقی و اسپیلت در تمام اتاق‌هاست. امکانات کامل شامل آب چشمه، دو کنتور برق ۳۲ آمپر، موتورخانه مرکزی، سیستم دزدگیر، تراس با ویوی ابدی، آلاچیق و زمین بازی استاندارد محیطی امن و آرامش‌بخش ایجاد کرده است. ",
    otherDescription: 'ملک دارای سند تک‌برگ معتبر بوده و با قیمت ۴۵ میلیارد تومان عرضه می‌شود. همچنین امکان تهاتر با ملک یا خودرو نیز وجود دارد، دو عدد کنتور برق ۳۲ آمپر - انشعاب گاز و تلفن - سه خواب مستر - اسپیلت در تمام اتاق‌ها - گرمایش از موتورخانه مرکزی - آب چشمه - آلاچیق - تراس - زمین بازی استاندارد - امکان تهاتر با ماشین یا ملک - سند تک‌برگ - ویو ابدی - شهرک اختصاصی - ۹۰۰ متر زمین - ۳۵۰ متر بنا - مجهز به سیستم دزدگیر - سه خواب مستر با کمد دیواری، تخت کمدی و اسپیلت - کف‌پوش پارکت چوب روسی - پنجره‌ها با کرکره برقی، توری و پرده داخلی',
    developer: 'عاملیت فروش: فرهوم گروپ ، قیمت : ۴۵٫۰۰۰٫۰۰۰٫۰۰۰ تومان',
    date: '2025-08-21',
    category: 'ممتاز',
    location: ' شهر اکسیژن (مرزن‌آباد) منطقه‌ی سفیدکوهک، f-0044 ، marzan abad',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/1.jpg?updatedAt=1755798636356',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/2.jpg?updatedAt=1755798635140',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/3.jpg?updatedAt=1755798640796',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/4.jpg?updatedAt=1755798638761',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/5.jpg?updatedAt=1755798640600',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/6.jpg?updatedAt=1755798637151',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/7.jpg?updatedAt=1755798636818',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/8.jpg?updatedAt=1755798634458',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/9.jpg?updatedAt=1755798635073',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/10.jpg?updatedAt=1755798637546',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/11.jpg?updatedAt=1755798644801',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/Sari/0044/12.jpg?updatedAt=1755798645244',
    
    


    ],
    brochureUrl: 'https://www.farhome.ir/404.html',
    modelUrl: 'https://www.farhome.ir/404.html'
  },
    {
    id: 'featured9',
    title: 'آپارتمان ۲۰۰ متری در ساختمانی برند',
    excerpt: ' کد فایل : f-022',
    description: "دارای ۲ لاین آسانسور / دراری ژنراتور برق ",
    otherDescription: ' ۸ طبقه / ۱۶ واحد، 3 خواب، 200 متر، سال ساخت : ۶ سال',
    developer: 'عاملیت فروش: فرهوم گروپ ، قیمت : ۱۰٫۰۰۰٫۰۰۰٫۰۰۰ تومان',
    date: '2025-09-04',
    category: 'ممتاز',
    location: ' ساری ، میدان سلمان فارسی ، ساختمان ایساتیس ، sari , f-022',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/1.jpg?updatedAt=1756987504773',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/2.jpg?updatedAt=1756987504269',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/3.jpg?updatedAt=1756987504306',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/4.jpg?updatedAt=1756987505168',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/5.jpg?updatedAt=1756987426858',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/6.jpg?updatedAt=1756987503262',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/7.jpg?updatedAt=1756987504499',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/8.jpg?updatedAt=1756987432174',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/022/9.jpg?updatedAt=1756987505169',



    ],
    brochureUrl: 'https://www.farhome.ir/404.html',
    modelUrl: 'https://www.farhome.ir/404.html'
  },
      {
    id: 'featured10',
    title: 'فروش ویژه ملک صنعتی – اداری در موقعیت ممتاز',
    excerpt: ' کد فایل : f-0046',
    description: "یک فرصت استثنایی برای سرمایه‌گذاران و صاحبان صنعت! ملکی با مساحت ۷۸۰۰ متر زمین و ۲۵۰۰ متر سوله استاندارد در بهترین نقطه صنعتی منطقه، واقع در جاده بابل به بابلسر، هادی‌شهر، کوچه صنعت، جنب کارخانه فرش و موکت بابل.",
    otherDescription: ' این ملک علاوه بر سوله، امکانات کامل و کم‌نظیری دارد:  • ویلای اقامتی مجهز  • ساختمان سرایداری و نگهبانی مستقل  • ساختمان مدیریت  • لابراتوار تخصصی  • آشپزخانه صنعتی  • چاه آب  • برق و گاز صنعتی موقعیت عالی، دسترسی راحت و امکانات کامل، این ملک را به گزینه‌ای ایده‌آل برای راه‌اندازی یا توسعه کسب‌وکارهای صنعتی و تولیدی تبدیل کرده است',
    developer: 'عاملیت فروش: فرهوم گروپ ، ۷۸۰۰ متر زمین ۲۵۰۰ متر سوله - ویلای اقامتی- سرایداری - نگهبانی - لابراتوار  - ساختمان مدیریت  - آشپزخانه  - چاه - برق و گاز صنعتی، قیمت : تماس بگیرید',
    date: '2025-09-04',
    category: 'ممتاز',
    location: ' بابل به بابلسر،  هادی شهر، کوچه صنعت،  جنب کارخانه فرش و موکت بابل ، babol , f-0046',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-03.jpg?updatedAt=1756988157032',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-02.jpg?updatedAt=1756988157699',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-41-59.jpg?updatedAt=1756988155695',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-05.jpg?updatedAt=1756988161576',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-06.jpg?updatedAt=1756988162157',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0046/photo_2025-09-04_15-42-04.jpg?updatedAt=1756988162932',
      



    ],
    brochureUrl: 'https://www.farhome.ir/404.html',
    modelUrl: 'https://www.farhome.ir/404.html'
  },
        {
    id: 'featured11',
    title: 'فروش آپارتمان لوکس دوبلکس در آلانیا – برج گلد سیتی',
    excerpt: ' کد فایل : f-0144',
    description: "فرصتی بی‌نظیر برای خرید یا سرمایه‌گذاری در یکی از بهترین برج‌های آلانیا!",
    otherDescription: 'متراژ: ۱۴۰ متر -  دارای ۲ خواب مستر - دوبلکس شیک و مدرن - واقع در طبقه ۱۳ برج لوکس گلد سیتی - فول فرنیش (مبله کامل و آماده سکونت) - خدمات هتلی در مجموعه - پارک آبی و استخر اختصاصی - لوکیشن ممتاز در شهر آلانیا، یک گزینه استثنایی برای زندگی لاکچری در ترکیه یا سرمایه‌گذاری پرسود!',
    developer: 'عاملیت فروش: فرهوم گروپ، قیمت: ۱۸۰,۰۰۰ دلار، امکان تهاتر با ملک در ساری  ',
    date: '2025-09-04',
    category: 'ممتاز',
    location: ' turkey , alanya ، آلانیا ترکیه , f-0144',
    contactNumbers: ['09115800059'],
    images: [
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/1.jpg?updatedAt=1756988668677',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/2.jpg?updatedAt=1756988659551',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/3.jpg?updatedAt=1756988669700',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/4.jpg?updatedAt=1756988668853',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/5.jpg?updatedAt=1756988666219',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/6.jpg?updatedAt=1756988668720',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/7.jpg?updatedAt=1756988665002',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/8.jpg?updatedAt=1756988663054',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/9.jpg?updatedAt=1756988668653',
      'https://ik.imagekit.io/amirfaramarzpour/Fardad/Files/VIP/0144/10.jpg?updatedAt=1756988662473',


    ],
    brochureUrl: 'https://www.farhome.ir/404.html',
    modelUrl: 'https://www.farhome.ir/404.html'
  },
];