import React, { useState } from 'react';
import { Calendar, Clock, User, Tag, ChevronLeft, ChevronRight, Share2, Download, X, Maximize2, Minimize2 } from 'lucide-react';
import { BlogPost } from '../data/Blog';
import { useLanguage } from '../contexts/LanguageContext';

interface BlogCardProps {
  post: BlogPost;
  onExpand: (id: string) => void;
  isExpanded: boolean;
  onClose: () => void;
}

const BlogCard: React.FC<BlogCardProps> = ({ post, onExpand, isExpanded, onClose }) => {
  const { t } = useLanguage();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isExcerptExpanded, setIsExcerptExpanded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleShare = async () => {
    const url = `${window.location.origin}#${post.id}`;
    try {
      await navigator.clipboard.writeText(url);
      alert('URL copied to clipboard!');
    } catch (err) {
      alert(`Share this URL: ${url}`);
    }
  };

  const handleDownload = () => {
    const content = `${post.title}\n\nBy: ${post.author}\nDate: ${post.date}\nCategory: ${post.category}\n\n${post.description}${post.otherDescription ? '\n\n' + post.otherDescription : ''}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${post.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % post.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + post.images.length) % post.images.length);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex items-center justify-center animate-fade-in">
        <div className="relative w-full h-full">
          <img
            src={post.images[currentImageIndex]}
            alt={post.title}
            className="w-full h-full object-contain"
          />
          <button
            onClick={toggleFullscreen}
            className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors duration-200"
          >
            <Minimize2 className="w-6 h-6" />
          </button>
          {post.images.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {post.images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  if (isExpanded) {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
        <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-scale-in">
          <div className="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white pr-4">
              {post.title}
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200"
            >
              <X className="w-6 h-6 text-gray-500" />
            </button>
          </div>

          <div className="p-6">
            <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-6">
              <div className="flex items-center gap-1">
                <User className="w-4 h-4" />
                {post.author}
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {post.date}
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {post.readTime} {t('readTime')}
              </div>
              <div className="flex items-center gap-1">
                <Tag className="w-4 h-4" />
                {post.category}
              </div>
            </div>

            {post.images.length > 0 && (
              <div className="relative mb-6">
                <div className="relative">
                  <img
                    src={post.images[currentImageIndex]}
                    alt={post.title}
                    className="w-full h-64 object-cover rounded-lg cursor-pointer"
                    onClick={toggleFullscreen}
                  />
                  <button
                    onClick={toggleFullscreen}
                    className="absolute top-2 right-2 p-2 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors duration-200"
                  >
                    <Maximize2 className="w-5 h-5" />
                  </button>
                </div>
                {post.images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      {post.images.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                            index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            <div className="prose dark:prose-invert max-w-none mb-6">
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-justify whitespace-pre-line">
                {post.description}
              </p>
              {post.otherDescription && (
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-justify whitespace-pre-line mt-4">
                  {post.otherDescription}
                </p>
              )}
            </div>

            <div className="flex items-center gap-4 pt-6 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={handleShare}
                className="flex items-center gap-2 btn-secondary"
              >
                <Share2 className="w-4 h-4" />
                {t('shareUrl')}
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center gap-2 btn-secondary"
              >
                <Download className="w-4 h-4" />
                {t('downloadDesc')}
              </button>
              {post.referenceLink && (
                <a
                  href={post.referenceLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary-600 hover:text-primary-700 font-medium"
                >
                  View Reference
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card overflow-hidden group hover:scale-105 transition-all duration-300 animate-fade-in">
      <div className="relative overflow-hidden">
        <img
          src={post.images[0]}
          alt={post.title}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute top-4 right-4">
          <span className="px-3 py-1 bg-primary-600 text-white rounded-full text-xs font-semibold">
            {post.category}
          </span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 line-clamp-2 group-hover:text-primary-600 transition-colors duration-200">
          {post.title}
        </h3>

        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-4">
          <div className="flex items-center gap-1">
            <User className="w-4 h-4" />
            {post.author}
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            {post.date}
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {post.readTime} {t('readTime')}
          </div>
        </div>

        <p className="text-gray-600 dark:text-gray-400 mb-4 text-justify">
          {isExcerptExpanded ? post.excerpt : `${post.excerpt.substring(0, 120)}...`}
        </p>

        <div className="flex items-center justify-between">
          <button
            onClick={() => setIsExcerptExpanded(!isExcerptExpanded)}
            className="text-primary-600 hover:text-primary-700 text-sm font-medium"
          >
            {isExcerptExpanded ? t('readLess') : t('readMore')}
          </button>
          <button
            onClick={() => onExpand(post.id)}
            className="btn-primary text-sm py-2 px-4"
          >
            {t('ReadFullArticle')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default BlogCard;