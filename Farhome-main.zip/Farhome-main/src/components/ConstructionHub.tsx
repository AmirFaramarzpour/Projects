import React from 'react';
import { Hammer, MapPin, Phone, Calendar, Download, X, ChevronLeft, ChevronRight, User, Share2, Maximize, Globe, Youtube, TwitchIcon, Instagram, Twitch, YoutubeIcon } from 'lucide-react';
import { hubPosts } from '../data/Hub';
import { useLanguage } from '../contexts/LanguageContext';

interface ConstructionHubProps {
  expandedItem: { type: string; id: string } | null;
  onExpand: (type: string, id: string) => void;
  onClose: () => void;
}

const ConstructionHub: React.FC<ConstructionHubProps> = ({ expandedItem, onExpand, onClose }) => {
  const { t } = useLanguage();
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);
  const [isFullscreen, setIsFullscreen] = React.useState(false);
  const [isBookmarked, setIsBookmarked] = React.useState(false);

  const expandedPost = expandedItem?.type === 'hubpost' 
    ? hubPosts.find(p => p.id === expandedItem.id)
    : null;

  const nextImage = () => {
    if (expandedPost) {
      setCurrentImageIndex((prev) => (prev + 1) % expandedPost.images.length);
    }
  };

  const prevImage = () => {
    if (expandedPost) {
      setCurrentImageIndex((prev) => (prev - 1 + expandedPost.images.length) % expandedPost.images.length);
    }
  };

  const handleShare = async () => {
    const url = `${window.location.origin}${window.location.pathname}#${expandedPost?.id}`;
    try {
      await navigator.clipboard.writeText(url);
      alert('URL copied to clipboard!');
    } catch (err) {
      alert(`Share this URL: ${url}`);
    }
  };

  const handleFullscreen = () => {
    setIsFullscreen(true);
  };

  const handleCloseFullscreen = () => {
    setIsFullscreen(false);
  };

  const handleBookmark = () => {
    if (expandedPost?.website) {
      window.open(`https://${expandedPost.website}`, '_blank');
    }
  };

  const handleContact = () => {
    if (expandedPost && expandedPost.contactNumbers.length > 0) {
      window.open(`tel:${expandedPost.contactNumbers[1]}`, '_self');
    }
  };

  const handleWhatsApp = () => {
    if (expandedPost && expandedPost.contactNumbers.length > 0) {
      window.open(`https://wa.me/${expandedPost.contactNumbers[0].replace(/[^\d]/g, '')}`, '_blank');
    }
  };

  const handleInstagram = () => {
    if (expandedPost?.instagram) {
      window.open(expandedPost.instagram, '_blank');
    }
  };

  const handleTeaser = () => {
    if (expandedPost?.teaserUrl) {
      window.open(expandedPost.teaserUrl, '_blank');
    }
  };

  React.useEffect(() => {
    setCurrentImageIndex(0);
    setIsBookmarked(false);
  }, [expandedPost]);

  // Handle fullscreen keyboard events
  React.useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (isFullscreen) {
        if (e.key === 'Escape') {
          handleCloseFullscreen();
        } else if (e.key === 'ArrowLeft') {
          prevImage();
        } else if (e.key === 'ArrowRight') {
          nextImage();
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isFullscreen, expandedPost]);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          {t('constructionHub')}
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          {t('Connectwith')}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {hubPosts.map((post, index) => (
          <div 
            key={post.id} 
            className="card overflow-hidden group hover:scale-105 transition-all duration-300 animate-fade-in"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="relative overflow-hidden">
              <img
                src={post.images[0]}
                alt={post.title}
                className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 bg-secondary-600 text-white rounded-full text-xs font-semibold">
                  {post.category}
                </span>
              </div>
            </div>

            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-secondary-600 transition-colors duration-200">
                {post.title}
              </h3>

              <div className="space-y-2 mb-2 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  {post.author}
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {post.location}
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {post.date}
                </div>
              </div>

              <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                {post.excerpt.split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}
              </p>

              <div className="flex items-center gap-2 mb-4">
                {post.contactNumbers.map((number, idx) => (
                  <a
                    key={idx}
                    href={`tel:${number}`}
                    className="flex items-center gap-1 text-xs bg-secondary-100 dark:bg-secondary-900 text-secondary-800 dark:text-secondary-200 px-2 py-1 rounded-full hover:bg-secondary-200 dark:hover:bg-secondary-800 transition-colors duration-200"
                  >
                    <Phone className="w-3 h-3" />
                    {number}
                  </a>
                ))}
              </div>

              <button
                onClick={() => onExpand('hubpost', post.id)}
                className="w-full btn-secondary"
              >
                {t('learnMore')}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Fullscreen Image Modal */}
      {isFullscreen && expandedPost && (
        <div className="fixed inset-0 bg-black z-[60] flex items-center justify-center animate-fade-in">
          <button
            onClick={handleCloseFullscreen}
            className="absolute top-4 right-4 z-10 p-3 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors duration-200"
          >
            <X className="w-6 h-6" />
          </button>
          
          <img
            src={expandedPost.images[currentImageIndex]}
            alt={expandedPost.title}
            className="max-w-full max-h-full object-contain"
          />
          
          {expandedPost.images.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors duration-200"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors duration-200"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {expandedPost.images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
          
          <div className="absolute bottom-4 right-4 text-white text-sm bg-black/50 px-3 py-1 rounded-full">
            {currentImageIndex + 1} / {expandedPost.images.length}
          </div>
        </div>
      )}

      {/* Main Modal */}
      {expandedPost && !isFullscreen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-scale-in">
            <div className="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white pr-4">
                {expandedPost.title}
              </h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200"
              >
                <X className="w-6 h-6 text-gray-500" />
              </button>
            </div>

            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="space-y-3 text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-2">
                      <User className="w-5 h-5" />
                      <span><strong>{t('Author')}</strong> {expandedPost.author}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      <span>{expandedPost.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-5 h-5" />
                      <span><strong>{t('Date')}</strong> {expandedPost.date}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">{t('ContactNumbers')}</h4>
                  <div className="space-y-1">
                    {expandedPost.contactNumbers.map((number, idx) => (
                      <a
                        key={idx}
                        href={`tel:${number}`}
                        className="flex items-center gap-2 text-secondary-600 hover:text-secondary-700 transition-colors duration-200"
                      >
                        <Phone className="w-4 h-4" />
                        {number}
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              {/* Image Gallery */}
              <div className="relative mb-6">
                <img
                  src={expandedPost.images[currentImageIndex]}
                  alt={expandedPost.title}
                  className="w-full h-64 object-cover rounded-lg cursor-pointer"
                  onClick={handleFullscreen}
                />
                <button
                  onClick={handleFullscreen}
                  className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                  title="View Fullscreen"
                >
                  <Maximize className="w-4 h-4" />
                </button>
                {expandedPost.images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      {expandedPost.images.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                            index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>

              <div className="prose dark:prose-invert max-w-none mb-6">
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  {expandedPost.description.split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}
                </p>
                {expandedPost.otherDescription && (
                  <p className="text-gray-700 dark:text-gray-300 leading-relaxed mt-4">
                    {expandedPost.otherDescription.split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button
                  onClick={handleShare}
                  className="flex items-center justify-center gap-2 btn-secondary text-sm py-2 px-3"
                >
                  <Share2 className="w-4 h-4" />
                  اشتراک‌ گذاری 
                </button>
                
                <button
                  onClick={handleBookmark}
                  className={`flex items-center justify-center gap-2 text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200 ${
                    isBookmarked 
                      ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' 
                      : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <Globe className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                  {isBookmarked ? 'Visited Website' : 'وبسایت شرکت'}
                </button>

                <button
                  onClick={handleContact}
                  className="flex items-center justify-center gap-2 bg-secondary-600 hover:bg-secondary-700 text-white text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200"
                >
                  <Phone className="w-4 h-4" />
                  تماس با دفتر مرکزی
                </button>

                <button
                  onClick={handleWhatsApp}
                  className="flex items-center justify-center gap-2 bg-yellow-100 hover:bg-yellow-200 dark:bg-yellow-900 dark:hover:bg-yellow-800 text-yellow-800 dark:text-yellow-200 text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200"
                >
                  <TwitchIcon className="w-4 h-4" />
                  واتساپ
                </button>

                <button
                  onClick={handleInstagram}
                  className="flex items-center justify-center gap-2 bg-pink-100 hover:bg-pink-200 dark:bg-pink-900 dark:hover:bg-pink-800 text-pink-800 dark:text-pink-200 text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200"
                >
                  <Instagram className="w-4 h-4" />
                  صفحه رسمی در اینستاگرام
                </button>

                {expandedPost.teaserUrl && (
                  <button
                    onClick={handleTeaser}
                    className="flex items-center justify-center gap-2 btn-secondary text-sm py-2 px-3"
                  >
                    <Youtube className="w-4 h-4" />
                    مشاهده تیزر مجموعه 
                  </button>
                )}

                {expandedPost.brochureUrl && (
                  <button
                    onClick={() => window.open(expandedPost.brochureUrl, '_blank')}
                    className="flex items-center justify-center gap-2 btn-secondary text-sm py-2 px-3"
                  >
                    <Download className="w-4 h-4" />
                    دانلود کاتالوگ و بروشور محصولات
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConstructionHub;