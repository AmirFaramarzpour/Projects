import React from 'react';
import { Phone, Mail, MessageCircle, Languages } from 'lucide-react';
import { Agent } from '../data/MockData';
import { useLanguage } from '../contexts/LanguageContext';

interface AgentCardProps {
  agent: Agent;
}

const AgentCard: React.FC<AgentCardProps> = ({ agent }) => {
  const { t } = useLanguage();
  const specializationKey = agent.specialization.replace(/\s/g, '');

  return (
    <div className="card p-6 text-center group hover:scale-105 transition-all duration-300 animate-fade-in">
      <div className="relative mb-6">
        <img
          src={agent.image}
          alt={agent.name}
          className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-white dark:border-gray-700 shadow-lg group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
          <div className="bg-primary-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
            {agent.experience}
          </div>
        </div>
      </div>

      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
        {t(agent.name.replace(/\s/g, ''))}
      </h3>
      
      <p className="text-primary-600 dark:text-primary-400 font-medium mb-4">
        {t(specializationKey) || agent.specialization}
      </p>

      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-center text-gray-600 dark:text-gray-400">
          <Languages className="w-4 h-4 mr-2" />
          <span className="text-sm">{agent.languages.join(', ')}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <a
          href={`tel:${agent.phone}`}
          className="flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white py-2 px-4 rounded-lg font-medium transition-all duration-200 hover:scale-105"
        >
          <Phone className="w-4 h-4" />
          <span className="hidden sm:inline">{t('Call')}</span>
        </a>
        <a
          href={`mailto:${agent.email}`}
          className="flex items-center justify-center gap-2 bg-gray-600 hover:bg-primary-500 text-white py-2 px-4 rounded-lg font-medium transition-all duration-200 hover:scale-105"
        >
          <Mail className="w-4 h-4" />
          <span className="hidden sm:inline">{t('Email')}</span>
        </a>
      </div>

      <a
        href={`https://wa.me/${agent.phone}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        <button className="w-full mt-3 flex items-center justify-center gap-2 bg-secondary-700 hover:bg-gray-800 dark:bg-secondary-700 dark:hover:bg-gray-100 text-gray-200 dark:text-gray-800 py-2 px-4 rounded-lg font-medium transition-all duration-200">
          <MessageCircle className="w-4 h-4" />
          {t('contactAgent')}
        </button>
      </a>
    </div>
  );
};

export default AgentCard;