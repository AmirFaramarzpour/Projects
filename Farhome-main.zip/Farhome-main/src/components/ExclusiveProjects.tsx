import React from 'react';
import { Building2, MapPin, Phone, Calendar, Download, ExternalLink as External, X, ChevronLeft, ChevronRight, Share2, Maximize, Heart, Bookmark, MessageCircle, Star, Eye } from 'lucide-react';
import { exclusiveProjects } from '../data/Exclusive';
import { useLanguage } from '../contexts/LanguageContext';

interface ExclusiveProjectsProps {
  expandedItem: { type: string; id: string } | null;
  onExpand: (type: string, id: string) => void;
  onClose: () => void;
}

const ExclusiveProjects: React.FC<ExclusiveProjectsProps> = ({ expandedItem, onExpand, onClose }) => {
  const { t } = useLanguage();
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);
  const [isFullscreen, setIsFullscreen] = React.useState(false);
  const [isFavorited, setIsFavorited] = React.useState(false);
  const [isBookmarked, setIsBookmarked] = React.useState(false);

  const expandedProject = expandedItem?.type === 'project' 
    ? exclusiveProjects.find(p => p.id === expandedItem.id)
    : null;

  const nextImage = () => {
    if (expandedProject) {
      setCurrentImageIndex((prev) => (prev + 1) % expandedProject.images.length);
    }
  };

  const prevImage = () => {
    if (expandedProject) {
      setCurrentImageIndex((prev) => (prev - 1 + expandedProject.images.length) % expandedProject.images.length);
    }
  };

  const handleShare = async () => {
    const url = `${window.location.origin}${window.location.pathname}#${expandedProject?.id}`;
    try {
      await navigator.clipboard.writeText(url);
      alert('URL copied to clipboard!');
    } catch (err) {
      alert(`Share this URL: ${url}`);
    }
  };

  const handleFullscreen = () => {
    setIsFullscreen(true);
  };

  const handleCloseFullscreen = () => {
    setIsFullscreen(false);
  };

  const handleFavorite = () => {
    setIsFavorited(!isFavorited);
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  const handleContact = () => {
    if (expandedProject && expandedProject.contactNumbers.length > 0) {
      window.open(`tel:${expandedProject.contactNumbers[0]}`, '_self');
    }
  };

  const handleRate = () => {
    alert('This feature coming soon!');
  };

  const handleViewCount = () => {
    alert('This feature coming soon!');
  };

  React.useEffect(() => {
    setCurrentImageIndex(0);
    setIsFavorited(false);
    setIsBookmarked(false);
  }, [expandedProject]);

  // Handle fullscreen keyboard events
  React.useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (isFullscreen) {
        if (e.key === 'Escape') {
          handleCloseFullscreen();
        } else if (e.key === 'ArrowLeft') {
          prevImage();
        } else if (e.key === 'ArrowRight') {
          nextImage();
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isFullscreen, expandedProject]);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          {t('exclusiveProjects')}
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          {t('Discoverpremium')}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {exclusiveProjects.map((project, index) => (
          <div 
            key={project.id} 
            className="card overflow-hidden group hover:scale-105 transition-all duration-300 animate-fade-in"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="relative overflow-hidden">
              <img
                src={project.images[0]}
                alt={project.title}
                className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 bg-primary-600 text-white rounded-full text-xs font-semibold">
                  {project.category}
                </span>
              </div>
            </div>

            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-primary-600 transition-colors duration-200">
                {project.title}
              </h3>

              <div className="space-y-2 mb-4 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  {project.developer}
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {project.location}
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {project.date}
                </div>
              </div>

              <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                {project.excerpt}
              </p>

              <div className="flex items-center gap-2 mb-4">
                {project.contactNumbers.map((number, idx) => (
                  <a
                    key={idx}
                    href={`tel:${number}`}
                    className="flex items-center gap-1 text-xs bg-secondary-100 dark:bg-secondary-900 text-secondary-800 dark:text-secondary-200 px-2 py-1 rounded-full hover:bg-secondary-200 dark:hover:bg-secondary-800 transition-colors duration-200"
                  >
                    <Phone className="w-3 h-3" />
                    {number}
                  </a>
                ))}
              </div>

              <button
                onClick={() => onExpand('project', project.id)}
                className="w-full btn-primary"
              >
                {t('learnMore')}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Fullscreen Image Modal */}
      {isFullscreen && expandedProject && (
        <div className="fixed inset-0 bg-black z-[60] flex items-center justify-center animate-fade-in">
          <button
            onClick={handleCloseFullscreen}
            className="absolute top-4 right-4 z-10 p-3 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors duration-200"
          >
            <X className="w-6 h-6" />
          </button>
          
          <img
            src={expandedProject.images[currentImageIndex]}
            alt={expandedProject.title}
            className="max-w-full max-h-full object-contain"
          />
          
          {expandedProject.images.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors duration-200"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors duration-200"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {expandedProject.images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
          
          <div className="absolute bottom-4 right-4 text-white text-sm bg-black/50 px-3 py-1 rounded-full">
            {currentImageIndex + 1} / {expandedProject.images.length}
          </div>
        </div>
      )}

      {/* Main Modal */}
      {expandedProject && !isFullscreen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-scale-in">
            <div className="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white pr-4">
                {expandedProject.title}
              </h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200"
              >
                <X className="w-6 h-6 text-gray-500" />
              </button>
            </div>

            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="space-y-3 text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-5 h-5" />
                      <span><strong>{t('Developer')}</strong> {expandedProject.developer}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      <span><strong>{t('Location')}</strong> {expandedProject.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-5 h-5" />
                      <span><strong>{t('Date')}</strong> {expandedProject.date}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">{t('ContactNumbers')}</h4>
                  <div className="space-y-1">
                    {expandedProject.contactNumbers.map((number, idx) => (
                      <a
                        key={idx}
                        href={`tel:${number}`}
                        className="flex items-center gap-2 text-primary-600 hover:text-primary-700 transition-colors duration-200"
                      >
                        <Phone className="w-4 h-4" />
                        {number}
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              {/* Image Gallery */}
              <div className="relative mb-6">
                <img
                  src={expandedProject.images[currentImageIndex]}
                  alt={expandedProject.title}
                  className="w-full h-64 object-cover rounded-lg cursor-pointer"
                  onClick={handleFullscreen}
                />
                <button
                  onClick={handleFullscreen}
                  className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                  title="View Fullscreen"
                >
                  <Maximize className="w-4 h-4" />
                </button>
                {expandedProject.images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      {expandedProject.images.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                            index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>

              <div className="prose dark:prose-invert max-w-none mb-6">
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  {expandedProject.description}
                </p>
                {expandedProject.otherDescription && (
                  <p className="text-gray-700 dark:text-gray-300 leading-relaxed mt-4">
                    {expandedProject.otherDescription}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button
                  onClick={handleShare}
                  className="flex items-center justify-center gap-2 btn-secondary text-sm py-2 px-3"
                >
                  <Share2 className="w-4 h-4" />
                  اشتراک لینک فایل
                </button>
                {/*
                <button
                  onClick={handleFavorite}
                  className={`flex items-center justify-center gap-2 text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200 ${
                    isFavorited 
                      ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300' 
                      : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isFavorited ? 'fill-current' : ''}`} />
                  {isFavorited ? 'Favorited' : 'Favorite'}
                </button>

                <button
                  onClick={handleBookmark}
                  className={`flex items-center justify-center gap-2 text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200 ${
                    isBookmarked 
                      ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' 
                      : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                  {isBookmarked ? 'Saved' : 'Save'}
                </button>
                  */}
                <button
                  onClick={handleContact}
                  className="flex items-center justify-center gap-2 bg-[#9CAFAA] hover:bg-secondary-700 text-white text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200"
                >
                  <MessageCircle className="w-4 h-4" />
                  تماس با فرهوم
                </button>
                  {/*
                <button
                  onClick={handleRate}
                  className="flex items-center justify-center gap-2 bg-yellow-100 hover:bg-yellow-200 dark:bg-yellow-900 dark:hover:bg-yellow-800 text-yellow-800 dark:text-yellow-200 text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200"
                >
                  <Star className="w-4 h-4" />
                  Rate
                </button>

                <button
                  onClick={handleViewCount}
                  className="flex items-center justify-center gap-2 bg-purple-100 hover:bg-purple-200 dark:bg-purple-900 dark:hover:bg-purple-800 text-purple-800 dark:text-purple-200 text-sm py-2 px-3 rounded-lg font-medium transition-all duration-200"
                >
                  <Eye className="w-4 h-4" />
                  Analytics
                </button>
                  */}
                {expandedProject.brochureUrl && (
                  <button
                    onClick={() => window.open(expandedProject.brochureUrl, '_blank')}
                    className="flex items-center justify-center gap-2 btn-secondary text-sm py-2 px-3"
                  >
                    <Download className="w-4 h-4" />
                    بروشور و کاتالوگ
                  </button>
                )}

                {expandedProject.modelUrl && (
                  <button
                    onClick={() => window.open(expandedProject.modelUrl, '_blank')}
                    className="flex items-center justify-center gap-2 btn-primary text-sm py-2 px-3"
                  >
                    <External className="w-4 h-4" />
                    3D Model
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExclusiveProjects;