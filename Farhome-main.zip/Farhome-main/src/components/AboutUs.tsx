import React from 'react';
import { Award, Users, Target, Heart, MapPin, Phone, Mail } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const AboutUs: React.FC = () => {
  const { t } = useLanguage();

  const stats = [
    { icon: Award, value: '20+', label: t('yearsExperience') },
    { icon: Users, value: '95+', label: t('happyClientsAbout') },
    { icon: Target, value: '600+', label: t('propertiesSold') },
    { icon: Heart, value: '100%', label: t('clientSatisfaction') }
  ];

  const team = [
    {
      name: t('seyed'),
      role: t('teamFounderRole'), // Note: Role translations need to be added to LanguageContext.tsx
      image: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Main-Team/CEO.jpg?updatedAt=1749730025508',
      bio: t('teamFounderBio')
    },
    {
      name: t('MehdiKeyvanfard'),
      role: t('teamCPORole'), // Note: Role translations need to be added to LanguageContext.tsx
      image: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Main-Team/CPO.jpg?updatedAt=1749730108951',
      bio: t('teamCPOBio')
    },
    //{
      //name: t('AmirFaramarzpour'),
      //role: t('teamWebDeveloperRole'), // Note: Role translations need to be added to LanguageContext.tsx
      //image: 'https://ik.imagekit.io/amirfaramarzpour/Fardad/Main-Team/Amir%20Faramarzpour.jpg?updatedAt=1752580537274',
      //bio: t('teamWebDeveloperBio')
    //},
  ];

  const values = [
    {
      icon: Target,
      title: t('excellenceTitle'),
      description: t('excellenceDescription')
    },
    {
      icon: Heart,
      title: t('integrityTitle'),
      description: t('integrityDescription')
    },
    {
      icon: Users,
      title: t('clientFocusTitle'),
      description: t('clientFocusDescription')
    },
    {
      icon: Award,
      title: t('innovationTitle'),
      description: t('innovationDescription')
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
          {t('aboutRealEstateProTitle')}
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-8">
          {t('aboutUsDescription')}
        </p>
        
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 dark:bg-primary-900 rounded-full mb-4 group-hover:scale-110 transition-transform duration-200">
                <stat.icon className="w-8 h-8 text-primary-600 dark:text-primary-400" />
              </div>
              <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{stat.value}</div>
              <div className="text-gray-600 dark:text-gray-400 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Video Section */}
      <div className="relative mb-16">
        <div className="relative h-64 md:h-96 rounded-2xl overflow-hidden">
          <iframe
            width="100%"
            height="100%"
            src="https://ik.imagekit.io/amirfaramarzpour/Fardad/Main-Team/farhome%20trailer%20(1).mp4?updatedAt=1752975860221"
            title="Company Video"
            frameBorder="0"
            allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
            className="w-full h-full object-cover"  
          />
        </div>
        <div className="text-center mt-6">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            {t('watchOurStoryTitle')}
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            {t('watchOurStoryDescription')}
          </p>
        </div>
      </div>

      {/* Team Section */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {t('meetOurTeamTitle')}
          </h3>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            {t('teamDescription')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {team.map((member, index) => (
            <div 
              key={index} 
              className="card text-center p-6 group hover:scale-105 transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <img
                src={member.image}
                alt={member.name}
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover border-4 border-white dark:border-gray-700 shadow-lg group-hover:scale-110 transition-transform duration-300"
              />
              <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                {member.name}
              </h4>
              <p className="text-primary-600 dark:text-primary-400 font-medium mb-3">
                {member.role}
              </p>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                {member.bio}
              </p>
              <div className="flex justify-center mt-4 space-x-2">

              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Values Section */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {t('ourValuesTitle')}
          </h3>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            {t('valuesDescription')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <div 
              key={index} 
              className="text-center group animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary-100 dark:bg-secondary-900 rounded-full mb-4 group-hover:scale-110 transition-transform duration-200">
                <value.icon className="w-8 h-8 text-secondary-600 dark:text-secondary-400" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                {value.title}
              </h4>
              <p className="text-gray-600 dark:text-gray-400">
                {value.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Mission Statement */}
      <div className="card p-8 md:p-12 text-center">
        <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
          {t('ourMissionTitle')}
        </h3>
        <p className="text-lg text-gray-600 dark:text-gray-400 max-w-4xl mx-auto leading-relaxed mb-8">
          {t('missionStatement')}
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="flex items-center justify-center space-x-2 text-gray-600 dark:text-gray-400">
            <MapPin className="w-5 h-5" />
            <span>{t('address')}</span>
          </div>
          <div className="flex items-center justify-center space-x-2 text-gray-600 dark:text-gray-400">
            <Phone className="w-5 h-5" />
            <span>{t('phone')}</span>
          </div>
          <div className="flex items-center justify-center space-x-2 text-gray-600 dark:text-gray-400">
            <Mail className="w-5 h-5" />
            <span>{t('emailAddress')}</span>
          </div>
        </div>
        <div style={{ fontFamily: 'Arial, sans-serif', fontSize: '14px', color: '#555', marginTop: '20px' }}>
           FarHome &copy; 2025  All rights reserved. | Design: <a href="https://amirfaramarzpour.ir" target="_blank" rel="noopener noreferrer">AmirFaramarzpour</a>.
        </div>

      </div>
    </div>
  );
};

export default AboutUs;