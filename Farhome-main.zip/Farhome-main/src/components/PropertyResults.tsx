import React from 'react';
import { SlidersHorizontal } from 'lucide-react';
import PropertyCard from './PropertyCard';
import { Property } from '../data/MockData';
import { useLanguage } from '../contexts/LanguageContext';

interface PropertyResultsProps {
  properties: Property[];
  currency: string;
  convertPrice: (price: number) => number;
  formatPrice: (price: number) => string;
  sortOption: string;
  onSortChange: (sort: string) => void;
}

const PropertyResults: React.FC<PropertyResultsProps> = ({
  properties,
  currency,
  convertPrice,
  formatPrice,
  sortOption,
  onSortChange
}) => {
  const { t } = useLanguage();

  const sortOptions = [
    { value: 'newest', label: t('newest') },
    { value: 'priceLowHigh', label: t('priceLowHigh') },
    { value: 'priceHighLow', label: t('priceHighLow') }
  ];

  return (
    <div>
      {/* Results Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            {properties.length} {t('PropertiesFound')}
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {t('Showingallavailableproperties')}
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-700 dark:text-gray-300">{t('sortBy')}:</span>
          </div>
          <select
            value={sortOption}
            onChange={(e) => onSortChange(e.target.value)}
            className="input-field min-w-[200px]"
          >
            {sortOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Results Grid */}
      {properties.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.map((property, index) => (
            <div key={property.id} style={{ animationDelay: `${index * 0.1}s` }}>
              <PropertyCard
                property={property}
                currency={currency}
                convertPrice={convertPrice}
                formatPrice={formatPrice}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
            <SlidersHorizontal className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            {t('NoPropertiesFound')}
          </h3>
          <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
            {t('Tryadjusting')}
          </p>
        </div>
      )}
    </div>
  );
};

export default PropertyResults;