import React, { useState } from 'react';
import { Filter } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface Filters {
  location: string;
  minPrice: number | null;
  maxPrice: number | null;
  propertyType: string;
  furnished: boolean | null;
  bedrooms: number | null;
  bathrooms: number | null;
}

interface PropertyFiltersProps {
  onFilterChange: (filters: Filters) => void;
}

const PropertyFilters: React.FC<PropertyFiltersProps> = ({ onFilterChange }) => {
  const { t, isRTL } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [filters, setFilters] = useState<Filters>({
    location: '',
    minPrice: null,
    maxPrice: null,
    propertyType: '',
    furnished: null,
    bedrooms: null,
    bathrooms: null
  });

  const handleFilterChange = (key: keyof Filters, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const propertyTypes = [
    { value: '', label: t('allTypes') },
    { value: 'house', label: t('house') },
    { value: 'apartment', label: t('apartment') },
    { value: 'villa', label: t('villa') },
    { value: 'office', label: t('office') },
    { value: 'shop', label: t('shop') },
    { value: 'floor', label: t('floor') },
    { value: 'penthouse', label: t('penthouse') },
    { value: 'land', label: t('land') },
    { value: 'warehouse', label: t('warehouse') },
    { value: 'industrialLand', label: t('industrialLand') },
    { value: 'othercommercial', label: t('othercommercial') },
    { value: 'showroom', label: t('showroom') },
    { value: 'commercial', label: t('commercial') },
  ];

  const furnishedOptions = [
    { value: null, label: t('All') },
    { value: true, label: t('furnished') },
    { value: false, label: t('unfurnished') }
  ];

  const numberOptions = [
    { value: null, label: t('All') },
    { value: 1, label: '1' },
    { value: 2, label: '2' },
    { value: 3, label: '3' },
    { value: 4, label: '4+' }
  ];

  return (
    <div className="mb-8">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 btn-secondary mb-4 lg:hidden"
      >
        <Filter className="w-4 h-4" />
        {t('Filters')}
      </button>

      <div className={`${isOpen ? 'block' : 'hidden'} lg:block`}>
        <div className="card p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Location */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('location')}
              </label>
              <input
                type="text"
                value={filters.location}
                onChange={(e) => handleFilterChange('location', e.target.value)}
                className="input-field"
                placeholder={t("EnterLoc")}
              />
            </div>

            {/* Property Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('propertyType')}
              </label>
              <select
                value={filters.propertyType}
                onChange={(e) => handleFilterChange('propertyType', e.target.value)}
                className="input-field"
              >
                {propertyTypes.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Min Price */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('minPrice')}
              </label>
              <input
                type="number"
                value={filters.minPrice || ''}
                onChange={(e) => handleFilterChange('minPrice', e.target.value ? parseFloat(e.target.value) : null)}
                className="input-field"
                placeholder="0"
                min="0"
              />
            </div>

            {/* Max Price */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('maxPrice')}
              </label>
              <input
                type="number"
                value={filters.maxPrice || ''}
                onChange={(e) => handleFilterChange('maxPrice', e.target.value ? parseFloat(e.target.value) : null)}
                className="input-field"
                placeholder={t("Nolimit")}
                min="0"
              />
            </div>

            {/* Furnished */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('furnishedStatus')}
              </label>
              <select
                value={filters.furnished === null ? '' : filters.furnished.toString()}
                onChange={(e) => {
                  const value = e.target.value === '' ? null : e.target.value === 'true';
                  handleFilterChange('furnished', value);
                }}
                className="input-field"
              >
                {furnishedOptions.map(option => (
                  <option key={option.value === null ? 'null' : option.value.toString()} value={option.value === null ? '' : option.value.toString()}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Bedrooms */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('bedrooms')}
              </label>
              <select
                value={filters.bedrooms || ''}
                onChange={(e) => handleFilterChange('bedrooms', e.target.value ? parseInt(e.target.value) : null)}
                className="input-field"
              >
                {numberOptions.map(option => (
                  <option key={option.value || 'all'} value={option.value || ''}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Bathrooms */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('bathrooms')}
              </label>
              <select
                value={filters.bathrooms || ''}
                onChange={(e) => handleFilterChange('bathrooms', e.target.value ? parseInt(e.target.value) : null)}
                className="input-field"
              >
                {numberOptions.map(option => (
                  <option key={option.value || 'all'} value={option.value || ''}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyFilters;