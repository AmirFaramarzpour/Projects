import React, { useState, useEffect, useCallback } from 'react';
import { MapPin, Bed, Bath, Square, Phone, X, ChevronLeft, ChevronRight, Maximize } from 'lucide-react';
import { Property } from '../data/MockData';
import { useLanguage } from '../contexts/LanguageContext';

interface PropertyCardProps {
  property: Property;
  currency: string;
  convertPrice: (price: number) => number;
  formatPrice: (price: number) => string;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, currency, convertPrice, formatPrice }) => {
  const { t, isRTL } = useLanguage();

  const convertedPrice = convertPrice(property.priceValue);
  const formattedPrice = formatPrice(convertedPrice);

  const [isExpanded, setIsExpanded] = React.useState(false);
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleNextImage = useCallback(() => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images.length);
  }, [property.images.length]);

  const handlePrevImage = useCallback(() => {
    setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
  }, [property.images.length]);

  const handleExpand = () => {
    if (!isExpanded) {
      setCurrentImageIndex(0); // Reset to first image on expand
    }
    setIsExpanded(prev => !prev);
  };

  const handleFullscreenToggle = () => {
    setIsFullscreen(prev => !prev);
  };

  const handleCloseFullscreen = () => {
    setIsFullscreen(false);
  };

  const handleCloseModal = () => {
    setIsExpanded(false);
    setIsFullscreen(false);
  };

  // Handle keyboard navigation only when fullscreen or modal is active
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (isFullscreen || isExpanded) {
        if (event.key === 'ArrowRight') {
          handleNextImage();
        } else if (event.key === 'ArrowLeft') {
          handlePrevImage();
        } else if (event.key === 'Escape') {
          if (isFullscreen) handleCloseFullscreen();
          else handleCloseModal();
        }
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isExpanded, isFullscreen, handleNextImage, handlePrevImage]);

  return (
    <div className="card overflow-hidden group transition-all duration-300 animate-fade-in">
      <div className="relative overflow-hidden">
        <img
          src={property.images[0]}
          alt={property.title}
          className="w-full h-48 object-cover transition-transform duration-300"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${
            property.type === 'buy' ? 'bg-primary-600' : 'bg-secondary-600'
          }`}>
            {property.type === 'buy' ? t('buy') : t('rent')}
          </span>
        </div>
        <div className="absolute top-4 right-4">
          <span className="px-3 py-1 bg-black/50 backdrop-blur-sm rounded-full text-white text-xs font-semibold">
            {formattedPrice} {t('currency')}
          </span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
          {property.title}
        </h3>
        
        <div className="flex items-center text-gray-600 dark:text-gray-400 mb-4">
          <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
          <span className="text-sm">{property.location}</span>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="flex items-center text-gray-600 dark:text-gray-400">
            <Bed className="w-4 h-4 mr-1" />
            <span className="text-sm">{property.bedrooms} {t('bedrooms')}</span>
          </div>
          <div className="flex items-center text-gray-600 dark:text-gray-400">
            <Bath className="w-4 h-4 mr-1" />
            <span className="text-sm">{property.bathrooms} {t('bathrooms')}</span>
          </div>
          <div className="flex items-center text-gray-600 dark:text-gray-400">
            <Square className="w-4 h-4 mr-1" />
            <span className="text-sm">{property.sqft} {t('sqft')}</span>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            property.furnished 
              ? 'bg-secondary-100 text-secondary-800 dark:bg-secondary-900 dark:text-secondary-200'
              : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
          }`}>
            {property.furnished ? t('furnished') : t('unfurnished')}
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400">
            {property.propertyType}
          </span>
        </div>

        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2">
          {property.description}
        </p>

        <div className="border-t dark:border-gray-700 pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
            </div>
            <div className="flex gap-2">
              <button 
                className="btn-primary text-sm py-2 px-4"
                onClick={handleExpand}
              >
                {t('viewDetails')}
              </button>
              <button className="p-2 rounded-lg bg-secondary-100 hover:bg-secondary-200 dark:bg-secondary-900 dark:hover:bg-secondary-800 text-secondary-600 dark:text-secondary-400 transition-colors duration-200">
                <a href={`tel:${property.agentPhone}`}>
                  <Phone className="w-4 h-4" />
                </a>
              </button>
            </div>
          </div>
        </div>
      </div>

      {isExpanded && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={(e) => e.stopPropagation()}>
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white pr-4">
                {property.title}
              </h2>
              <button
                onClick={handleCloseModal}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200"
              >
                <X className="w-6 h-6 text-gray-500" />
              </button>
            </div>

            <div className="p-6">
              <div className="relative mb-6">
                <img
                  src={property.images[currentImageIndex]}
                  alt={property.title}
                  className="w-full h-64 object-cover rounded-lg cursor-pointer"
                  onClick={handleFullscreenToggle}
                />
                <button
                  onClick={handleFullscreenToggle}
                  className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                  title="View Fullscreen"
                >
                  <Maximize className="w-4 h-4" />
                </button>
                {property.images.length > 1 && (
                  <>
                    <button
                      onClick={(e) => { e.stopPropagation(); handlePrevImage(); }}
                      className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleNextImage(); }}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      {property.images.map((_, index) => (
                        <button
                          key={index}
                          onClick={(e) => { e.stopPropagation(); setCurrentImageIndex(index); }}
                          className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                            index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="space-y-3 text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      <span><strong>{t('location')}: </strong>{property.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Bed className="w-5 h-5" />
                      <span>  <strong>{t('bedrooms')} </strong>{property.bedrooms}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Bath className="w-5 h-5" />
                      <span><strong>{t('bathrooms')}</strong> {property.bathrooms}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Square className="w-5 h-5" />
                      <span>{property.sqft}<strong>{t('sqft')}</strong></span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">{t('Call')}</h4>
                  <div className="space-y-1">
                    <a
                      href={`tel:${property.agentPhone}`}
                      className="flex items-center gap-2 text-primary-600 hover:text-primary-700 transition-colors duration-200"
                    >
                      <Phone className="w-4 h-4" />
                      {property.agentPhone}
                    </a>
                  </div>
                </div>
              </div>

              <div className="prose dark:prose-invert max-w-none mb-6">
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  {property.description}
                </p>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed mt-4">
                  <strong>{t('features')}:</strong> {property.features.join(', ')}
                </p>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed mt-4">
                  <strong>{t('dateAdded')}:</strong> {property.dateAdded}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {isFullscreen && (
        <div className="fixed inset-0 bg-black z-[60] flex items-center justify-center animate-fade-in" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={handleCloseFullscreen}
            className="absolute top-4 right-4 z-10 p-3 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors duration-200"
          >
            <X className="w-6 h-6" />
          </button>
          
          <img
            src={property.images[currentImageIndex]}
            alt={property.title}
            className="max-w-full max-h-full object-contain"
          />
          
          {property.images.length > 1 && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); handlePrevImage(); }}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors duration-200"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); handleNextImage(); }}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors duration-200"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {property.images.map((_, index) => (
                  <button
                    key={index}
                    onClick={(e) => { e.stopPropagation(); setCurrentImageIndex(index); }}
                    className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
          
          <div className="absolute bottom-4 right-4 text-white text-sm bg-black/50 px-3 py-1 rounded-full">
            {currentImageIndex + 1} / {property.images.length}
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyCard;
