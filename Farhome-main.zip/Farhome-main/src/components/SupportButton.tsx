import React, { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const SupportButton: React.FC = () => {
  const { t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Construct mailto link
    const subject = encodeURIComponent(`Support Request from ${formData.name}`);
    const body = encodeURIComponent(`Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`);
    const mailtoLink = `mailto:support@farhome.ir?subject=${subject}&body=${body}`;
    window.location.href = mailtoLink;

    setIsSubmitted(true);
    setIsSubmitting(false);

    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
      setIsOpen(false);
    }, 3000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleWhatsAppClick = () => {
    const phoneNumber = '+989116812737'; // Replace with actual WhatsApp number
    const message = encodeURIComponent(`Hello, my name is ${formData.name}. My email is ${formData.email}. ${formData.message}`);
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
  };

  return (
    <>
      {/* Support Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-primary-600 hover:bg-primary-700 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 z-40 group animate-float"
      >
        <MessageCircle className="w-6 h-6" />
        <span className="absolute right-full mr-3 top-1/2 transform -translate-y-1/2 bg-primary-600 text-white px-3 py-1 rounded-lg text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap hidden md:block">
          {t('support')}
        </span>
      </button>

      {/* Support Modal */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto animate-scale-in">
            <div className="border-b border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {t('supportTitle')}
              </h3>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6">
              {isSubmitted ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-secondary-100 dark:bg-secondary-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send className="w-8 h-8 text-secondary-600 dark:text-secondary-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {t('messageSent')}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-400">
                    We'll get back to you as soon as possible.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('name')} *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="input-field"
                      placeholder="Your name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('email')} *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="input-field"
                      placeholder="your.email@example.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('message')} *
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      rows={4}
                      className="input-field resize-none"
                      placeholder="How can we help you?"
                    />
                  </div>

                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setIsOpen(false)}
                      className="flex-1 btn-secondary"
                    >
                      {t('cancel')}
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-1 btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                      {isSubmitting ? 'Sending...' : t('sendMessage')}
                    </button>
                  </div>
                  <button
                    onClick={handleWhatsAppClick}
                    className="w-full mt-4 btn-secondary flex items-center justify-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6.166 14.847c-.303-.195-1.789-.876-2.067-.973-.278-.098-.477-.147-.678.097-.201.244-.788.78-1.173.976-.386.197-.683.195-1.066-.044-.384-.239-1.535-1.054-2.805-3.766-.236-.49-.454-1.004-.454-1.517 0-.513.384-.766.748-.766.364 0 1.123.053 1.752.749.628.697 1.138 1.514 1.263 1.638.126.124.252.144.371.047.119-.098.614-.49 1.174-1.029.56-.539 1.186-1.19 1.326-1.39.14-.2.186-.298.133-.405-.053-.107-.402-.611-.88-.93-.477-.32-1.008-.48-1.516-.48-.508 0-1.008.147-1.54.441-.531.294-2.175 1.028-2.694 1.22-.519.191-1.108.238-1.316.134-.208-.104-.676-.512-1.019-1.111-.343-.6-.3-1.135-.18-1.246.12-.111.502-.18 1.1-.18 1.375 0 2.91 1.794 3.205 2.085.295.291.488.635.56.828.071.193.03.377-.02.528-.05.151-.497 1.548-.683 2.098-.186.55-.375 1.136-.53 1.706-.155.57-.308 1.135-.548 1.576-.24.441-.794.743-1.367.743-.573 0-1.03-.191-1.349-.369-.32-.178-1.098-.717-1.098-1.386 0-.669.486-1.049.916-1.388.43-.34 1.193-.518 1.815-.518.622 0 1.212.133 1.733.399.521.266 1.237.67 1.872 1.011.635.341 1.26.613 1.667.819.406.206.814.309 1.122.309.308 0 .614-.074.914-.221.3-.147.564-.348.78-.6.216-.252.368-.538.438-.828.07-.29.026-.583-.12-.824z"/>
                    </svg>
                    {t('whatsappSupport')}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default SupportButton;