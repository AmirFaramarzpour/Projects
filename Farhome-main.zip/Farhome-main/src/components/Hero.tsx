
   import React, { useState, useEffect } from 'react';
   import { Search, Home, Users, Award, MapPin } from 'lucide-react';
   import { useLanguage } from '../contexts/LanguageContext';

   interface HeroProps {
     onSearch: (query: string, type: 'buy' | 'rent') => void;
   }

   const Hero: React.FC<HeroProps> = ({ onSearch }) => {
     const { t, isRTL } = useLanguage();
     const [searchQuery, setSearchQuery] = useState('');
     const [searchType, setSearchType] = useState<'buy' | 'rent'>('buy');

     const handleSearch = () => {
       if (searchQuery.trim()) {
         onSearch(searchQuery, searchType);
       }
     };

     const handleKeyPress = (e: React.KeyboardEvent) => {
       if (e.key === 'Enter') {
         handleSearch();
       }
     };


     // Dynamically load the TGJU script
     useEffect(() => {
       const script = document.createElement('script');
       script.src = 'https://api.tgju.org/v1/widget/v2';
       script.async = true; // Use async instead of defer for better control
       document.body.appendChild(script);

       // Cleanup to remove the script when the component unmounts
       return () => {
         document.body.removeChild(script);
       };
     }, []);

     return (
       <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
         {/* Background */}
         <div 
           className="absolute inset-0 bg-cover bg-center bg-no-repeat"
           style={{
             backgroundImage: `url('https://ik.imagekit.io/amirfaramarzpour/Fardad/Main-Team/bg10.jpg?updatedAt=1756990473562')`
           }}
         >
           <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30"></div>
         </div>

         {/* Content */}
         <div className="relative z-10 container mx-auto px-4 text-center">
           <div className="max-w-4xl mx-auto animate-fade-in">
             {/* Main Headlines */}
             <h1 className="text-5xl md:text-5xl font-bold text-white mb-6 leading-tight">
               {t('heroTitle')}
             </h1>
             <p className="text-xl md:text-2xl text-gray-200 mb-12 max-w-2xl mx-auto">
               {t('heroSubtitle')}
             </p>

             {/* Search Section */}
             <div className="max-w-2xl mx-auto mb-16">
               {/* Search Type Buttons */}
               <div className="flex justify-center mb-6">
                 <div className="bg-white/10 backdrop-blur-md rounded-lg p-1 flex">
                   <button
                     onClick={() => setSearchType('buy')}
                     className={`px-10 py-2 rounded-md font-semibold transition-all duration-200 ${
                       searchType === 'buy'
                         ? 'bg-white text-gray-900 shadow-lg'
                         : 'text-white hover:bg-white/20'
                     }`}
                   >
                     {t('buy')}
                   </button>
                   <button
                     onClick={() => setSearchType('rent')}
                     className={`px-10 py-2 rounded-md font-semibold transition-all duration-200 ${
                       searchType === 'rent'
                         ? 'bg-white text-gray-900 shadow-lg'
                         : 'text-white hover:bg-white/30'
                     }`}
                   >
                     {t('rent')}
                   </button>
                 </div>
               </div>

               {/* Search Bar */}
               <div className="flex gap-4">
                 <div className="flex-1 relative">
                   <Search className={`absolute top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 ${
                     isRTL ? 'right-4' : 'left-4'
                   }`} />
                   <input
                     type="text"
                     placeholder={t('searchPlaceholder')}
                     value={searchQuery}
                     onChange={(e) => setSearchQuery(e.target.value)}
                     onKeyPress={handleKeyPress}
                     className={`w-full py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-gray-300 placeholder:text-sm focus:outline-none focus:ring-2 focus:ring-white/50 focus:border-transparent transition-all duration-200 ${
                       isRTL ? 'pr-12 pl-4 text-right' : 'pl-12 pr-4'
                     }`}
                   />
                 </div>
                 <button
                   onClick={handleSearch}
                   className="btn-primary whitespace-nowrap hover:shadow-2xl"
                 >
                   {t('searchButton')}
                 </button>
               </div>
             </div>

             {/* Ticker Widget */}
<tgju
	type="ticker-tap"
	items="398096,398097,535605,398115,398102,137122,137137,137203,137205,137206,137207,137225"
	columns="dot"
	speed="50"
	token="webservice"
	styles='{
		"background": "#0000000e",
		"border": "#ffffff04",
		"title": "#ffffff",
		"copyright": "#ffffff02"
	}'></tgju>
<script src="https://api.tgju.org/v1/widget/v2" defer></script>

             {/* Video Play Button */}

           </div>
         </div>

         {/* Scroll Indicator */}

       </div>
     );
   };

   export default Hero;
