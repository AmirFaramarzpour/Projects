import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Translations {
  [key: string]: string;
}

const translations: { [key: string]: Translations } = {
  en: {
    RealEstatePro: 'FarHome',
    // Navigation
    home: 'Home',
    search: 'Search',
    buy: 'Buy',
    rent: 'Rent',
    findAgent: 'Find Agent',
    aboutUs: 'About Us',
    blog: 'Blog',
    constructionHub: 'Construction Hub',
    exclusiveProjects: 'Exclusive Projects',
    featuredProperties: 'Featured Properties', // Added English translation
    
    // Hero Section
    heroTitle: 'Find Your Dream Property',
    heroSubtitle: 'Discover the perfect home with our extensive collection of premium properties',
    searchPlaceholder: 'Search by location, property type, File code...',
    searchButton: 'Search',
    
    // Property Features
    bedrooms: 'Bedrooms',
    bathrooms: 'Bathrooms',
    sqft: 'sq meter',
    furnished: 'Furnished',
    unfurnished: 'Unfurnished',
    
    // Filters
    location: 'Location',
    priceRange: 'Price Range',
    propertyType: 'Property Type',
    minPrice: 'Min Price',
    maxPrice: 'Max Price',
    allTypes: 'All Types',
    house: 'House',
    apartment: 'Apartment',
    villa: 'Villa',
    office: 'Office',
    shop: 'Shop',
    filters: 'Filters',
    House: 'House',
    residential: 'Residential',
    commercial: 'Commercial',
    penthouse: 'Penthouse',
    land: 'Land',
    tower: 'Tower',
    floor:'Floor',
    suburbshousing: 'Suburbs Housing',
    warehouse: 'Warehouse',
    industrialLand: 'Industrial Land',
    showroom: 'Showroom',
    othercommercial: 'Other Commercial',
    furnishedStatus: 'Furnished Status',
    Filters: "Filters",
    EnterLoc: 'Enter location ...',
    Nolimit : 'No limit',
    All: 'All',
    Showingallavailableproperties:'Showing all available properties',
    NoPropertiesFound: 'No Properties Found',
    Tryadjusting: 'Try adjusting your filters or search criteria to find more properties',
    PropertiesFound: 'Properties Found',
    Propertiesfor: 'Properties for',
    propertiesavailable: 'properties available',
    ReadFullArticle: 'Read Full Article',
    stayinformed: 'Stay informed with the latest trends and insights in real estate',
    Connectwith: 'Connect with premier construction partners and explore innovative building solutions',
    Discoverpremium: 'Explore premium developments, monopol projects, and exclusive investment opportunities curated for discerning buyers.',
    Discoverfeatured: "Here, we’re talking about properties that truly stand out—whether it’s the architecture, the amenities, the location, or even the sale terms. These kinds of listings are rare gems in the area.",
    // Actions
    viewDetails: 'View Details',
    readMore: 'Read More',
    readLess: 'Read Less',
    learnMore: 'Learn More',
    contactAgent: 'WhatsApp',
    close: 'Close',
    submit: 'Submit',
    cancel: 'Cancel',
    Call: 'Call',
    Email: 'Email',
    Connectwithour: 'Connect with our experienced real estate professionals',
    
    // Support
    support: 'Support',
    supportTitle: 'How can we help you?',
    name: 'Name',
    email: 'Email',
    message: 'Message',
    sendMessage: 'Send Message',
    messageSent: 'Message sent successfully!',
    
    // Blog
    blogTitle: 'Latest Real Estate Insights',
    readTime: 'min read',
    shareUrl: 'Share URL',
    downloadDesc: 'Download Description',
    
    // Currency
    currency: 'Currency',
    usd: 'USD',
    irr: 'IRR',
    toman: 'Toman',
    
    //Meet Our Team
    SeyedJamalAldinHosseini: 'Seyed Jamal Aldin Hosseini',
    teamFounderRole: 'CEO & Founder',
    teamCPORole: 'CPO and Co-Founder',
    teamWebDeveloperRole: 'Web Developer and IT',
    // Sort
    sortBy: 'Sort By',
    newest: 'Newest First',
    priceLowHigh: 'Price: Low to High',
    priceHighLow: 'Price: High to Low',
    
    // Statistics
    propertiesAvailable: 'Properties Available',
    experiencedAgents: 'Experienced Agents',
    happyClients: 'Happy Clients',
    citiesCovered: 'Cities Covered',
    
    // About Us Section
    MehdiKeyvanfard: 'Mehdi Keyvanfard',
    seyed: 'Seyed Jamal Aldin Hoseini',
    AmirFaramarzpour: 'Amir Faramarzpour',
    mojtaba: 'Mojtaba Altafi',
    iman: 'Iman Khorshidi',
    Amirbabei: 'Amir Babaei',
    aboutRealEstateProTitle: 'About FarHome',
    aboutUsDescription: 'With over 20 years of experience in real estate sales, our company is committed to providing a secure, reliable, and professional experience for our clients. We are proud to work directly with reputable developers to offer the best property options.',
    yearsExperience: 'Years Experience',
    happyClientsAbout: 'Happy Clients',
    propertiesSold: 'Properties Sold',
    clientSatisfaction: 'Client Satisfaction',
    watchOurStoryTitle: 'A brief introduction',
    watchOurStoryDescription: 'Something Beyond',
    meetOurTeamTitle: 'Meet Our Team',
    teamDescription: 'Our experienced professionals are dedicated to providing you with exceptional service',
    teamFounderBio: 'Fardad founded company with a vision to revolutionize the real estate experience in Iran.',
    teamCPOBio: 'Mehdi, Project Director and co-founder of a real estate startup, spearheads project direction and leads the core team, driving innovation and execution from the ground up.',
    teamWebDeveloperBio: 'Amir has a unique sets of skill in IT and web developments + Security analysis.',
    ourValuesTitle: 'Our Values',
    valuesDescription: 'These core values guide everything we do and shape our clients',
    excellenceTitle: 'Partnerships',
    excellenceDescription: 'we have strong partnerships with major and reputable construction holdings across cities and countries in the region, including Turkey, Cyprus, and the UAE, offering consulting and sales services on an international level.',
    integrityTitle: 'Integrity',
    integrityDescription: 'To ensure legal transparency and security, we collaborate with an official legal attorney, so all contracts and transactions are handled with full confidence.',
    clientFocusTitle: 'Client Focus',
    clientFocusDescription: 'We also work closely with reputable economic institutions such as currency exchange offices, gold dealers, and car showrooms to facilitate smoother and faster financial transactions for our clients.',
    innovationTitle: 'Construction Centers',
    innovationDescription: 'In the field of construction materials and decorative furnishings, we cooperate with primary suppliers to ensure our clients have access to reliable, affordable, and high-quality products.',
    ourMissionTitle: 'Our mission',
    missionStatement: "With over two decades of experience in real estate sales, our company is dedicated to delivering a trustworthy, seamless, and professional service to every client. We partner exclusively with reputable developers to bring you the finest property selections. Whether you're a first-time buyer or a seasoned investor, we tailor our approach to suit your unique needs. Your goals are our priority, and we're here to guide you every step of the way",
    address: 'Mardanshahi, Mazandaran Province, Sari, Iran',
    phone: '+98 911 580 0059',
    emailAddress: 'Farhome@outlook.com',
    whatsappSupport: 'Contact using WhatsApp',
    Officesecretary: 'Office secretary',
    SalesSeniorMarketing: 'Sales Senior, Marketing',
    Marketing: 'Marketing',
  },
  fa: {
    RealEstatePro: 'فرهوم',
    // Navigation
    home: 'صفحه اصلی',
    search: 'جستجو',
    buy: 'خرید',
    rent: 'اجاره',
    findAgent: 'کارشناسان ما',
    aboutUs: 'درباره ما',
    blog: 'وبلاگ',
    constructionHub: 'مرکز ساخت‌وساز',
    exclusiveProjects: 'فروش انحصاری',
    featuredProperties: 'املاک ممتاز', // Added Persian translation
    ContactNumbers: 'شماره تماس: ',
    Developer: 'سازنده، ',
    Location: 'موقعیت پروژه: ',
    Center: 'نمایشگاه دائمی و دفتر مرکزی:    ',
    Date: 'تاریخ درج فایل: ',
    Author: 'مالک برند: ',
    // Hero Section
    heroTitle: 'ملک رویایی خودتو  پیدا کن',
    heroSubtitle: 'فَرهوم بهت کمک می‌کنه بهترین خرید ممکن رو داشته باشی',
    searchPlaceholder: 'جستجو بر اساس منطقه، نوع کاربری، کد فایل (برای مثال: ساری، اصفهان و یا ویلا، اپارتمان و ...)',
    searchButton: 'جستجو',
    
    // Property Features
    bedrooms: 'خواب',
    bathrooms: 'سرویس',
    sqft: 'متر مربع',
    furnished: 'مبله',
    unfurnished: 'غیر مبله',
    features: 'ویژگی‌های اصلی',
    dateAdded : 'تاریخ درج فایل',
    // Filters
    location: 'منطقه',
    priceRange: 'محدوده قیمت',
    propertyType: 'نوع ملک',
    minPrice: 'حداقل قیمت',
    maxPrice: 'حداکثر قیمت',
    allTypes: 'همه انواع',
    house: 'خانه',
    apartment: 'آپارتمان',
    villa: 'ویلا',
    office: 'اداری',
    shop: 'تجاری',
    filters: 'فیلترها',
    residential: 'مسکونی',
    House: 'خانه',
    floor: 'زیربنا',
    commercial: 'تجاری',
    tower: 'برج',
    penthouse: 'پنت‌هاوس',
    land: 'زمین',
    suburbshousing: 'مسکن حومه',
    warehouse: 'انبار',
    industrialLand: 'زمین صنعتی',
    showroom: 'نمایشگاه',
    othercommercial: 'تجاری دیگر',
    furnishedStatus: 'وضعیت مبله بودن یا نبودن',
    Filters: 'فیلترها',
    EnterLoc: 'شهر یا موقعیت را وارد کنید...',
    Nolimit: 'بدون محدودیت',
    All:'همه',
    Showingallavailableproperties: 'نمایش فایل‌های موجود',
    NoPropertiesFound: 'فایل با مشخصات مدنظر یافت نشد.',
    Tryadjusting: 'سعی کنید با تنظیم درست فیلترها، جستجوی بهتری را تجربه کنید.',
    PropertiesFound: 'فایل یافت شد.',
    Propertiesfor: 'فایل‌های ',
    propertiesavailable: 'فایل موجود',
    ReadFullArticle: 'مطالعه کامل مقاله',
    stayinformed: ' آخرین اخبار، مقالات و ترندهای املاک، معرفی پتانسیل‌های سرمایه‌گذاری، توضیح مسائل حقوقی',
    Connectwith: 'معرفی برندهای مطرح در زمینه ساختمان، دکوراسیون منزل، تهیه‌کننده متریال و تجهیزات کامل ساختمانی',
    Discoverpremium: '«این ملک خاص تنها از طریق ما عرضه می‌شه؛ یعنی عاملیت فروش انحصاری اون رو به عهده داریم. با اطمینان از اصالت، شرایط ویژه، و همراهی کامل در تمام مراحل خرید در کنار شما هستیم.»',
    Discoverfeatured: '«اینجا با املاکی طرفیم که یه سر و گردن از بقیه بالاترن—چه از نظر معماری، چه امکانات، چه موقعیت و حتی شرایط فروش! از اونایی که توی این منطقه به‌ ندرت پیدا می‌شن.»',
    whatsappSupport: 'واتساپ پشتیبانی',

    // Actions
    viewDetails: 'مشاهده جزئیات',
    readMore: 'ادامه',
    readLess: 'بستن',
    learnMore: 'اطلاعات بیشتر',
    contactAgent: 'واتساپ',
    close: 'بستن',
    submit: 'ارسال',
    cancel: 'لغو',
    Call: 'تماس',
    Email: 'پست الکترونیک',
    Connectwithour: 'با مشاوران املاک ما و کارشناسان فروش صحبت کن.',
    
    // Support
    support: 'پشتیبانی',
    supportTitle: 'چطور می‌تونیم کمکتون کنیم؟',
    name: 'نام',
    email: 'ایمیل',
    message: 'پیام',
    sendMessage: 'ارسال پیام',
    messageSent: 'پیام با موفقیت ارسال شد!',
    
    // Blog
    blogTitle: 'وبلاگ',
    readTime: 'دقیقه مطالعه',
    shareUrl: 'اشتراک لینک',
    downloadDesc: 'دانلود توضیحات',
    
    // Currency
    currency: 'تومان',
    usd: 'دلار',
    irr: 'ریال',
    toman: 'تومان',
    
    // Sort
    sortBy: 'مرتب‌سازی',
    newest: 'جدیدترین',
    priceLowHigh: 'قیمت: کم به زیاد',
    priceHighLow: 'قیمت: زیاد به کم',
    
    // Statistics
    propertiesAvailable: 'ملک موجود',
    experiencedAgents: 'مشاور مجرب',
    happyClients: 'مشتری راضی',
    citiesCovered: 'شهر تحت پوشش',
    
    // About Us Section
    aboutRealEstateProTitle: 'فَرهوم',
    aboutUsDescription: 'بیش از 20 سال است که به افراد کمک می‌کنیم تا خانه‌های رویایی خود را پیدا کنند و سرمایه‌گذاری‌های هوشمند در املاک انجام دهند. تعهد ما به برتری و رضایت مشتری، ما را به نامی قابل اعتماد در این حوزه تبدیل کرده است.',
    yearsExperience: 'سال تجربه',
    happyClientsAbout: 'مشتریان خوشحال',
    propertiesSold: 'معاملات انجام شده',
    clientSatisfaction: 'درصد رضایت ',
    watchOurStoryTitle: 'یک مقدمه کوتاه . .',
    watchOurStoryDescription: ' چیزی فراتر از املاک',
    meetOurTeamTitle: 'با تیم ما آشنا شوید',
    teamDescription: 'متخصصان با تجربه ما متعهد به ارائه خدمات استثنایی به شما هستند',
    teamFounderRole: 'مدیرعامل و بنیان‌گذار',
    teamCPORole: 'مدیر پروژه و هم‌بنیان‌گذار',
    teamWebDeveloperRole: 'توسعه‌دهنده وب',
    teamFounderBio: 'فرداد فَرهوم را با چشم‌اندازی برای انقلابی کردن تجربه املاک  راه‌اندازی کرد.',
    teamCPOBio: 'مهدی، مدیر اجرائی پروژه و هم‌بنیان‌گذار فَرهوم، هدایت پروژه‌ و هماهنگی را بر عهده دارد .',
    teamWebDeveloperBio: 'امیر در زمینه طراحی و توسعه وب‌سایت‌ها و برنامه‌نویسی نرم‌افزار فعالیت می‌کند.',
    ourValuesTitle: 'ارزش‌های ما',
    valuesDescription: '«ما با تکیه بر ارزش‌های اصلی‌مان، مسیر تمام فعالیت‌ها را مشخص کرده و کیفیت تعامل با مشتریان را به‌گونه‌ای شکل می‌دهیم که درخور اعتمادشان باشد.»',
    excellenceTitle: 'مشارکت‌ها',
    excellenceDescription: 'ما با هلدینگ‌های ساختمانی معتبر و بزرگ در کشورهای منطقه، از جمله ترکیه، قبرس و امارات، همکاری و مشارکت داریم و خدمات مشاوره و فروش را در سطح بین‌المللی ارائه می‌دهیم.',
    integrityTitle: 'صداقت',
    integrityDescription: 'برای اطمینان از شفافیت و امنیت قانونی، ما با وکلای رسمی دادگستری همکاری می‌کنیم، بنابراین تمامی قراردادها و معاملات با اطمینان کامل انجام می‌شوند.',
    clientFocusTitle: 'تمرکز بر مشتری',
    clientFocusDescription: 'ما همچنین با موسسات اقتصادی معتبر مانند صرافی‌ها، فروشندگان طلا و نمایشگاه‌های خودرو همکاری نزدیک داریم تا تراکنش‌های مالی روان‌تر و سریع‌تری برای مشتریانمان فراهم کنیم.',
    innovationTitle: 'مراکز ساخت و ساز',
    innovationDescription: 'در زمینه مواد ساختمانی و مبلمان تزئینی، ما با تامین‌کنندگان اصلی همکاری می‌کنیم تا مشتریانمان به محصولات قابل اعتماد، مقرون‌به‌صرفه و با کیفیت بالا دسترسی داشته باشند.',
    ourMissionTitle: 'هدف ما',
    missionStatement: 'با بیش از بیست سال تجربه در فروش املاک و مستغلات، فَرهوم متعهد به ارائه خدماتی مطمئن، حرفه‌ای و بی‌دردسر به مشتریان خود است. ما با همکاری مستقیم با توسعه‌دهندگان معتبر، بهترین گزینه‌های ملکی را در اختیار شما قرار می‌دهیم. چه برای اولین بار قصد خرید دارید و چه یک سرمایه‌گذار باتجربه باشید، رویکرد ما متناسب با نیازهای شما طراحی می‌شود. هدف‌های شما اولویت ما هستند و در هر قدم همراه‌تان خواهیم بود.',
    address: 'مردانشاهی، استان مازندران، ساری، ایران',
    phone: '09335317304',
    emailAddress: 'support@farhome.ir',
    seyed: ' سید جمال الدین حسینی (فرداد)',
    MehdiKeyvanfard: 'مهدی کیوانفرد',
    AmirFaramarzpour: 'امیر فرامرزپور',
    MojtabaAltafi: 'مجتبی الطافی',
    ImanKhorshidi: 'ایمان خورشیدی',
    AbolfazlNori: 'ابوالفضل نوری',
    //NitaHashemi: 'نیتا هاشمی',
    Officesecretary: 'مسئول دفتر',
    SalesSeniorMarketing: 'کارشناس فروش و بازاریابی',
    Marketing: ' بازاریابی و فروش',
  }
};

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState('fa');
  
  const t = (key: string): string => {
    return translations[language]?.[key] || key;
  };
  
  const isRTL = language === 'fa';
  
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      <div className={isRTL ? 'rtl font-lalezar' : 'ltr'}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};