import React, { useState, useEffect } from 'react';
//import { DollarSign } from 'lucide-react';
import { LanguageProvider } from './contexts/LanguageContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { useLanguage } from './contexts/LanguageContext';
import Header from './components/Header';
import Hero from './components/Hero';
import PropertyFilters from './components/PropertyFilters';
import PropertyResults from './components/PropertyResults';
import AgentCard from './components/AgentCard';
import BlogCard from './components/BlogCard';
import ExclusiveProjects from './components/ExclusiveProjects';
import FeaturedProperties from './components/FeaturedProperties';
import ConstructionHub from './components/ConstructionHub';
import SupportButton from './components/SupportButton';
import AboutUs from './components/AboutUs';
import { properties, agents, Property } from './data/MockData';
import { blogPosts } from './data/Blog';

interface Filters {
  location: string;
  minPrice: number | null;
  maxPrice: number | null;
  propertyType: string;
  furnished: boolean | null;
  bedrooms: number | null;
  bathrooms: number | null;
}

const AppContent: React.FC = () => {
  const { t } = useLanguage();
  const [currentSection, setCurrentSection] = useState('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState<'buy' | 'rent'>('buy');
  const [filteredProperties, setFilteredProperties] = useState<Property[]>(properties);
  const [sortOption, setSortOption] = useState('newest');
  const [currency, setCurrency] = useState('USD');
  const [expandedItem, setExpandedItem] = useState<{ type: string; id: string } | null>(null);

  // Currency conversion rates (simplified)
  const conversionRates = {
    USD: 1,
    IRR: 950000, // 1 USD = 950,000 IRR
    Toman: 95000 // 1 USD = 95,000 Toman (IRR/10)
  };

  const convertPrice = (priceInUSD: number): number => {
    return priceInUSD * conversionRates[currency as keyof typeof conversionRates];
  };

  const formatPrice = (price: number): string => {
    if (currency === 'IRR' || currency === 'Toman') {
      return price.toLocaleString('fa-IR');
    }
    return price.toLocaleString('en-US');
  };

  // Handle URL hash changes for deep linking
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.substring(1);
      if (hash) {
        if (hash.startsWith('blogpost')) {
          setCurrentSection('blog');
          setExpandedItem({ type: 'blog', id: hash });
        } else if (hash.startsWith('project')) {
          setCurrentSection('exclusiveProjects');
          setExpandedItem({ type: 'project', id: hash });
        } else if (hash.startsWith('hubpost')) {
          setCurrentSection('constructionHub');
          setExpandedItem({ type: 'hubpost', id: hash });
        } else if (hash.startsWith('featured')) {
          setCurrentSection('featuredProperties');
          setExpandedItem({ type: 'project', id: hash });
        } else {
          setCurrentSection('constructionHub'); // Default to constructionHub for any hash
          setExpandedItem({ type: 'hubpost', id: hash });
        }
      } else {
        setCurrentSection('home');
        setExpandedItem(null);
      }
    };

    handleHashChange(); // Check initial hash on page load
    window.addEventListener('hashchange', handleHashChange);

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleSearch = (query: string, type: 'buy' | 'rent') => {
    setSearchQuery(query);
    setSearchType(type);
    setCurrentSection('search');
    applyFiltersAndSort(query, type);
  };

  const handleFilterChange = (filters: Filters) => {
    let filtered = properties.filter(property => {
      // Location filter
      if (filters.location && !property.location.toLowerCase().includes(filters.location.toLowerCase())) {
        return false;
      }

      // Property type filter
      if (filters.propertyType && property.propertyType !== filters.propertyType) {
        return false;
      }

      // Price range filter
      if (filters.minPrice !== null && property.priceValue < filters.minPrice) {
        return false;
      }
      if (filters.maxPrice !== null && property.priceValue > filters.maxPrice) {
        return false;
      }

      // Furnished filter
      if (filters.furnished !== null && property.furnished !== filters.furnished) {
        return false;
      }

      // Bedrooms filter
      if (filters.bedrooms !== null) {
        if (filters.bedrooms === 4 && property.bedrooms < 4) {
          return false;
        } else if (filters.bedrooms < 4 && property.bedrooms !== filters.bedrooms) {
          return false;
        }
      }

      // Bathrooms filter
      if (filters.bathrooms !== null) {
        if (filters.bathrooms === 4 && property.bathrooms < 4) {
          return false;
        } else if (filters.bathrooms < 4 && property.bathrooms !== filters.bathrooms) {
          return false;
        }
      }

      return true;
    });

    filtered = sortProperties(filtered, sortOption);
    setFilteredProperties(filtered);
  };

  const applyFiltersAndSort = (query: string = searchQuery, type: 'buy' | 'rent' = searchType) => {
    let filtered = properties.filter(property => {
      const matchesQuery = !query || 
        property.title.toLowerCase().includes(query.toLowerCase()) ||
        property.location.toLowerCase().includes(query.toLowerCase()) ||
        property.propertyType.toLowerCase().includes(query.toLowerCase());
      
      const matchesType = property.type === type;
      
      return matchesQuery && matchesType;
    });

    filtered = sortProperties(filtered, sortOption);
    setFilteredProperties(filtered);
  };

  const sortProperties = (propertiesToSort: Property[], sort: string): Property[] => {
    const sorted = [...propertiesToSort];
    
    switch (sort) {
      case 'priceLowHigh':
        return sorted.sort((a, b) => a.priceValue - b.priceValue);
      case 'priceHighLow':
        return sorted.sort((a, b) => b.priceValue - a.priceValue);
      case 'newest':
      default:
        return sorted.sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime());
    }
  };

  const handleSortChange = (sort: string) => {
    setSortOption(sort);
    const sorted = sortProperties(filteredProperties, sort);
    setFilteredProperties(sorted);
  };

  const handleSectionChange = (section: string) => {
    setCurrentSection(section);
    if (section === 'buy' || section === 'rent') {
      setSearchType(section as 'buy' | 'rent');
      applyFiltersAndSort('', section as 'buy' | 'rent');
    }
  };

  const handleExpandItem = (type: string, id: string) => {
    setExpandedItem({ type, id });
    window.location.hash = id; // Use the id directly without prefix for flexibility
  };

  const handleCloseExpanded = () => { // Modified to only close the modal
    setExpandedItem(null);
    // Removed window.location.hash = '' to prevent navigation
  };

  const renderSection = () => {
    switch (currentSection) {
      case 'home':
        return <Hero onSearch={handleSearch} />;
      
      case 'search':
        return (
          <div className="container mx-auto px-4 py-8">
            <PropertyFilters onFilterChange={handleFilterChange} />
            <PropertyResults
              properties={filteredProperties}
              currency={currency}
              convertPrice={convertPrice}
              formatPrice={formatPrice}
              sortOption={sortOption}
              onSortChange={handleSortChange}
            />
          </div>
        );
      
      case 'buy':
      case 'rent':
        const typeProperties = properties.filter(p => p.type === currentSection);
        return (
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2" style={{ fontFamily: '"Amiri", serif' }}>
                  {t('Propertiesfor')} {currentSection === 'buy' ? t('buy') : t('rent')}
                </h2>
                <p className="text-gray-600 dark:text-gray-400" style={{ fontFamily: '"Amiri", serif' }}>
                  {typeProperties.length} {t('propertiesavailable')}
                </p>
              </div>
              
              {/* 
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-700 dark:text-gray-300">{t('currency')}:</span>
                </div>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="input-field min-w-[100px]"
                >
                  <option value="USD">{t('usd')}</option>
                  <option value="IRR">{t('irr')}</option>
                  <option value="Toman">{t('toman')}</option>
                </select>
              </div>
              */}
            </div>
            
            <PropertyResults
              properties={sortProperties(typeProperties, sortOption)}
              currency={currency}
              convertPrice={convertPrice}
              formatPrice={formatPrice}
              sortOption={sortOption}
              onSortChange={handleSortChange}
            />
          </div>
        );
      
      case 'findAgent':
        return (
          <div className="container mx-auto px-4 py-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
                {t('findAgent')}
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                {t('Connectwithour')}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {agents.map((agent, index) => (
                <div key={agent.id} style={{ animationDelay: `${index * 0.1}s` }}>
                  <AgentCard agent={agent} />
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'blog':
        return (
          <div className="container mx-auto px-4 py-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
                {t('blogTitle')}
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                {t('stayinformed')}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map((post, index) => (
                <div key={post.id} style={{ animationDelay: `${index * 0.1}s` }}>
                  <BlogCard
                    post={post}
                    onExpand={(id) => handleExpandItem('blog', id)}
                    isExpanded={expandedItem?.type === 'blog' && expandedItem?.id === post.id}
                    onClose={handleCloseExpanded}
                  />
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'exclusiveProjects':
        return (
          <ExclusiveProjects
            expandedItem={expandedItem}
            onExpand={handleExpandItem}
            onClose={handleCloseExpanded}
          />
        );
      
      case 'featuredProperties':
        return (
          <FeaturedProperties
            expandedItem={expandedItem}
            onExpand={handleExpandItem}
            onClose={handleCloseExpanded}
          />
        );
      
      case 'constructionHub':
        return (
          <ConstructionHub
            expandedItem={expandedItem}
            onExpand={handleExpandItem}
            onClose={handleCloseExpanded}
          />
        );
      
      case 'aboutUs':
        return <AboutUs />;
      
      default:
        return <Hero onSearch={handleSearch} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header currentSection={currentSection} onSectionChange={handleSectionChange} />
      <main>
        {renderSection()}
      </main>
      <SupportButton />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AppContent />
      </LanguageProvider>
    </ThemeProvider>
  );
};

export default App;