/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'aref': ['Aref Ruqaa', 'serif'],
        'gulzar': ['Gulzar', 'serif'],
        'lalezar': ['Lalezar', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
