export interface MenuItem {
  name: string;
  price: number;
  image: string;
}

export interface MenuCategory {
  name: string;
  icon: string;
  imagePrefix?: string;
  items: MenuItem[];
}