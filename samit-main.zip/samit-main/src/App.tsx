import { useState, useEffect } from 'react';
import MenuSection from './components/MenuSection';
import { menuData } from './data/menuData';
import { Phone, Instagram, MapPin, ExternalLink } from 'lucide-react';

function App() {
  const [view, setView] = useState('home');
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDateTime = () => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZone: 'Asia/Tehran',
    };
    return currentTime.toLocaleString('fa-IR', options).replace('AM', 'صبح').replace('PM', 'عصر');
  };

  const renderView = () => {
    switch (view) {
      case 'home':
        return (
          <div className="min-h-screen flex items-center justify-center bg-white">
            <div className="flex flex-col items-center">
              <img
                src="https://ik.imagekit.io/amirfaramarzpour/Samit/IMG_5403.JPG?updatedAt=1753188142083"
                alt="Restaurant Background"
                className="mb-8"
                style={{ width: '50%', height: 'auto' }}
              />
              <button
                onClick={() => setView('menu')}
                className="bg-black/75 text-white py-3 px-6 rounded-lg border-1 border-white hover:bg-[#181c18] hover:border-gray-300 transition-all duration-300 text-xl mb-4 w-64"
                style={{ fontFamily: 'Lalezar, sans-serif' }}
              >
                See Menu
              </button>
              <button
                onClick={() => setView('contact')}
                className="bg-black/75 text-white py-3 px-6 rounded-lg border-1 border-white hover:bg-[#181c18] hover:border-gray-300 transition-all duration-300 text-xl w-64"
                style={{ fontFamily: 'Lalezar, sans-serif' }}
              >
                Contact Us
              </button>
            </div>
          </div>
        );
        case 'menu':
          return (
            <div
              className="min-h-screen p-4"
              style={{
                backgroundImage: `url('https://ik.imagekit.io/amirfaramarzpour/Samit/bg2.jpg?updatedAt=1753878298332')`,
                backgroundSize: 'cover', // Use 'cover' to fill the container, cropping if necessary
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
                backgroundAttachment: 'fixed',
              }}
            >
              <div className="bg-white-800/10 p-4 min-h-screen">
                <button
                  onClick={() => setView('home')}
                  className="bg-black/50 backdrop-blur-lg text-white font-bold py-2 px-4 rounded-lg border-2 border-black hover:bg-gray-200 hover:border-gray-300 transition-all duration-300 mb-4"
                  style={{ fontFamily: 'Lalezar, sans-serif' }}
                >
                  صفحه اصلی
                </button>
                <div className="max-w-7xl mx-auto space-y-8">
                  {menuData.map((category, index) => (
                    <MenuSection
                      key={index}
                      category={category}
                      className="w-full"
                    />
                  ))}
                </div>
              </div>
            </div>
          );
      case 'contact':
        return (
          <div className="min-h-screen bg-gray-800/80 backdrop-blur-md p-4">
            <button
              onClick={() => setView('home')}
              className="bg-transparent text-white font-bold py-2 px-4 rounded-lg border-2 border-black hover:bg-gray-200 hover:border-gray-300 transition-all duration-300 mb-4"
              style={{ fontFamily: 'Lalezar, sans-serif' }}
            >
              صفحه اصلی
            </button>
            <div className="flex flex-col items-center space-y-4">
              <p className="text-4xl text-[#FFFFFF]" style={{ fontFamily: 'Lalezar, sans-serif' }}>
                آدرس و اطلاعات تماس
              </p>
              <div className="text-right text-base text-[#FFFFFF] py-8" style={{ fontFamily: 'Lalezar, sans-serif' }}>
                {formatDateTime()}
              </div>
              <button
                onClick={() => window.open('https://maps.app.goo.gl/Ar1ELCL7YyJ6XiTDA', '_blank')}
                className="bg-[#332D56] hover:bg-[#333446] text-white/90 px-8 py-4 rounded-lg transition-all duration-300 hover:scale-105 shadow-lg flex items-center justify-center space-x-2 space-x-reverse w-80 h-20"
                style={{ fontFamily: 'Lalezar, sans-serif' }}
              >
                <ExternalLink className="h-5 w-5" />
                <div className="text-sm font-bold">ساری، خیابان صبا، روبروی زندان سابق</div>
                <MapPin className="h-5 w-5" />
              </button>
              <button
                onClick={() => window.location.href = 'tel:+989113071200'}
                className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg transition-all duration-300 hover:scale-105 shadow-lg flex items-center justify-center space-x-2 space-x-reverse w-80 h-20"
                style={{ fontFamily: 'Lalezar, sans-serif' }}
              >
                <Phone className="h-4 w-4" />
                <div className="text-sm">شماره تماس </div>
                <span className="text-2xl font-bold">۰۹۱۱۳۰۷۱۲۰۰</span>
              </button>
              <button
                onClick={() => window.open('https://instagram.com/samit_restaurant', '_blank')}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 rounded-lg transition-all duration-300 hover:scale-105 shadow-lg flex items-center justify-center space-x-2 space-x-reverse w-80 h-20"
                style={{ fontFamily: 'Lalezar, sans-serif' }}
              >
                <div className="text-sm">اینستاگرام</div>
                <Instagram className="h-4 w-4" />
                <span className="text-base font-bold">Samit_Restaurant</span>
              </button>
              <div className="mt-2 pt-4 text-center flex justify-center items-center">
                <p className="text-[#FFFFFF] font-regular" style={{ fontFamily: 'Lalezar, sans-serif' }}>
                  Copyright 2025 Samit Restaurant | Design: 
                  <a 
                    href="https://amirfaramarzpour.ir" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:text-[#FFC107]-300 transition-colors duration-300 ml-1"
                  >
                    Amir
                  </a>
                </p>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return <div>{renderView()}</div>;
}

export default App;