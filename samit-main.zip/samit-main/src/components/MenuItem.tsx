import React from 'react';
import { toFarsiNumbers } from '../utils/numberUtils';

interface MenuItemProps {
  item: { name: string; price: number; image: string };
  index: number;
  showPrice?: boolean;
  imagePrefix?: string;
}

const MenuItem: React.FC<MenuItemProps> = ({ item, index, showPrice = true, imagePrefix }) => {
  return (
    <div className="flex items-center p-2 border-b border-gray-100 hover:bg-[#4B352A]/80 hover:backdrop-blur-sm">
      {imagePrefix && (
        <img
          src={`${imagePrefix}${item.image}`}
          alt={item.name}
          className="w-16 h-16 object-cover rounded mr-4"
        />
      )}
      <div className="flex-1 text-right">
        <h4 className="text-l text-[#FFFFFF]" style={{ fontFamily: 'Lalezar, sans-serif' }}>
          {item.name}
        </h4>
        {showPrice && (
          <span className="text-md font-regular text-[#FF9B2F]" style={{ fontFamily: 'Lalezar, sans-serif' }}>
            {toFarsiNumbers(item.price)} تومان
          </span>
        )}
      </div>
    </div>
  );
};

export default MenuItem;