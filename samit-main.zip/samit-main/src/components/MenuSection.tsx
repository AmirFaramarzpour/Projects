import React, { useState } from 'react';
import { Flame, UtensilsCrossed, Salad, Beer, ChevronsDownUp } from 'lucide-react';
import MenuItem from './MenuItem';
import { MenuCategory } from '../types/menu';

interface MenuSectionProps {
  category: MenuCategory;
  className?: string;
}

const MenuSection: React.FC<MenuSectionProps> = ({ category, className = '' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const showPrice = !['نوشیدنی', 'مخلفات'].includes(category.name);

  const getIcon = () => {
    switch (category.name) {
      case 'غذای اصلی':
        return Flame;
      case 'کباب‌ها':
        return UtensilsCrossed;
      case 'مخلفات':
        return Salad;
      case 'نوشیدنی':
        return Beer;
      default:
        return Flame;
    }
  };

  const IconComponent = getIcon();

  return (
    <div className={`relative rounded-lg transition-all duration-300 bg-black/50 backdrop-blur-lg border border-gray-200 shadow-sm ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-4 flex items-center justify-between text-left hover:bg-[#818281]"
      >
        <div className="flex items-center space-x-2 space-x-reverse">
          <div className="p-2 rounded-full bg-transparent">
            <IconComponent className="h-7 w-7 text-[#E9A319] border-gray-200 shadow-sm" />
          </div>
          <h3 className="text-xl text-[#FFFFFF]" style={{ fontFamily: 'Lalezar, sans-serif' }}>
            {category.name}
          </h3>
        </div>
        <ChevronsDownUp className={`h-5 w-5 text-gray-600 transition-transform ${isOpen ? 'rotate-180' : 'rotate-0'}`} />
      </button>
      <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-[1000px]' : 'max-h-0'}`}>
        <div className="p-4">
          <div className="max-h-96 overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
              {category.items.map((item, index) => (
                <MenuItem
                  key={index}
                  item={item}
                  index={index}
                  showPrice={showPrice}
                  imagePrefix={category.imagePrefix}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MenuSection;