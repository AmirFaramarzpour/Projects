// Utility function to convert English numbers to Farsi numbers
export const toFarsiNumbers = (num: number | string): string => {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  
  let numStr = num.toString();
  
  // Add thousand separators (commas) for better readability
  if (typeof num === 'number') {
    numStr = num.toLocaleString();
  }
  
  // Replace English digits with Farsi digits
  for (let i = 0; i < englishDigits.length; i++) {
    numStr = numStr.replace(new RegExp(englishDigits[i], 'g'), farsiDigits[i]);
  }
  
  return numStr;
};