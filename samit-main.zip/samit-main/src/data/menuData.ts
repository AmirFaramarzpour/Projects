export const menuData = [
  {
    name: 'غذای اصلی',
    icon: 'Flame',
    //imagePrefix: 'https://example.com/images/main/',
    items: [
      { name: 'چلو اکبر جوجه', price: 260000, image: '' },
      { name: 'زرشک‌پلو با مرغ', price: 230000, image: '' },
      { name: 'چلو مرغ اناردون', price: 295000, image: '' },
      { name: 'چلو مرغ ترش', price: 295000, image: '' },
      { name: 'چلو کوبیده', price: 310000, image: '' },
      { name: 'چلو جوجه کباب', price: 260000, image: '' },
      { name: 'چلو وزیری', price: 360000, image: '' },
      { name: 'چلو بختیاری', price: 310000, image: '' },
      { name: 'چلو فسنجان مرغ', price: 370000, image: '' },
      { name: 'چلو فسنجان بره', price: 630000, image: '' },
      { name: 'چلو گوشت بره', price: 570000, image: '' },
      { name: 'ته‌چین گوشت بره', price: 480000, image: '' },
      { name: 'ته‌چین مرغ', price: 320000, image: '' },
      { name: 'چلو ماهی قزل‌آلا', price: 470000, image: '' },
      { name: 'چلو خورشت آلو اسفناج', price: 295000, image: '' },
      { name: 'میرزا قاسمی', price: 160000, image: '' },
      { name: 'کشک بادمجان', price: 160000, image: '' },
    ]
  },
  {
    name: 'کباب‌ها',
    icon: 'UtensilsCrossed',
    //imagePrefix: 'https://example.com/images/kabab/',
    items: [
      { name: 'چنجه', price: 250000, image: '' },
      { name: 'شیشلیک', price: 450000, image: '' },
      { name: 'دنده', price: 250000, image: '' },
      { name: 'یونانی', price: 180000, image: '' },
      { name: 'نگینی', price: 220000, image: '' },
      { name: 'جوجه زعفرانی', price: 160000, image: '' },
      { name: 'جوجه ترش', price: 190000, image: '' },
      { name: 'کوبیده', price: 110000, image: '' },
      { name: 'کتف و بال', price: 150000, image: '' },
      { name: 'جگر دنبه', price: 110000, image: '' },
      { name: 'دل', price: 110000, image: '' },
      { name: 'قارچ', price: 60000, image: '' },
      { name: 'گوجه', price: 20000, image: '' },
    ]
  },
  {
    name: 'مخلفات',
    icon: 'Salad',
    //imagePrefix: 'https://example.com/images/sides/',
    items: [
      { name: 'ماست ساده', price: 79000, image: '' },
      { name: 'ماست دلال', price: 99000, image: '' },
      { name: 'ماست خیار', price: 89000, image: '' },
      { name: 'انواع ترشی', price: 109000, image: '' },
      { name: 'سالاد فصل', price: 69000, image: '' },
      { name: 'سالاد شیرازی', price: 69000, image: '' },
      { name: 'زیتون', price: 80000, image: '' },
    ]
  },
  {
    name: 'نوشیدنی',
    icon: 'Coffee',
    //imagePrefix: 'https://example.com/images/drinks/',
    items: [
      { name: 'نوشابه', price: 0, image: '' },
      { name: 'دلستر', price: 0, image: '' },
      { name: 'دوغ', price: 0, image: '' },
      { name: 'آب', price: 0, image: '' },
      { name: 'آب بزرگ', price: 0, image: '' },
      { name: 'نوشابه بزرگ', price: 0, image: '' },
      { name: 'دلستر بزرگ', price: 0, image: '' },
    ]
  },
];