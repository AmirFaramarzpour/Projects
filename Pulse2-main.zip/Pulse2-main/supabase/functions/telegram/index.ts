import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ');
}

function extractPosts(html: string) {
  const posts: any[] = [];
  const blockRegex = /<div[^>]*class="tgme_widget_message[^"]*"[^>]*data-post="([^"]+)"[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/g;
  let m;
  while ((m = blockRegex.exec(html)) !== null) {
    const block = m[0];
    const postId = m[1];
    const textMatch = block.match(/<div[^>]*class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/);
    let text = textMatch ? textMatch[1].replace(/<br\s*\/?>/g, '\n').replace(/<[^>]+>/g, '') : '';
    text = decodeEntities(text).trim();
    const timeMatch = block.match(/<time[^>]*datetime="([^"]+)"/);
    const datetime = timeMatch ? timeMatch[1] : '';
    const photoMatch = block.match(/background-image:url\('([^']+)'\)/);
    const photoUrl = photoMatch ? photoMatch[1].replace(/\\u002F/g, '/').replace(/\\\//g, '/') : null;
    if (!text && !photoUrl) continue;
    posts.push({ id: postId, postId, text, datetime, photoUrl });
  }
  return posts;
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  try {
    const url = new URL(req.url);
    const channel = url.searchParams.get('channel') ?? 'hotchartmusic';
    const res = await fetch(`https://t.me/s/${channel}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; PulseDashboard/1.0)',
        Accept: 'text/html',
      },
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) {
      return new Response(JSON.stringify({ error: `upstream ${res.status}`, posts: [] }), {
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const html = await res.text();
    let posts = extractPosts(html);
    posts = posts.reverse().slice(0, 10);
    return new Response(JSON.stringify({ posts, count: posts.length, fetchedAt: new Date().toISOString() }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e), posts: [] }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
