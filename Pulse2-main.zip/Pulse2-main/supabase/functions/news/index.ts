import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface FeedSource {
  outlet: string;
  category: string;
  url: string;
}

const FEEDS: FeedSource[] = [
  // BBC
  { outlet: 'BBC News', category: 'World', url: 'https://feeds.bbci.co.uk/news/world/rss.xml' },
  { outlet: 'BBC News', category: 'Business', url: 'https://feeds.bbci.co.uk/news/business/rss.xml' },
  { outlet: 'BBC News', category: 'Technology', url: 'https://feeds.bbci.co.uk/news/technology/rss.xml' },
  { outlet: 'BBC News', category: 'Science', url: 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml' },
  { outlet: 'BBC News', category: 'Health', url: 'https://feeds.bbci.co.uk/news/health/rss.xml' },
  { outlet: 'BBC News', category: 'Entertainment', url: 'https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml' },
  // The Guardian
  { outlet: 'The Guardian', category: 'World', url: 'https://www.theguardian.com/world/rss' },
  { outlet: 'The Guardian', category: 'Business', url: 'https://www.theguardian.com/business/rss' },
  { outlet: 'The Guardian', category: 'Technology', url: 'https://www.theguardian.com/technology/rss' },
  { outlet: 'The Guardian', category: 'Science', url: 'https://www.theguardian.com/science/rss' },
  { outlet: 'The Guardian', category: 'Sports', url: 'https://www.theguardian.com/sport/rss' },
  // Al Jazeera
  { outlet: 'Al Jazeera', category: 'World', url: 'https://www.aljazeera.com/xml/rss/all.xml' },
  { outlet: 'Al Jazeera', category: 'Business', url: 'https://www.aljazeera.com/xml/rss/economy.xml' },
  { outlet: 'Al Jazeera', category: 'Technology', url: 'https://www.aljazeera.com/xml/rss/technology.xml' },
  { outlet: 'Al Jazeera', category: 'Sports', url: 'https://www.aljazeera.com/xml/rss/sports.xml' },
  // NPR
  { outlet: 'NPR', category: 'World', url: 'https://feeds.npr.org/1004/rss.xml' },
  { outlet: 'NPR', category: 'Business', url: 'https://feeds.npr.org/1006/rss.xml' },
  { outlet: 'NPR', category: 'Technology', url: 'https://feeds.npr.org/1009/rss.xml' },
  { outlet: 'NPR', category: 'Science', url: 'https://feeds.npr.org/1007/rss.xml' },
  { outlet: 'NPR', category: 'Health', url: 'https://feeds.npr.org/1128/rss.xml' },
  { outlet: 'NPR', category: 'Entertainment', url: 'https://feeds.npr.org/1008/rss.xml' },
  // Sky News
  { outlet: 'Sky News', category: 'World', url: 'https://feeds.skynews.com/feeds/rss/world.xml' },
  { outlet: 'Sky News', category: 'Business', url: 'https://feeds.skynews.com/feeds/rss/business.xml' },
  { outlet: 'Sky News', category: 'Technology', url: 'https://feeds.skynews.com/feeds/rss/technology.xml' },
  { outlet: 'Sky News', category: 'Sports', url: 'https://feeds.skynews.com/feeds/rss/sports.xml' },
  // Google News Reuters-topic fallback
  { outlet: 'Reuters', category: 'World', url: 'https://news.google.com/rss/search?q=site:reuters.com+when:2d&hl=en-US&gl=US&ceid=US:en' },
  { outlet: 'Reuters', category: 'Business', url: 'https://news.google.com/rss/search?q=site:reuters.com+business+when:2d&hl=en-US&gl=US&ceid=US:en' },
  { outlet: 'Reuters', category: 'Technology', url: 'https://news.google.com/rss/search?q=site:reuters.com+technology+when:2d&hl=en-US&gl=US&ceid=US:en' },
];

function stripHtml(s: string): string {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .trim();
}

function outletCode(name: string): string {
  const words = name.replace(/[^a-zA-Z\s]/g, '').split(/\s+/).filter(Boolean);
  if (words.length === 1) return words[0].slice(0, 3).toUpperCase();
  return (words[0][0] + words[1][0] + (words[2]?.[0] ?? '')).toUpperCase().slice(0, 3);
}

function parseItems(xml: string, source: FeedSource): any[] {
  const items: any[] = [];
  const itemRegex = /<item[\s\S]*?<\/item>/g;
  let match;
  while ((match = itemRegex.exec(xml)) !== null) {
    const block = match[0];
    const title = block.match(/<title[^>]*>([\s\S]*?)<\/title>/)?.[1] ?? '';
    const link = block.match(/<link[^>]*>([\s\S]*?)<\/link>/)?.[1] ?? block.match(/<link[^>]*href="([^"]+)"/)?.[1] ?? '';
    const desc = block.match(/<description[^>]*>([\s\S]*?)<\/description>/)?.[1] ?? '';
    const pub = block.match(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/)?.[1] ?? '';
    const t = stripHtml(title);
    const u = stripHtml(link);
    if (!t || !u) continue;
    items.push({
      id: `${source.outlet}-${u}`,
      title: t,
      description: stripHtml(desc).slice(0, 280),
      url: u,
      outlet: source.outlet,
      outletCode: outletCode(source.outlet),
      category: source.category,
      publishedAt: pub ? new Date(pub).toISOString() : new Date().toISOString(),
    });
  }
  return items;
}

async function fetchFeed(source: FeedSource): Promise<any[]> {
  try {
    const res = await fetch(source.url, {
      headers: { 'User-Agent': 'PulseDashboard/1.0 (+https://bolt.new)' },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return [];
    const xml = await res.text();
    return parseItems(xml, source).slice(0, 12);
  } catch {
    return [];
  }
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  try {
    const results = await Promise.all(FEEDS.map(fetchFeed));
    const all = results.flat().sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt));
    return new Response(JSON.stringify({ articles: all, count: all.length, fetchedAt: new Date().toISOString() }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e), articles: [] }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
