import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const NEWS_FUNCTION_URL = `${supabaseUrl}/functions/v1/news`;
export const TELEGRAM_FUNCTION_URL = `${supabaseUrl}/functions/v1/telegram`;
