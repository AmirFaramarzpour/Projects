export interface CryptoCoin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  price_change_percentage_24h: number;
  sparkline_in_7d: { price: number[] };
  high_24h: number;
  low_24h: number;
}

export interface NewsArticle {
  id: string;
  title: string;
  description: string;
  url: string;
  outlet: string;
  outletCode: string;
  category: string;
  publishedAt: string;
}

export type Category =
  | 'All'
  | 'World'
  | 'Business'
  | 'Technology'
  | 'Sports'
  | 'Science'
  | 'Health'
  | 'Entertainment';

export interface WeatherCurrent {
  temperature: number;
  apparentTemperature: number;
  weatherCode: number;
  windSpeed: number;
}

export interface WeatherDaily {
  date: string;
  weatherCode: number;
  tempMax: number;
  tempMin: number;
}

export interface WeatherData {
  city: string;
  latitude: number;
  longitude: number;
  current: WeatherCurrent;
  daily: WeatherDaily[];
}

export interface TelegramPost {
  id: string;
  postId: string;
  text: string;
  datetime: string;
  photoUrl: string | null;
}
