import { useEffect, useRef, useState } from 'react';
import type { NewsArticle } from '@/types';
import { NEWS_FUNCTION_URL, supabase } from '@/lib/supabase';

interface NewsResponse {
  articles: NewsArticle[];
  count: number;
  fetchedAt: string;
  error?: string;
}

export function useNews(refreshMs = 5 * 60 * 1000) {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [fetchedAt, setFetchedAt] = useState<Date | null>(null);
  const reqId = useRef(0);

  useEffect(() => {
    let active = true;
    async function load() {
      const myId = ++reqId.current;
      try {
        const { data, error: fnError } = await supabase.functions.invoke<NewsResponse>('news');
        if (!active || myId !== reqId.current) return;
        if (fnError) throw fnError;
        if (data?.error) throw new Error(data.error);
        const arts = data?.articles ?? [];
        setArticles(arts);
        setFetchedAt(new Date());
        setError(null);
      } catch (e) {
        if (!active || myId !== reqId.current) return;
        setError(e instanceof Error ? e.message : 'Failed to load news');
        try {
          const res = await fetch(NEWS_FUNCTION_URL);
          if (res.ok) {
            const fallback = (await res.json()) as NewsResponse;
            if (active && myId === reqId.current && fallback.articles.length) {
              setArticles(fallback.articles);
              setFetchedAt(new Date());
              setError(null);
            }
          }
        } catch {
          /* ignore */
        }
      } finally {
        if (active && myId === reqId.current) setLoading(false);
      }
    }
    load();
    const id = setInterval(load, refreshMs);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [refreshMs]);

  return { articles, loading, error, fetchedAt };
}
