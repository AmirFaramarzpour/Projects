import { useEffect, useState } from 'react';
import type { WeatherData } from '@/types';
import { weatherLabel } from '@/lib/utils';

const FALLBACK = { lat: 51.5074, lon: -0.1278, city: 'London' };
const REVERSE_GEO_URL = 'https://geocoding-api.open-meteo.com/v1/reverse';

async function reverseGeocode(lat: number, lon: number): Promise<string> {
  try {
    const res = await fetch(`${REVERSE_GEO_URL}?latitude=${lat}&longitude=${lon}&language=en&format=json`);
    if (!res.ok) throw new Error('geocode failed');
    const data = await res.json();
    const r = data?.results?.[0];
    if (!r) return 'Your location';
    return r.name ?? r.admin1 ?? r.country ?? 'Your location';
  } catch {
    return 'Your location';
  }
}

export function useWeather() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    async function load(lat: number, lon: number, city: string) {
      try {
        const url =
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
          `&current=temperature_2m,weather_code,apparent_temperature,wind_speed_10m` +
          `&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(`status ${res.status}`);
        const data = await res.json();
        if (!active) return;
        setWeather({
          city,
          latitude: lat,
          longitude: lon,
          current: {
            temperature: data.current.temperature_2m,
            apparentTemperature: data.current.apparent_temperature,
            weatherCode: data.current.weather_code,
            windSpeed: data.current.wind_speed_10m,
          },
          daily: (data.daily.time as string[]).map((date, i) => ({
            date,
            weatherCode: data.daily.weather_code[i],
            tempMax: data.daily.temperature_2m_max[i],
            tempMin: data.daily.temperature_2m_min[i],
          })),
        });
        setError(null);
      } catch (e) {
        if (active) setError(e instanceof Error ? e.message : 'Weather unavailable');
      } finally {
        if (active) setLoading(false);
      }
    }

    async function init() {
      if (!('geolocation' in navigator)) {
        await load(FALLBACK.lat, FALLBACK.lon, FALLBACK.city);
        return;
      }
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const { latitude, longitude } = pos.coords;
          const city = await reverseGeocode(latitude, longitude);
          await load(latitude, longitude, city);
        },
        async () => {
          await load(FALLBACK.lat, FALLBACK.lon, FALLBACK.city);
        },
        { timeout: 8000, maximumAge: 600000 },
      );
    }
    init();
    return () => {
      active = false;
    };
  }, []);

  async function changeCity(query: string) {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const geoRes = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=1&language=en&format=json`,
      );
      const geoData = await geoRes.json();
      const r = geoData?.results?.[0];
      if (!r) throw new Error('City not found');
      const lat = r.latitude;
      const lon = r.longitude;
      const city = r.name;
      const url =
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
        `&current=temperature_2m,weather_code,apparent_temperature,wind_speed_10m` +
        `&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5`;
      const res = await fetch(url);
      const data = await res.json();
      setWeather({
        city,
        latitude: lat,
        longitude: lon,
        current: {
          temperature: data.current.temperature_2m,
          apparentTemperature: data.current.apparent_temperature,
          weatherCode: data.current.weather_code,
          windSpeed: data.current.wind_speed_10m,
        },
        daily: (data.daily.time as string[]).map((date, i) => ({
          date,
          weatherCode: data.daily.weather_code[i],
          tempMax: data.daily.temperature_2m_max[i],
          tempMin: data.daily.temperature_2m_min[i],
        })),
      });
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'City not found');
    } finally {
      setLoading(false);
    }
  }

  return { weather, loading, error, changeCity };
}

export { weatherLabel };
