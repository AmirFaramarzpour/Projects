import { useEffect, useState } from 'react';
import type { TelegramPost } from '@/types';
import { supabase } from '@/lib/supabase';

interface TelegramResponse {
  posts: TelegramPost[];
  count: number;
  fetchedAt: string;
  error?: string;
}

export function useTelegram(channel = 'IranintlTV', refreshMs = 900) {
  const [posts, setPosts] = useState<TelegramPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const { data, error: fnError } = await supabase.functions.invoke<TelegramResponse>(
          `telegram?channel=${encodeURIComponent(channel)}`,
        );
        if (!active) return;
        if (fnError) throw fnError;
        if (data?.error) throw new Error(data.error);
        setPosts(data?.posts ?? []);
        setError(null);
      } catch (e) {
        if (active) setError(e instanceof Error ? e.message : 'Failed to load Telegram feed');
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    const id = setInterval(load, refreshMs);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [channel, refreshMs]);

  return { posts, loading, error };
}
