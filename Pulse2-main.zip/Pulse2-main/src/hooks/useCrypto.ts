import { useEffect, useRef, useState } from 'react';
import type { CryptoCoin } from '@/types';

const COINGECKO_URL =
  'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=true&price_change_percentage=24h';

export function useCrypto(refreshMs = 45000) {
  const [coins, setCoins] = useState<CryptoCoin[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [volatility, setVolatility] = useState(0);
  const prevBtcRef = useRef<number | null>(null);

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const res = await fetch(COINGECKO_URL, {
          headers: { accept: 'application/json' },
        });
        if (!res.ok) throw new Error(`status ${res.status}`);
        const data: CryptoCoin[] = await res.json();
        if (!active) return;
        const btc = data.find((c) => c.id === 'bitcoin');
        if (btc) {
          setVolatility(Math.min(1, Math.abs(btc.price_change_percentage_24h) / 8));
          void prevBtcRef;
        }
        setCoins(data);
        setLastUpdated(new Date());
        setError(null);
      } catch (e) {
        if (active) setError(e instanceof Error ? e.message : 'Failed to load markets');
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    const id = setInterval(load, refreshMs);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [refreshMs]);

  return { coins, loading, error, lastUpdated, volatility };
}
