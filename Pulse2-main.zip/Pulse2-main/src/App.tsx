import { useMemo, useState } from 'react';
import { Topbar } from '@/components/Topbar';
import { TickerTape } from '@/components/TickerTape';
import { CategoryRail } from '@/components/CategoryRail';
import { NewsFeed } from '@/components/NewsFeed';
import { WeatherCard } from '@/components/WeatherCard';
import { CryptoCard } from '@/components/CryptoCard';
import { TelegramCard } from '@/components/TelegramCard';
import { useCrypto } from '@/hooks/useCrypto';
import { useNews } from '@/hooks/useNews';
import { useWeather } from '@/hooks/useWeather';
import { useTelegram } from '@/hooks/useTelegram';
import type { Category } from '@/types';

const CATEGORIES: Category[] = [
  'All',
  'World',
  'Business',
  'Technology',
  'Sports',
  'Science',
  'Health',
  'Entertainment',
];

const TELEGRAM_CHANNEL = 'IranintlTV';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<Category>('All');
  const [search, setSearch] = useState('');

  const { coins, loading: cryptoLoading, error: cryptoError, lastUpdated, volatility } = useCrypto();
  const { articles, loading: newsLoading, error: newsError } = useNews();
  const { weather, loading: weatherLoading, error: weatherError, changeCity } = useWeather();
  const { posts, loading: tgLoading, error: tgError } = useTelegram(TELEGRAM_CHANNEL);

  const counts = useMemo(() => {
    const map: Record<string, number> = { All: articles.length };
    for (const a of articles) {
      map[a.category] = (map[a.category] ?? 0) + 1;
    }
    return map;
  }, [articles]);

  return (
    <div className="min-h-screen bg-[#0A0C10] text-[#EDEEF0]">
      <Topbar volatility={volatility} search={search} onSearch={setSearch} />
      <TickerTape coins={coins} />

      <main className="mx-auto max-w-[1600px] px-4 py-4 sm:px-6">
        <div className="flex flex-col gap-4 lg:flex-row">
          <CategoryRail
            categories={CATEGORIES}
            active={activeCategory}
            onSelect={setActiveCategory}
            counts={counts}
          />

          <NewsFeed
            articles={articles}
            loading={newsLoading}
            error={newsError}
            activeCategory={activeCategory}
            search={search}
          />

          <aside className="flex w-full shrink-0 flex-col gap-4 lg:w-[340px]">
            <WeatherCard
              weather={weather}
              loading={weatherLoading}
              error={weatherError}
              onChangeCity={changeCity}
            />
            <CryptoCard
              coins={coins}
              loading={cryptoLoading}
              error={cryptoError}
              lastUpdated={lastUpdated}
            />
            <TelegramCard
              posts={posts}
              loading={tgLoading}
              error={tgError}
              channel={TELEGRAM_CHANNEL}
            />
          </aside>
        </div>
      </main>

      <footer className="border-t border-[#262B33] px-6 py-4 text-center">
        <span className="font-mono text-[10px] text-[#868D96]">
          Pulse — live data from CoinGecko, Open-Meteo, RSS feeds & Telegram · auto-refreshing
        </span>
      </footer>
    </div>
  );
}
