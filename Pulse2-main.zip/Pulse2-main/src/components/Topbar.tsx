import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TopbarProps {
  volatility: number;
  search: string;
  onSearch: (v: string) => void;
}

function buildPulsePath(volatility: number, width = 480, height = 28): string {
  const amp = 4 + volatility * 16;
  const points: string[] = [];
  const segments = 24;
  for (let i = 0; i <= segments; i++) {
    const x = (i / segments) * width;
    const baseY = height / 2;
    const t = i / segments;
    const spike = Math.sin(t * Math.PI * 6) * amp * (0.3 + 0.7 * Math.sin(t * Math.PI * 3 + volatility * 5));
    const y = baseY + spike;
    points.push(`${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`);
  }
  return points.join(' ');
}

export function Topbar({ volatility, search, onSearch }: TopbarProps) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  const date = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });

  return (
    <header
      className={cn(
        'sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-[#262B33] bg-[#0A0C10]/95 px-4 backdrop-blur-md sm:px-6',
      )}
    >
      <div className="flex min-w-0 flex-col">
        <div className="flex items-center gap-2">
          <span className="font-display text-xl font-bold tracking-tight text-[#EDEEF0]">
            Pulse
          </span>
          <span className="hidden h-1.5 w-1.5 rounded-full bg-[#3DD6F5] sm:inline-block" />
        </div>
        <svg
          viewBox="0 0 480 28"
          preserveAspectRatio="none"
          className="mt-0.5 h-4 w-[140px] sm:w-[220px]"
          aria-hidden
        >
          <path
            d={buildPulsePath(volatility)}
            fill="none"
            stroke="#3DD6F5"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="pulse-line"
            style={{ filter: 'drop-shadow(0 0 3px rgba(61,214,245,0.5))' }}
          />
        </svg>
      </div>

      <div className="relative flex-1 max-w-xs sm:max-w-sm md:max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#868D96]" />
        <input
          type="text"
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          placeholder="Search headlines..."
          className="w-full rounded-full border border-[#262B33] bg-[#14171C] py-2 pl-9 pr-4 text-sm text-[#EDEEF0] placeholder:text-[#868D96] focus:border-[#3DD6F5]/50 focus:outline-none focus:ring-1 focus:ring-[#3DD6F5]/30"
        />
      </div>

      <div className="hidden text-right sm:block">
        <div className="font-mono text-sm text-[#868D96]">{time}</div>
        <div className="font-mono text-[11px] text-[#868D96]/70">{date}</div>
      </div>
    </header>
  );
}
