import { useState } from 'react';
import { MapPin, Pencil, Search, Wind } from 'lucide-react';
import type { WeatherData } from '@/types';
import { cn, dayAbbr, weatherIcon, weatherLabel } from '@/lib/utils';

interface WeatherCardProps {
  weather: WeatherData | null;
  loading: boolean;
  error: string | null;
  onChangeCity: (q: string) => void;
}

export function WeatherCard({ weather, loading, error, onChangeCity }: WeatherCardProps) {
  const [editing, setEditing] = useState(false);
  const [query, setQuery] = useState('');

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim()) {
      onChangeCity(query.trim());
      setQuery('');
      setEditing(false);
    }
  }

  if (loading && !weather) {
    return (
      <div className="animate-pulse rounded-xl border border-[#262B33] bg-[#14171C] p-5">
        <div className="h-4 w-24 rounded bg-[#1B1F26]" />
        <div className="mt-4 h-12 w-32 rounded bg-[#1B1F26]" />
        <div className="mt-4 flex justify-between">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-12 w-12 rounded bg-[#1B1F26]" />
          ))}
        </div>
      </div>
    );
  }

  if (!weather) {
    return (
      <div className="rounded-xl border border-[#262B33] bg-[#14171C] p-5 text-sm text-[#868D96]">
        {error ? `Weather unavailable: ${error}` : 'Weather loading...'}
      </div>
    );
  }

  const Icon = weatherIcon(weather.current.weatherCode);

  return (
    <div className="animate-fade-slide-in rounded-xl border border-[#262B33] bg-[#14171C] p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-[#EDEEF0]">
          <MapPin className="h-4 w-4 text-[#3DD6F5]" />
          {editing ? (
            <form onSubmit={submit} className="flex items-center gap-1">
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search city..."
                className="w-28 rounded-md border border-[#262B33] bg-[#0A0C10] px-2 py-1 text-xs text-[#EDEEF0] placeholder:text-[#868D96] focus:border-[#3DD6F5]/50 focus:outline-none"
              />
              <button type="submit">
                <Search className="h-3.5 w-3.5 text-[#3DD6F5]" />
              </button>
            </form>
          ) : (
            <span className="font-display text-sm font-semibold">{weather.city}</span>
          )}
        </div>
        <button
          onClick={() => setEditing((v) => !v)}
          className="text-[#868D96] transition-colors hover:text-[#3DD6F5]"
          aria-label="Change city"
        >
          <Pencil className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="mt-4 flex items-center gap-4">
        <span className="font-display text-5xl font-bold text-[#EDEEF0]">
          {Math.round(weather.current.temperature)}°
        </span>
        <Icon className="h-10 w-10 text-[#3DD6F5]" style={{ filter: 'drop-shadow(0 0 4px rgba(61,214,245,0.4))' }} />
      </div>

      <div className="mt-1 flex items-center gap-3">
        <span className="text-sm text-[#868D96]">{weatherLabel(weather.current.weatherCode)}</span>
        <span className="font-mono text-xs text-[#868D96]">
          Feels {Math.round(weather.current.apparentTemperature)}°
        </span>
        <span className="flex items-center gap-1 font-mono text-xs text-[#868D96]">
          <Wind className="h-3 w-3" /> {Math.round(weather.current.windSpeed)} km/h
        </span>
      </div>

      <div className="mt-4 grid grid-cols-5 gap-1 border-t border-[#262B33] pt-3">
        {weather.daily.map((d) => {
          const DIcon = weatherIcon(d.weatherCode);
          return (
            <div key={d.date} className="flex flex-col items-center gap-1">
              <span className="text-[10px] font-medium uppercase text-[#868D96]">{dayAbbr(d.date)}</span>
              <DIcon className="h-4 w-4 text-[#3DD6F5]" />
              <span className="font-mono text-[11px] text-[#EDEEF0]">{Math.round(d.tempMax)}°</span>
              <span className={cn('font-mono text-[10px] text-[#868D96]')}>{Math.round(d.tempMin)}°</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
