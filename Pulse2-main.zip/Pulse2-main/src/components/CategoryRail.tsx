import type { Category } from '@/types';
import { cn } from '@/lib/utils';

interface CategoryRailProps {
  categories: Category[];
  active: Category;
  onSelect: (c: Category) => void;
  counts: Record<string, number>;
}

export function CategoryRail({ categories, active, onSelect, counts }: CategoryRailProps) {
  return (
    <>
      {/* Desktop vertical rail */}
      <nav className="hidden w-[140px] shrink-0 flex-col gap-1 md:flex lg:w-[180px]">
        {categories.map((c) => {
          const isActive = c === active;
          return (
            <button
              key={c}
              onClick={() => onSelect(c)}
              className={cn(
                'flex items-center justify-between rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors',
                isActive
                  ? 'border-l-2 border-[#3DD6F5] bg-[#1B1F26] text-[#3DD6F5]'
                  : 'text-[#868D96] hover:bg-[#14171C] hover:text-[#EDEEF0]',
              )}
            >
              <span>{c}</span>
              {counts[c] !== undefined && (
                <span className="font-mono text-[10px] text-[#868D96]">{counts[c]}</span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Mobile/tablet horizontal pill row */}
      <nav className="flex gap-2 overflow-x-auto pb-2 md:hidden">
        {categories.map((c) => {
          const isActive = c === active;
          return (
            <button
              key={c}
              onClick={() => onSelect(c)}
              className={cn(
                'shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition-colors',
                isActive
                  ? 'bg-[#1B1F26] text-[#3DD6F5] ring-1 ring-[#3DD6F5]/40'
                  : 'bg-[#14171C] text-[#868D96] hover:text-[#EDEEF0]',
              )}
            >
              {c}
            </button>
          );
        })}
      </nav>
    </>
  );
}
