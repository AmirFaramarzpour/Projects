import { TrendingDown, TrendingUp } from 'lucide-react';
import type { CryptoCoin } from '@/types';
import { cn, formatPrice } from '@/lib/utils';

interface TickerTapeProps {
  coins: CryptoCoin[];
}

export function TickerTape({ coins }: TickerTapeProps) {
  if (coins.length === 0) {
    return <div className="h-10 border-b border-[#262B33] bg-[#14171C]" />;
  }

  const items = [...coins, ...coins];

  return (
    <div className="relative h-10 overflow-hidden border-b border-[#262B33] bg-[#14171C]">
      <div className="marquee-track flex h-full items-center gap-6 whitespace-nowrap px-6">
        {items.map((c, i) => {
          const up = c.price_change_percentage_24h >= 0;
          return (
            <span key={`${c.id}-${i}`} className="flex items-center gap-2">
              <span className="font-mono text-xs font-medium text-[#EDEEF0]">{c.symbol.toUpperCase()}</span>
              <span className="font-mono text-xs text-[#868D96]">{formatPrice(c.current_price)}</span>
              <span
                className={cn(
                  'flex items-center gap-0.5 font-mono text-xs',
                  up ? 'text-[#4ADE80]' : 'text-[#F76464]',
                )}
              >
                {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                {up ? '+' : ''}
                {c.price_change_percentage_24h.toFixed(2)}%
              </span>
              <span className="text-[#262B33]">|</span>
            </span>
          );
        })}
      </div>
    </div>
  );
}
