import { useMemo, useState } from 'react';
import type { Category, NewsArticle } from '@/types';
import { NewsCard, NewsCardSkeleton } from '@/components/NewsCard';

interface NewsFeedProps {
  articles: NewsArticle[];
  loading: boolean;
  error: string | null;
  activeCategory: Category;
  search: string;
}

const PAGE = 12;

export function NewsFeed({ articles, loading, error, activeCategory, search }: NewsFeedProps) {
  const [visible, setVisible] = useState(PAGE);

  const filtered = useMemo(() => {
    let list = articles;
    if (activeCategory !== 'All') {
      list = list.filter((a) => a.category === activeCategory);
    }
    const q = search.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (a) => a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q),
      );
    }
    return list;
  }, [articles, activeCategory, search]);

  const shown = filtered.slice(0, visible);

  return (
    <section className="min-w-0 flex-1">
      <div className="mb-3 flex items-baseline gap-3">
        <h2 className="font-display text-lg font-semibold text-[#EDEEF0]">{activeCategory}</h2>
        <span className="font-mono text-xs text-[#868D96]">
          {loading ? '...' : `${filtered.length} stories`}
        </span>
      </div>

      {error && !loading && filtered.length === 0 && (
        <div className="rounded-xl border border-[#F76464]/30 bg-[#F76464]/5 p-4 text-sm text-[#F76464]">
          Couldn't load news right now. {error}
        </div>
      )}

      <div className="space-y-3">
        {loading && articles.length === 0
          ? Array.from({ length: 6 }).map((_, i) => <NewsCardSkeleton key={i} />)
          : shown.map((a, i) => <NewsCard key={a.id} article={a} index={i} />)}
      </div>

      {!loading && filtered.length > visible && (
        <div className="mt-4 flex justify-center">
          <button
            onClick={() => setVisible((v) => v + PAGE)}
            className="rounded-full border border-[#262B33] bg-[#14171C] px-5 py-2 text-sm font-medium text-[#EDEEF0] transition-colors hover:border-[#3DD6F5]/40 hover:text-[#3DD6F5]"
          >
            Load more
          </button>
        </div>
      )}

      {!loading && filtered.length === 0 && !error && (
        <div className="rounded-xl border border-[#262B33] bg-[#14171C] p-8 text-center text-sm text-[#868D96]">
          No headlines match your search.
        </div>
      )}
    </section>
  );
}
