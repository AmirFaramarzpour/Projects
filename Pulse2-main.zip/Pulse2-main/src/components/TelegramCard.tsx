import { ExternalLink } from 'lucide-react';
import type { TelegramPost } from '@/types';
import { cn, timeAgo } from '@/lib/utils';

interface TelegramCardProps {
  posts: TelegramPost[];
  loading: boolean;
  error: string | null;
  channel: string;
}

export function TelegramCard({ posts, loading, error, channel }: TelegramCardProps) {
  return (
    <div className="animate-fade-slide-in rounded-xl border border-[#262B33] bg-[#14171C] p-5">
      <div className="mb-3 flex items-center gap-2">
        <span className="h-2 w-2 animate-pulse rounded-full bg-[#B296FF]" />
        <h3 className="font-display text-base font-semibold text-[#EDEEF0]">
          Latest: @{channel}
        </h3>
      </div>

      {loading && posts.length === 0 ? (
        <div className="space-y-3">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex animate-pulse gap-2 border-t border-[#262B33] pt-3">
              <div className="h-9 w-9 shrink-0 rounded bg-[#1B1F26]" />
              <div className="flex-1 space-y-1">
                <div className="h-3 w-full rounded bg-[#1B1F26]" />
                <div className="h-3 w-2/3 rounded bg-[#1B1F26]" />
              </div>
            </div>
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="py-4 text-center text-xs text-[#868D96]">
          {error ? 'Telegram feed unavailable' : 'No recent posts'}
        </div>
      ) : (
        <div className="space-y-0">
          {posts.map((p, i) => (
            <a
              key={p.id}
              href={`https://t.me/${p.postId}`}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                'group flex gap-2.5 py-2.5 transition-colors hover:bg-[#1B1F26]/50',
                i !== 0 && 'border-t border-[#262B33]',
              )}
            >
              {p.photoUrl ? (
                <img
                  src={p.photoUrl}
                  alt=""
                  loading="lazy"
                  className="h-9 w-9 shrink-0 rounded object-cover"
                />
              ) : (
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded bg-[#1B1F26]/60">
                  <span className="text-[10px] font-bold text-[#B296FF]">TG</span>
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="line-clamp-6 text-sm text-[#EDEEF0] group-hover:text-white">{p.text || '(media post)'}</p>
                <span className="font-mono text-[10px] text-[#868D96]">
                  {p.datetime ? timeAgo(p.datetime) : ''}
                </span>
              </div>
              <ExternalLink className="h-3.5 w-3.5 shrink-0 text-[#868D96] opacity-0 transition-opacity group-hover:opacity-100" />
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
