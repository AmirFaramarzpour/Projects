import type { NewsArticle } from '@/types';
import { cn, outletTint, timeAgo } from '@/lib/utils';

interface NewsCardProps {
  article: NewsArticle;
  index: number;
}

export function NewsCard({ article, index }: NewsCardProps) {
  const tint = outletTint(article.outletCode);
  return (
    <a
      href={article.url}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        'animate-fade-slide-in block rounded-xl border border-[#262B33] bg-[#14171C] p-4 transition-colors hover:border-[#3DD6F5]/40',
      )}
      style={{ animationDelay: `${Math.min(index * 40, 400)}ms` }}
    >
      <div className="mb-2 flex items-center gap-2">
        <span
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[9px] font-bold text-white"
          style={{ backgroundColor: tint }}
        >
          {article.outletCode}
        </span>
        <span className="text-xs font-medium text-[#868D96]">{article.outlet}</span>
        <span className="rounded-full bg-[#1B1F26] px-2 py-0.5 text-[10px] uppercase tracking-wider text-[#3DD6F5]">
          {article.category}
        </span>
        <span className="ml-auto font-mono text-[11px] text-[#868D96]">{timeAgo(article.publishedAt)}</span>
      </div>
      <h3 className="font-display text-base font-semibold leading-snug text-[#EDEEF0]">{article.title}</h3>
      {article.description && (
        <p className="mt-1 line-clamp-2 text-sm text-[#868D96]">{article.description}</p>
      )}
    </a>
  );
}

export function NewsCardSkeleton() {
  return (
    <div className="animate-pulse rounded-xl border border-[#262B33] bg-[#14171C] p-4">
      <div className="mb-2 flex items-center gap-2">
        <div className="h-6 w-6 rounded-full bg-[#1B1F26]" />
        <div className="h-3 w-20 rounded bg-[#1B1F26]" />
        <div className="h-4 w-16 rounded-full bg-[#1B1F26]" />
        <div className="ml-auto h-3 w-12 rounded bg-[#1B1F26]" />
      </div>
      <div className="h-4 w-3/4 rounded bg-[#1B1F26]" />
      <div className="mt-2 h-3 w-full rounded bg-[#1B1F26]" />
      <div className="mt-1 h-3 w-2/3 rounded bg-[#1B1F26]" />
    </div>
  );
}
