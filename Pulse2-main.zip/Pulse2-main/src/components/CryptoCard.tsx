import { TrendingDown, TrendingUp } from 'lucide-react';
import type { CryptoCoin } from '@/types';
import { cn, formatPrice } from '@/lib/utils';

interface CryptoCardProps {
  coins: CryptoCoin[];
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
}

function Sparkline({ data, up }: { data: number[]; up: boolean }) {
  if (!data || data.length < 2) return null;
  const w = 40;
  const h = 16;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - ((v - min) / range) * h;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
  return (
    <svg width={w} height={h} className="shrink-0">
      <polyline
        points={pts}
        fill="none"
        stroke={up ? '#4ADE80' : '#F76464'}
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function CryptoCard({ coins, loading, error, lastUpdated }: CryptoCardProps) {
  return (
    <div className="animate-fade-slide-in rounded-xl border border-[#262B33] bg-[#14171C] p-5">
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="font-display text-base font-semibold text-[#EDEEF0]">Markets</h3>
        {lastUpdated && (
          <span className="font-mono text-[10px] text-[#868D96]">
            {lastUpdated.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
          </span>
        )}
      </div>

      {error && coins.length === 0 && (
        <div className="py-4 text-center text-xs text-[#F76464]">Markets unavailable</div>
      )}

      {loading && coins.length === 0 ? (
        <div className="space-y-2">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="flex animate-pulse items-center gap-2">
              <div className="h-3 w-3 rounded bg-[#1B1F26]" />
              <div className="h-4 w-4 rounded-full bg-[#1B1F26]" />
              <div className="h-3 w-10 rounded bg-[#1B1F26]" />
              <div className="ml-auto h-3 w-14 rounded bg-[#1B1F26]" />
              <div className="h-3 w-10 rounded bg-[#1B1F26]" />
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-1">
          {coins.map((c) => {
            const up = c.price_change_percentage_24h >= 0;
            const isBtc = c.id === 'bitcoin';
            return (
              <div
                key={c.id}
                className={cn(
                  'flex items-center gap-2 rounded-lg px-2 py-1.5',
                  isBtc && 'bg-[#1B1F26]',
                )}
              >
                <span className="w-4 font-mono text-xs text-[#868D96]">{c.market_cap_rank}</span>
                <img src={c.image} alt={c.symbol} className="h-5 w-5 rounded-full" loading="lazy" />
                <span className="text-sm font-medium text-[#EDEEF0]">{c.symbol.toUpperCase()}</span>
                <span className="ml-auto font-mono text-sm text-[#EDEEF0]">{formatPrice(c.current_price)}</span>
                <span
                  className={cn(
                    'flex items-center gap-0.5 font-mono text-xs',
                    up ? 'text-[#4ADE80]' : 'text-[#F76464]',
                  )}
                >
                  {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {up ? '+' : ''}
                  {c.price_change_percentage_24h.toFixed(2)}%
                </span>
                <Sparkline data={c.sparkline_in_7d?.price ?? []} up={up} />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
